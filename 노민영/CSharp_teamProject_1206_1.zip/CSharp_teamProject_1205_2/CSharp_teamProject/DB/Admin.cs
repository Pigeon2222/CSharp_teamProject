﻿using System;

namespace CSharp_teamProject.DB
{
    public class Admin
    {
        public int admin_num { get; set; }
        public string admin_id { get; set; }
        public string admin_passWord { get; set; }
        public string admin_name { get; set; }
        public string admin_phoneNum { get; set; }
        public string admin_email { get; set; }
        public DateTime admin_createTime { get; set; }
    }
}
