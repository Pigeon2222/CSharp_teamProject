﻿using System;

namespace CSharp_teamProject.DB
{
    public class User
    {
        public int user_num { get; set; }
        public string user_id { get; set; }
        public string user_passWord { get; set; }
        public string user_name { get; set; }
        public string user_phoneNum { get; set; }
        public string user_email { get; set; }
        public DateTime user_createTime { get; set; }
    }
}
