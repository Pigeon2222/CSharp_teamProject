﻿
using System;
using System.Linq;
using System.Windows.Forms;

namespace CSharp_teamProject
{
    public partial class Login_up : Form
    {
        public Login_up()
        {
            InitializeComponent();
            maskedTextBox2.KeyUp += (sender, e) =>
            {
                if (e.KeyCode == Keys.Enter)
                {
                    Login_button_Login.PerformClick();
                    maskedTextBox2.Text = "";
                }
            };
        }

        private void Login_button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Login_button_Login_Click(object sender, EventArgs e)
        {
            string id = maskedTextBox1.Text;
            string pw = maskedTextBox2.Text;
            
            User_Manager.Load(id);//ID 조회
            try
            {
                if(User_Manager.users.Count>0)
                {
                    User_Manager.users.Single(x => x.user_passWord == pw); //id로 load했으므로 한 칸 짜리 list가 있거나 혹은 0칸짜리(아이디가 없을 경우)
                    Dispose();
                }
                else
                {
                    MessageBox.Show(id+"은/는 없는 아이디입니다.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("로그인 실패.", "LOGIN");
            }
            //if (maskedTextBox2.Text != "")
            //{
            //    if (id.Equals("admin") && pw.Equals("1234"))
            //    {
            //        MessageBox.Show("로그인에 성공했습니다.", "LOGIN");
            //        Dispose();
            //    }
            //    else
            //        MessageBox.Show("로그인 실패.", "LOGIN");
            //}
        }

        private void label5_Click(object sender, EventArgs e)
        {
            new sign_up().ShowDialog();
        }

        //일부러 꺼버렸을 때 뒤에 창 나오는 거 방지
        private void Login_up_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
                Application.Exit();
        }
    }
}
