﻿using CSharp_teamProject.Admin;
using System;
using System.Windows.Forms;

namespace CSharp_teamProject
{
    public partial class sign_up : Form
    {
        public sign_up()
        {
            InitializeComponent();
        }

        private void btn_Register_Click(object sender, System.EventArgs e)
        {
            //MessageBox.Show("가입 기능 미구현");
            if (txt_ID.Text.Trim() == "")
                MessageBox.Show("아이디를 입력해주세요");
            else if (txt_PW.Text.Trim() == "")
                MessageBox.Show("비밀번호를 입력해주세요.");
            else
                try
                {
                    User_Helper.insertQuery(txt_ID.Text, txt_PW.Text, txt_Name.Text, txt_Phone.Text,txt_Email.Text);
                    string contents = $"회원 {txt_ID.Text} 을/를 등록 하였습니다.";
                    //WriteLog(contents);
                    MessageBox.Show(contents);
                    //User_Manager.Load(txt_ID.Text);
                }
                catch (Exception)
                {
                    MessageBox.Show($"회원 {txt_ID.Text} 을/를 등록하지 못했습니다.");
                    //WriteLog($"회원 {user_id_box.Text} 을/를 등록하지 못했습니다.");
                }
        }
    }
}
