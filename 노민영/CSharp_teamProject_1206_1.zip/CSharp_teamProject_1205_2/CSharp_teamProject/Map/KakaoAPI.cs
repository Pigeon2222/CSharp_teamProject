﻿using System.Net;

namespace CSharp_teamProject.Map
{
    public class KakaoAPI
    {
        public static Locale SearchClick(string text)
        {
            Locale hotel = new Locale();
            string site = "https://dapi.kakao.com/v2/local/search/keyword.json";
            string query = $"{site}?query={text}";
            string restApiKey = "b6cdd3240cfda6158e35e52008661839";
            string Header = $"KakaoAK {restApiKey}";

            WebRequest request = WebRequest.Create(query);
            request.Headers.Add("Authorization", Header);

            /*
            // 응답받기
            WebResponse response = request.GetResponse();
            Stream stream = response.GetResponseStream();
            StreamReader reader = new StreamReader(stream, Encoding.UTF8);
            string json = reader.ReadToEnd();
            JavaScriptSerializer js = new JavaScriptSerializer();
            dynamic dob = js.Deserialize<dynamic>(json);
            dynamic docs = dob["documents"];
            object[] buf = docs;
            int length = buf.Length;
            for (int i = 0; i < length; i++)
            {
                string lname = docs[i]["place_name"];
                if(lname == text)
                {
                    double x = double.Parse(docs[i]["x"]);
                    double y = double.Parse(docs[i]["y"]);
                    hotel.Lat = y;
                    hotel.Lng = x;
                }
            }
            */
            return hotel;
        }
    }
}
