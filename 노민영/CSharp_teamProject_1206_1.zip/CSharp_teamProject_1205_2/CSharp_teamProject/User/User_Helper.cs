﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace CSharp_teamProject
{
    public class User_Helper
    {
        private static SqlConnection conn = new SqlConnection();
        public static SqlDataAdapter da;
        public static DataSet ds;
        public static DataTable dt;

        public static void ConnectDB()
        {
            string dataSource = "local";
            string db = "HHDB";
            string security = "SSPI";
            conn.ConnectionString = string.Format
                ("Data Source=({0}); initial Catalog={1};" +
                "integrated Security={2};" +
                "Timeout=3", dataSource, db, security);
            conn = new SqlConnection(conn.ConnectionString);
            conn.Open();
        }

        public static void selectQuery(string user_id = "")
        {
            try
            {
                ConnectDB();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                if (user_id == "")
                    cmd.CommandText = "select * from user_table";
                else
                    cmd.CommandText = "select * from user_table where user_id like '%" + user_id + "%'";
                da = new SqlDataAdapter(cmd);
                ds = new DataSet();
                da.Fill(ds, "Admin_Manager");
                dt = ds.Tables[0];
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message + "select");
                User_Manager.printLog("select" + e.StackTrace);
                return;
            }
            finally
            {
                conn.Close();
            }
        }

        public static void updateQuery(string user_id, string user_passWord, string user_name, string user_phoneNum, string user_email)
        {
            try
            {
                ConnectDB();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                string sqlcommand = "";
                sqlcommand = "update user_table set user_passWord='@p2', user_name='@p3', user_phoneNum='@p4', user_email='@p5' where user_id='@p1'";
                cmd.Parameters.AddWithValue("@p1", user_id);
                cmd.Parameters.AddWithValue("@p2", user_passWord);
                cmd.Parameters.AddWithValue("@p3", user_name);
                cmd.Parameters.AddWithValue("@p4", user_phoneNum);
                cmd.Parameters.AddWithValue("@p5", user_email);
                cmd.Parameters.AddWithValue("@p6", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"));
                cmd.CommandText = sqlcommand;
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show("update" + e.Message);
                User_Manager.printLog("update" + e.StackTrace);
            }
            finally
            {
                conn.Close();
            }
        }

        public static void deleteQuery(string user_id, string user_passWord)
        {
            try
            {
                ConnectDB();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                string sqlcommand = "";
                sqlcommand = "delete user_table where user_id='@p1' and user_passWord='@p2'";
                cmd.Parameters.AddWithValue("@p1", user_id);
                cmd.Parameters.AddWithValue("@p2", user_passWord);
                cmd.CommandText = sqlcommand;
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show("delete" + e.Message);
                User_Manager.printLog("delete" + e.StackTrace);
            }
            finally
            {
                conn.Close();
            }
        }

        public static void insertQuery(string user_id, string user_passWord, string user_name, string user_phoneNum, string user_email)
        {
            try
            {
                ConnectDB();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                string sqlcommand = "";
                sqlcommand = "insert into user_table(user_id, user_passWord, user_name, user_phoneNum, user_email) values (@p1, @p2, @p3, @p4, @p5)";
                cmd.Parameters.AddWithValue("@p1", user_id);
                cmd.Parameters.AddWithValue("@p2", user_passWord);
                cmd.Parameters.AddWithValue("@p3", user_name);
                cmd.Parameters.AddWithValue("@p4", user_phoneNum);
                cmd.Parameters.AddWithValue("@p5", user_email);
                cmd.Parameters.AddWithValue("@p6", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"));
                cmd.CommandText = sqlcommand;
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show("insert" + e.Message);
                User_Manager.printLog("insert" + e.StackTrace);
            }
            finally
            {
                conn.Close();
            }
        }
    }
}
