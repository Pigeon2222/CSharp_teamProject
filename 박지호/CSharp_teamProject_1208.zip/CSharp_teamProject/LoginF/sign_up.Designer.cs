﻿namespace CSharp_teamProject
{
    partial class sign_up
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(sign_up));
            this.Signup_label6 = new System.Windows.Forms.Label();
            this.txt_Email = new System.Windows.Forms.TextBox();
            this.Signup_label1 = new System.Windows.Forms.Label();
            this.Signup_label5 = new System.Windows.Forms.Label();
            this.Signup_label4 = new System.Windows.Forms.Label();
            this.Signup_label3 = new System.Windows.Forms.Label();
            this.btn_Register = new System.Windows.Forms.Button();
            this.txt_Phone = new System.Windows.Forms.TextBox();
            this.txt_Name = new System.Windows.Forms.TextBox();
            this.txt_PW = new System.Windows.Forms.TextBox();
            this.txt_ID = new System.Windows.Forms.TextBox();
            this.Signup_label2 = new System.Windows.Forms.Label();
            this.Signup_button1 = new System.Windows.Forms.Button();
            this.Signup_button2 = new System.Windows.Forms.Button();
            this.Signup_button4 = new System.Windows.Forms.Button();
            this.Signup_button3 = new System.Windows.Forms.Button();
            this.Signup_label7 = new System.Windows.Forms.Label();
            this.Signup_button5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Signup_label6
            // 
            this.Signup_label6.AutoSize = true;
            this.Signup_label6.BackColor = System.Drawing.Color.Transparent;
            this.Signup_label6.Font = new System.Drawing.Font("Georgia", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Signup_label6.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Signup_label6.Location = new System.Drawing.Point(234, 315);
            this.Signup_label6.Name = "Signup_label6";
            this.Signup_label6.Size = new System.Drawing.Size(73, 27);
            this.Signup_label6.TabIndex = 45;
            this.Signup_label6.Text = "Email";
            // 
            // txt_Email
            // 
            this.txt_Email.Location = new System.Drawing.Point(350, 312);
            this.txt_Email.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_Email.Name = "txt_Email";
            this.txt_Email.Size = new System.Drawing.Size(229, 25);
            this.txt_Email.TabIndex = 37;
            // 
            // Signup_label1
            // 
            this.Signup_label1.AutoSize = true;
            this.Signup_label1.BackColor = System.Drawing.Color.Transparent;
            this.Signup_label1.Font = new System.Drawing.Font("Georgia", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Signup_label1.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Signup_label1.Location = new System.Drawing.Point(363, 60);
            this.Signup_label1.Name = "Signup_label1";
            this.Signup_label1.Size = new System.Drawing.Size(202, 54);
            this.Signup_label1.TabIndex = 43;
            this.Signup_label1.Text = "Sign   up";
            // 
            // Signup_label5
            // 
            this.Signup_label5.AutoSize = true;
            this.Signup_label5.BackColor = System.Drawing.Color.Transparent;
            this.Signup_label5.Font = new System.Drawing.Font("Georgia", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Signup_label5.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Signup_label5.Location = new System.Drawing.Point(233, 279);
            this.Signup_label5.Name = "Signup_label5";
            this.Signup_label5.Size = new System.Drawing.Size(77, 27);
            this.Signup_label5.TabIndex = 42;
            this.Signup_label5.Text = "Phone";
            // 
            // Signup_label4
            // 
            this.Signup_label4.AutoSize = true;
            this.Signup_label4.BackColor = System.Drawing.Color.Transparent;
            this.Signup_label4.Font = new System.Drawing.Font("Georgia", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Signup_label4.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Signup_label4.Location = new System.Drawing.Point(235, 242);
            this.Signup_label4.Name = "Signup_label4";
            this.Signup_label4.Size = new System.Drawing.Size(73, 27);
            this.Signup_label4.TabIndex = 40;
            this.Signup_label4.Text = "Name";
            // 
            // Signup_label3
            // 
            this.Signup_label3.AutoSize = true;
            this.Signup_label3.BackColor = System.Drawing.Color.Transparent;
            this.Signup_label3.Font = new System.Drawing.Font("Georgia", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Signup_label3.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Signup_label3.Location = new System.Drawing.Point(247, 204);
            this.Signup_label3.Name = "Signup_label3";
            this.Signup_label3.Size = new System.Drawing.Size(48, 27);
            this.Signup_label3.TabIndex = 39;
            this.Signup_label3.Text = "PW";
            // 
            // btn_Register
            // 
            this.btn_Register.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Register.BackgroundImage")));
            this.btn_Register.FlatAppearance.BorderSize = 0;
            this.btn_Register.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Register.Font = new System.Drawing.Font("Georgia", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Register.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_Register.Location = new System.Drawing.Point(345, 361);
            this.btn_Register.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Register.Name = "btn_Register";
            this.btn_Register.Size = new System.Drawing.Size(234, 82);
            this.btn_Register.TabIndex = 38;
            this.btn_Register.Text = "Sign up";
            this.btn_Register.UseVisualStyleBackColor = true;
            this.btn_Register.Click += new System.EventHandler(this.btn_Register_Click);
            // 
            // txt_Phone
            // 
            this.txt_Phone.Location = new System.Drawing.Point(350, 276);
            this.txt_Phone.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_Phone.Name = "txt_Phone";
            this.txt_Phone.Size = new System.Drawing.Size(229, 25);
            this.txt_Phone.TabIndex = 36;
            // 
            // txt_Name
            // 
            this.txt_Name.Location = new System.Drawing.Point(351, 241);
            this.txt_Name.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_Name.Name = "txt_Name";
            this.txt_Name.Size = new System.Drawing.Size(227, 25);
            this.txt_Name.TabIndex = 35;
            // 
            // txt_PW
            // 
            this.txt_PW.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_PW.Location = new System.Drawing.Point(351, 205);
            this.txt_PW.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_PW.Name = "txt_PW";
            this.txt_PW.PasswordChar = '*';
            this.txt_PW.Size = new System.Drawing.Size(228, 25);
            this.txt_PW.TabIndex = 34;
            this.txt_PW.UseSystemPasswordChar = true;
            // 
            // txt_ID
            // 
            this.txt_ID.Location = new System.Drawing.Point(351, 168);
            this.txt_ID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_ID.Name = "txt_ID";
            this.txt_ID.Size = new System.Drawing.Size(228, 25);
            this.txt_ID.TabIndex = 33;
            // 
            // Signup_label2
            // 
            this.Signup_label2.AutoSize = true;
            this.Signup_label2.BackColor = System.Drawing.Color.Transparent;
            this.Signup_label2.Font = new System.Drawing.Font("Georgia", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Signup_label2.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Signup_label2.Location = new System.Drawing.Point(253, 168);
            this.Signup_label2.Name = "Signup_label2";
            this.Signup_label2.Size = new System.Drawing.Size(38, 27);
            this.Signup_label2.TabIndex = 32;
            this.Signup_label2.Text = "ID";
            // 
            // Signup_button1
            // 
            this.Signup_button1.BackColor = System.Drawing.Color.Transparent;
            this.Signup_button1.FlatAppearance.BorderSize = 0;
            this.Signup_button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Signup_button1.Image = ((System.Drawing.Image)(resources.GetObject("Signup_button1.Image")));
            this.Signup_button1.Location = new System.Drawing.Point(12, 11);
            this.Signup_button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Signup_button1.Name = "Signup_button1";
            this.Signup_button1.Size = new System.Drawing.Size(48, 53);
            this.Signup_button1.TabIndex = 48;
            this.Signup_button1.UseVisualStyleBackColor = false;
            this.Signup_button1.Click += new System.EventHandler(this.Signup_button1_Click);
            // 
            // Signup_button2
            // 
            this.Signup_button2.BackColor = System.Drawing.Color.Transparent;
            this.Signup_button2.FlatAppearance.BorderSize = 0;
            this.Signup_button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Signup_button2.Image = ((System.Drawing.Image)(resources.GetObject("Signup_button2.Image")));
            this.Signup_button2.Location = new System.Drawing.Point(327, 518);
            this.Signup_button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Signup_button2.Name = "Signup_button2";
            this.Signup_button2.Size = new System.Drawing.Size(63, 56);
            this.Signup_button2.TabIndex = 47;
            this.Signup_button2.UseVisualStyleBackColor = false;
            this.Signup_button2.Click += new System.EventHandler(this.Signup_button2_Click);
            // 
            // Signup_button4
            // 
            this.Signup_button4.BackColor = System.Drawing.Color.Transparent;
            this.Signup_button4.FlatAppearance.BorderSize = 0;
            this.Signup_button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Signup_button4.Image = ((System.Drawing.Image)(resources.GetObject("Signup_button4.Image")));
            this.Signup_button4.Location = new System.Drawing.Point(472, 518);
            this.Signup_button4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Signup_button4.Name = "Signup_button4";
            this.Signup_button4.Size = new System.Drawing.Size(60, 53);
            this.Signup_button4.TabIndex = 49;
            this.Signup_button4.UseVisualStyleBackColor = false;
            this.Signup_button4.Click += new System.EventHandler(this.Signup_button4_Click);
            // 
            // Signup_button3
            // 
            this.Signup_button3.BackColor = System.Drawing.Color.Transparent;
            this.Signup_button3.FlatAppearance.BorderSize = 0;
            this.Signup_button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Signup_button3.Image = ((System.Drawing.Image)(resources.GetObject("Signup_button3.Image")));
            this.Signup_button3.Location = new System.Drawing.Point(398, 519);
            this.Signup_button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Signup_button3.Name = "Signup_button3";
            this.Signup_button3.Size = new System.Drawing.Size(70, 54);
            this.Signup_button3.TabIndex = 46;
            this.Signup_button3.UseVisualStyleBackColor = false;
            this.Signup_button3.Click += new System.EventHandler(this.Signup_button3_Click);
            // 
            // Signup_label7
            // 
            this.Signup_label7.AutoSize = true;
            this.Signup_label7.BackColor = System.Drawing.Color.Transparent;
            this.Signup_label7.Font = new System.Drawing.Font("Georgia", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Signup_label7.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Signup_label7.Location = new System.Drawing.Point(291, 482);
            this.Signup_label7.Name = "Signup_label7";
            this.Signup_label7.Size = new System.Drawing.Size(342, 27);
            this.Signup_label7.TabIndex = 50;
            this.Signup_label7.Text = "Or Sign up with social platforms";
            // 
            // Signup_button5
            // 
            this.Signup_button5.BackColor = System.Drawing.Color.Transparent;
            this.Signup_button5.FlatAppearance.BorderSize = 0;
            this.Signup_button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Signup_button5.Image = ((System.Drawing.Image)(resources.GetObject("Signup_button5.Image")));
            this.Signup_button5.Location = new System.Drawing.Point(541, 518);
            this.Signup_button5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Signup_button5.Name = "Signup_button5";
            this.Signup_button5.Size = new System.Drawing.Size(60, 53);
            this.Signup_button5.TabIndex = 51;
            this.Signup_button5.UseVisualStyleBackColor = false;
            this.Signup_button5.Click += new System.EventHandler(this.Signup_button5_Click);
            // 
            // sign_up
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(916, 597);
            this.Controls.Add(this.Signup_button5);
            this.Controls.Add(this.Signup_label7);
            this.Controls.Add(this.Signup_button1);
            this.Controls.Add(this.Signup_button2);
            this.Controls.Add(this.Signup_button4);
            this.Controls.Add(this.Signup_button3);
            this.Controls.Add(this.Signup_label6);
            this.Controls.Add(this.txt_Email);
            this.Controls.Add(this.Signup_label1);
            this.Controls.Add(this.Signup_label5);
            this.Controls.Add(this.Signup_label4);
            this.Controls.Add(this.Signup_label3);
            this.Controls.Add(this.btn_Register);
            this.Controls.Add(this.txt_Phone);
            this.Controls.Add(this.txt_Name);
            this.Controls.Add(this.txt_PW);
            this.Controls.Add(this.txt_ID);
            this.Controls.Add(this.Signup_label2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "sign_up";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "sign_up";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.sign_up_KeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Signup_label6;
        private System.Windows.Forms.TextBox txt_Email;
        private System.Windows.Forms.Label Signup_label1;
        private System.Windows.Forms.Label Signup_label5;
        private System.Windows.Forms.Label Signup_label4;
        private System.Windows.Forms.Label Signup_label3;
        private System.Windows.Forms.Button btn_Register;
        private System.Windows.Forms.TextBox txt_Phone;
        private System.Windows.Forms.TextBox txt_Name;
        private System.Windows.Forms.TextBox txt_PW;
        private System.Windows.Forms.TextBox txt_ID;
        private System.Windows.Forms.Label Signup_label2;
        private System.Windows.Forms.Button Signup_button1;
        private System.Windows.Forms.Button Signup_button2;
        private System.Windows.Forms.Button Signup_button4;
        private System.Windows.Forms.Button Signup_button3;
        private System.Windows.Forms.Label Signup_label7;
        private System.Windows.Forms.Button Signup_button5;
    }
}