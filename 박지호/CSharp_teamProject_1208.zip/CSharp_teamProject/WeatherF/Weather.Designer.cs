﻿namespace CSharp_teamProject
{
    partial class Weather
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Weather));
            this.weather_button13 = new System.Windows.Forms.Button();
            this.weather_button14 = new System.Windows.Forms.Button();
            this.weather_button15 = new System.Windows.Forms.Button();
            this.weather_button16 = new System.Windows.Forms.Button();
            this.weather_button12 = new System.Windows.Forms.Button();
            this.weather_button7 = new System.Windows.Forms.Button();
            this.weather_button11 = new System.Windows.Forms.Button();
            this.weather_button10 = new System.Windows.Forms.Button();
            this.weather_button9 = new System.Windows.Forms.Button();
            this.weather_button8 = new System.Windows.Forms.Button();
            this.weather_button6 = new System.Windows.Forms.Button();
            this.weather_button5 = new System.Windows.Forms.Button();
            this.weather_button4 = new System.Windows.Forms.Button();
            this.weather_button3 = new System.Windows.Forms.Button();
            this.weather_label2 = new System.Windows.Forms.Label();
            this.weather_textBox2 = new System.Windows.Forms.TextBox();
            this.weather_button2 = new System.Windows.Forms.Button();
            this.weather_button1 = new System.Windows.Forms.Button();
            this.weather_label1 = new System.Windows.Forms.Label();
            this.weather_richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.weather_textBox1 = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Weather_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // weather_button13
            // 
            this.weather_button13.BackColor = System.Drawing.Color.White;
            this.weather_button13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("weather_button13.BackgroundImage")));
            this.weather_button13.FlatAppearance.BorderSize = 0;
            this.weather_button13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.weather_button13.Font = new System.Drawing.Font("한컴산뜻돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.weather_button13.Location = new System.Drawing.Point(411, 185);
            this.weather_button13.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.weather_button13.Name = "weather_button13";
            this.weather_button13.Size = new System.Drawing.Size(82, 72);
            this.weather_button13.TabIndex = 46;
            this.weather_button13.Text = "울산";
            this.weather_button13.UseVisualStyleBackColor = false;
            this.weather_button13.Click += new System.EventHandler(this.weather_button13_Click);
            // 
            // weather_button14
            // 
            this.weather_button14.BackColor = System.Drawing.Color.White;
            this.weather_button14.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("weather_button14.BackgroundImage")));
            this.weather_button14.FlatAppearance.BorderSize = 0;
            this.weather_button14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.weather_button14.Font = new System.Drawing.Font("한컴산뜻돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.weather_button14.Location = new System.Drawing.Point(516, 185);
            this.weather_button14.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.weather_button14.Name = "weather_button14";
            this.weather_button14.Size = new System.Drawing.Size(82, 72);
            this.weather_button14.TabIndex = 45;
            this.weather_button14.Text = "광주";
            this.weather_button14.UseVisualStyleBackColor = false;
            this.weather_button14.Click += new System.EventHandler(this.weather_button14_Click);
            // 
            // weather_button15
            // 
            this.weather_button15.BackColor = System.Drawing.Color.White;
            this.weather_button15.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("weather_button15.BackgroundImage")));
            this.weather_button15.FlatAppearance.BorderSize = 0;
            this.weather_button15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.weather_button15.Font = new System.Drawing.Font("한컴산뜻돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.weather_button15.Location = new System.Drawing.Point(621, 185);
            this.weather_button15.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.weather_button15.Name = "weather_button15";
            this.weather_button15.Size = new System.Drawing.Size(82, 72);
            this.weather_button15.TabIndex = 44;
            this.weather_button15.Text = "부산";
            this.weather_button15.UseVisualStyleBackColor = false;
            this.weather_button15.Click += new System.EventHandler(this.weather_button15_Click);
            // 
            // weather_button16
            // 
            this.weather_button16.BackColor = System.Drawing.Color.White;
            this.weather_button16.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("weather_button16.BackgroundImage")));
            this.weather_button16.FlatAppearance.BorderSize = 0;
            this.weather_button16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.weather_button16.Font = new System.Drawing.Font("한컴산뜻돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.weather_button16.Location = new System.Drawing.Point(724, 185);
            this.weather_button16.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.weather_button16.Name = "weather_button16";
            this.weather_button16.Size = new System.Drawing.Size(82, 72);
            this.weather_button16.TabIndex = 43;
            this.weather_button16.Text = "제주";
            this.weather_button16.UseVisualStyleBackColor = false;
            this.weather_button16.Click += new System.EventHandler(this.weather_button16_Click);
            // 
            // weather_button12
            // 
            this.weather_button12.BackColor = System.Drawing.Color.White;
            this.weather_button12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("weather_button12.BackgroundImage")));
            this.weather_button12.FlatAppearance.BorderSize = 0;
            this.weather_button12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.weather_button12.Font = new System.Drawing.Font("한컴산뜻돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.weather_button12.Location = new System.Drawing.Point(302, 185);
            this.weather_button12.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.weather_button12.Name = "weather_button12";
            this.weather_button12.Size = new System.Drawing.Size(82, 72);
            this.weather_button12.TabIndex = 42;
            this.weather_button12.Text = "창원";
            this.weather_button12.UseVisualStyleBackColor = false;
            this.weather_button12.Click += new System.EventHandler(this.weather_button12_Click);
            // 
            // weather_button7
            // 
            this.weather_button7.BackColor = System.Drawing.Color.White;
            this.weather_button7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("weather_button7.BackgroundImage")));
            this.weather_button7.FlatAppearance.BorderSize = 0;
            this.weather_button7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.weather_button7.Font = new System.Drawing.Font("한컴산뜻돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.weather_button7.Location = new System.Drawing.Point(516, 85);
            this.weather_button7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.weather_button7.Name = "weather_button7";
            this.weather_button7.Size = new System.Drawing.Size(82, 72);
            this.weather_button7.TabIndex = 41;
            this.weather_button7.Text = "울릉도";
            this.weather_button7.UseVisualStyleBackColor = false;
            this.weather_button7.Click += new System.EventHandler(this.weather_button7_Click);
            // 
            // weather_button11
            // 
            this.weather_button11.BackColor = System.Drawing.Color.White;
            this.weather_button11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("weather_button11.BackgroundImage")));
            this.weather_button11.FlatAppearance.BorderSize = 0;
            this.weather_button11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.weather_button11.Font = new System.Drawing.Font("한컴산뜻돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.weather_button11.Location = new System.Drawing.Point(192, 185);
            this.weather_button11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.weather_button11.Name = "weather_button11";
            this.weather_button11.Size = new System.Drawing.Size(82, 72);
            this.weather_button11.TabIndex = 40;
            this.weather_button11.Text = "전주";
            this.weather_button11.UseVisualStyleBackColor = false;
            this.weather_button11.Click += new System.EventHandler(this.weather_button11_Click);
            // 
            // weather_button10
            // 
            this.weather_button10.BackColor = System.Drawing.Color.White;
            this.weather_button10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("weather_button10.BackgroundImage")));
            this.weather_button10.FlatAppearance.BorderSize = 0;
            this.weather_button10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.weather_button10.Font = new System.Drawing.Font("한컴산뜻돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.weather_button10.Location = new System.Drawing.Point(84, 185);
            this.weather_button10.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.weather_button10.Name = "weather_button10";
            this.weather_button10.Size = new System.Drawing.Size(82, 72);
            this.weather_button10.TabIndex = 39;
            this.weather_button10.Text = "대구";
            this.weather_button10.UseVisualStyleBackColor = false;
            this.weather_button10.Click += new System.EventHandler(this.weather_button10_Click);
            // 
            // weather_button9
            // 
            this.weather_button9.BackColor = System.Drawing.Color.White;
            this.weather_button9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("weather_button9.BackgroundImage")));
            this.weather_button9.FlatAppearance.BorderSize = 0;
            this.weather_button9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.weather_button9.Font = new System.Drawing.Font("한컴산뜻돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.weather_button9.Location = new System.Drawing.Point(724, 85);
            this.weather_button9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.weather_button9.Name = "weather_button9";
            this.weather_button9.Size = new System.Drawing.Size(82, 72);
            this.weather_button9.TabIndex = 38;
            this.weather_button9.Text = "청주";
            this.weather_button9.UseVisualStyleBackColor = false;
            this.weather_button9.Click += new System.EventHandler(this.weather_button9_Click);
            // 
            // weather_button8
            // 
            this.weather_button8.BackColor = System.Drawing.Color.White;
            this.weather_button8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("weather_button8.BackgroundImage")));
            this.weather_button8.FlatAppearance.BorderSize = 0;
            this.weather_button8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.weather_button8.Font = new System.Drawing.Font("한컴산뜻돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.weather_button8.Location = new System.Drawing.Point(621, 85);
            this.weather_button8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.weather_button8.Name = "weather_button8";
            this.weather_button8.Size = new System.Drawing.Size(82, 72);
            this.weather_button8.TabIndex = 37;
            this.weather_button8.Text = "대전";
            this.weather_button8.UseVisualStyleBackColor = false;
            this.weather_button8.Click += new System.EventHandler(this.weather_button8_Click);
            // 
            // weather_button6
            // 
            this.weather_button6.BackColor = System.Drawing.Color.White;
            this.weather_button6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("weather_button6.BackgroundImage")));
            this.weather_button6.FlatAppearance.BorderSize = 0;
            this.weather_button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.weather_button6.Font = new System.Drawing.Font("한컴산뜻돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.weather_button6.Location = new System.Drawing.Point(411, 85);
            this.weather_button6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.weather_button6.Name = "weather_button6";
            this.weather_button6.Size = new System.Drawing.Size(82, 72);
            this.weather_button6.TabIndex = 36;
            this.weather_button6.Text = "강릉";
            this.weather_button6.UseVisualStyleBackColor = false;
            this.weather_button6.Click += new System.EventHandler(this.weather_button6_Click);
            // 
            // weather_button5
            // 
            this.weather_button5.BackColor = System.Drawing.Color.White;
            this.weather_button5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("weather_button5.BackgroundImage")));
            this.weather_button5.FlatAppearance.BorderSize = 0;
            this.weather_button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.weather_button5.Font = new System.Drawing.Font("한컴산뜻돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.weather_button5.Location = new System.Drawing.Point(302, 85);
            this.weather_button5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.weather_button5.Name = "weather_button5";
            this.weather_button5.Size = new System.Drawing.Size(82, 72);
            this.weather_button5.TabIndex = 35;
            this.weather_button5.Text = "춘천";
            this.weather_button5.UseVisualStyleBackColor = false;
            this.weather_button5.Click += new System.EventHandler(this.weather_button5_Click);
            // 
            // weather_button4
            // 
            this.weather_button4.BackColor = System.Drawing.Color.White;
            this.weather_button4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("weather_button4.BackgroundImage")));
            this.weather_button4.FlatAppearance.BorderSize = 0;
            this.weather_button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.weather_button4.Font = new System.Drawing.Font("한컴산뜻돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.weather_button4.Location = new System.Drawing.Point(191, 85);
            this.weather_button4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.weather_button4.Name = "weather_button4";
            this.weather_button4.Size = new System.Drawing.Size(82, 72);
            this.weather_button4.TabIndex = 34;
            this.weather_button4.Text = "인천";
            this.weather_button4.UseVisualStyleBackColor = false;
            this.weather_button4.Click += new System.EventHandler(this.weather_button4_Click_1);
            // 
            // weather_button3
            // 
            this.weather_button3.BackColor = System.Drawing.Color.White;
            this.weather_button3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("weather_button3.BackgroundImage")));
            this.weather_button3.FlatAppearance.BorderSize = 0;
            this.weather_button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.weather_button3.Font = new System.Drawing.Font("한컴산뜻돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.weather_button3.Location = new System.Drawing.Point(84, 85);
            this.weather_button3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.weather_button3.Name = "weather_button3";
            this.weather_button3.Size = new System.Drawing.Size(82, 72);
            this.weather_button3.TabIndex = 33;
            this.weather_button3.Text = "서울";
            this.weather_button3.UseVisualStyleBackColor = false;
            this.weather_button3.Click += new System.EventHandler(this.weather_button3_Click);
            // 
            // weather_label2
            // 
            this.weather_label2.AutoSize = true;
            this.weather_label2.BackColor = System.Drawing.Color.White;
            this.weather_label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.weather_label2.Font = new System.Drawing.Font("Fira Mono", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weather_label2.Location = new System.Drawing.Point(859, 181);
            this.weather_label2.Name = "weather_label2";
            this.weather_label2.Size = new System.Drawing.Size(48, 26);
            this.weather_label2.TabIndex = 32;
            this.weather_label2.Text = "Ion";
            // 
            // weather_textBox2
            // 
            this.weather_textBox2.Location = new System.Drawing.Point(914, 182);
            this.weather_textBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.weather_textBox2.Name = "weather_textBox2";
            this.weather_textBox2.Size = new System.Drawing.Size(114, 25);
            this.weather_textBox2.TabIndex = 31;
            // 
            // weather_button2
            // 
            this.weather_button2.BackColor = System.Drawing.Color.White;
            this.weather_button2.FlatAppearance.BorderSize = 0;
            this.weather_button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.weather_button2.Font = new System.Drawing.Font("함초롬돋움", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.weather_button2.Location = new System.Drawing.Point(865, 363);
            this.weather_button2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.weather_button2.Name = "weather_button2";
            this.weather_button2.Size = new System.Drawing.Size(163, 69);
            this.weather_button2.TabIndex = 30;
            this.weather_button2.Text = "주간날씨";
            this.weather_button2.UseVisualStyleBackColor = false;
            this.weather_button2.Click += new System.EventHandler(this.weather_button2_Click);
            // 
            // weather_button1
            // 
            this.weather_button1.BackColor = System.Drawing.Color.White;
            this.weather_button1.FlatAppearance.BorderSize = 0;
            this.weather_button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.weather_button1.Font = new System.Drawing.Font("함초롬돋움", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.weather_button1.Location = new System.Drawing.Point(865, 279);
            this.weather_button1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.weather_button1.Name = "weather_button1";
            this.weather_button1.Size = new System.Drawing.Size(163, 69);
            this.weather_button1.TabIndex = 29;
            this.weather_button1.Text = "현재날씨";
            this.weather_button1.UseVisualStyleBackColor = false;
            this.weather_button1.Click += new System.EventHandler(this.weather_button1_Click);
            // 
            // weather_label1
            // 
            this.weather_label1.AutoSize = true;
            this.weather_label1.BackColor = System.Drawing.Color.White;
            this.weather_label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.weather_label1.Font = new System.Drawing.Font("Fira Mono", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weather_label1.Location = new System.Drawing.Point(859, 131);
            this.weather_label1.Name = "weather_label1";
            this.weather_label1.Size = new System.Drawing.Size(48, 26);
            this.weather_label1.TabIndex = 28;
            this.weather_label1.Text = "Lat";
            // 
            // weather_richTextBox1
            // 
            this.weather_richTextBox1.Location = new System.Drawing.Point(84, 278);
            this.weather_richTextBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.weather_richTextBox1.Name = "weather_richTextBox1";
            this.weather_richTextBox1.Size = new System.Drawing.Size(722, 466);
            this.weather_richTextBox1.TabIndex = 27;
            this.weather_richTextBox1.Text = "";
            // 
            // weather_textBox1
            // 
            this.weather_textBox1.Location = new System.Drawing.Point(914, 132);
            this.weather_textBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.weather_textBox1.Name = "weather_textBox1";
            this.weather_textBox1.Size = new System.Drawing.Size(114, 25);
            this.weather_textBox1.TabIndex = 26;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1920, 1277);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 47;
            this.pictureBox1.TabStop = false;
            // 
            // Weather_dateTimePicker
            // 
            this.Weather_dateTimePicker.Font = new System.Drawing.Font("한컴 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Weather_dateTimePicker.Location = new System.Drawing.Point(84, 28);
            this.Weather_dateTimePicker.Name = "Weather_dateTimePicker";
            this.Weather_dateTimePicker.Size = new System.Drawing.Size(231, 30);
            this.Weather_dateTimePicker.TabIndex = 53;
            // 
            // Weather
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1125, 811);
            this.Controls.Add(this.Weather_dateTimePicker);
            this.Controls.Add(this.weather_button13);
            this.Controls.Add(this.weather_button14);
            this.Controls.Add(this.weather_button15);
            this.Controls.Add(this.weather_button16);
            this.Controls.Add(this.weather_button12);
            this.Controls.Add(this.weather_button7);
            this.Controls.Add(this.weather_button11);
            this.Controls.Add(this.weather_button10);
            this.Controls.Add(this.weather_button9);
            this.Controls.Add(this.weather_button8);
            this.Controls.Add(this.weather_button6);
            this.Controls.Add(this.weather_button5);
            this.Controls.Add(this.weather_button4);
            this.Controls.Add(this.weather_button3);
            this.Controls.Add(this.weather_label2);
            this.Controls.Add(this.weather_textBox2);
            this.Controls.Add(this.weather_button2);
            this.Controls.Add(this.weather_button1);
            this.Controls.Add(this.weather_label1);
            this.Controls.Add(this.weather_richTextBox1);
            this.Controls.Add(this.weather_textBox1);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Weather";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Weather";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Weather_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button weather_button13;
        private System.Windows.Forms.Button weather_button14;
        private System.Windows.Forms.Button weather_button15;
        private System.Windows.Forms.Button weather_button16;
        private System.Windows.Forms.Button weather_button12;
        private System.Windows.Forms.Button weather_button7;
        private System.Windows.Forms.Button weather_button11;
        private System.Windows.Forms.Button weather_button10;
        private System.Windows.Forms.Button weather_button9;
        private System.Windows.Forms.Button weather_button8;
        private System.Windows.Forms.Button weather_button6;
        private System.Windows.Forms.Button weather_button5;
        private System.Windows.Forms.Button weather_button4;
        private System.Windows.Forms.Button weather_button3;
        private System.Windows.Forms.Label weather_label2;
        private System.Windows.Forms.TextBox weather_textBox2;
        private System.Windows.Forms.Button weather_button2;
        private System.Windows.Forms.Button weather_button1;
        private System.Windows.Forms.Label weather_label1;
        private System.Windows.Forms.RichTextBox weather_richTextBox1;
        private System.Windows.Forms.TextBox weather_textBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DateTimePicker Weather_dateTimePicker;
    }
}