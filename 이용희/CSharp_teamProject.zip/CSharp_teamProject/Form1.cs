﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharp_teamProject
{
    public partial class Form1 : Form
    {
        List<String> a = new List<string>();
        List<String> b = new List<string>();
        List<String> c = new List<string>();

        public Form1()
        {
            InitializeComponent();

            StreamReader file = new StreamReader("숙박업.csv");
            DataTable table = new DataTable();
            while(!file.EndOfStream)
            {
                string line = file.ReadLine();
                string[] data = line.Split(',');
                table.Rows.Add(data[0],data[1],data[2],data[3], data[4], data[5], data[6], data[7]);
                a.Add(data[1]);
                b.Add(data[2]);
                c.Add(data[3]);
            }
            dataGridView1.DataSource = table;
        }



        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            
        }
    }
}
