﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Chart
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            // 여성 인원수
            chart1.Series[0].Points.Clear();
            chart1.Series[0].Points.AddXY(1, 17924);
            chart1.Series[0].Points.AddXY(2, 17325);
            chart1.Series[0].Points.AddXY(3, 13328);
            chart1.Series[0].Points.AddXY(4, 28987);
            chart1.Series[0].Points.AddXY(5, 20258);
            chart1.Series[0].Points.AddXY(6, 34785);
            chart1.Series[0].Points.AddXY(7, 52188);
            chart1.Series[0].Points.AddXY(8, 80549);
            chart1.Series[0].Points.AddXY(9, 98160);
            chart1.Series[0].Points.AddXY(10, 126434);
            chart1.Series[0].Points.AddXY(11, 139322);
            chart1.Series[0].Points.AddXY(12, 224985);
       
            // 남성 인원수
            chart1.Series[1].Points.Clear();
            chart1.Series[1].Points.AddXY(1, 36184);
            chart1.Series[1].Points.AddXY(2, 32854);
            chart1.Series[1].Points.AddXY(3, 28834);
            chart1.Series[1].Points.AddXY(4, 36184);
            chart1.Series[1].Points.AddXY(5, 37477);
            chart1.Series[1].Points.AddXY(6, 56183);
            chart1.Series[1].Points.AddXY(7, 82169);
            chart1.Series[1].Points.AddXY(8, 105712);
            chart1.Series[1].Points.AddXY(9, 121199);
            chart1.Series[1].Points.AddXY(10, 140007);
            chart1.Series[1].Points.AddXY(11, 154721);
            chart1.Series[1].Points.AddXY(12, 201483);
            
            // 남여 인원수 추세선
            chart1.Series[2].Points.Clear();
            chart1.Series[2].Points.AddXY(1, 54108);
            chart1.Series[2].Points.AddXY(2, 50179);
            chart1.Series[2].Points.AddXY(3, 42162);
            chart1.Series[2].Points.AddXY(4, 65171);
            chart1.Series[2].Points.AddXY(5, 57735);
            chart1.Series[2].Points.AddXY(6, 90968);
            chart1.Series[2].Points.AddXY(7, 134357);
            chart1.Series[2].Points.AddXY(8, 186261);
            chart1.Series[2].Points.AddXY(9, 219359);
            chart1.Series[2].Points.AddXY(10, 266441);
            chart1.Series[2].Points.AddXY(11, 294043);
            chart1.Series[2].Points.AddXY(12, 426468);

        }
    }
}
