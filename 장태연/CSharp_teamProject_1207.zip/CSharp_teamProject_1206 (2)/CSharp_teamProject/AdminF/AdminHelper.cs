﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace CSharp_teamProject
{
    
    public class AdminHelper : DBHelper
    {

        private static AdminHelper _instance;

        public static AdminHelper Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new AdminHelper();
                }
                return _instance;
            }
        }

        private AdminHelper()
        {
        }
        public override List<User> selectQuery(string user_id)
        {
            
            try
            {
                ConnectDB();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                if (user_id == "")
                {
                    UsersSelect.Clear();
                    cmd.CommandText = "select * from user_table";
                  

                    da = new SqlDataAdapter(cmd);
                    ds = new DataSet();
                    da.Fill(ds, "uesr_table");
                    dt = ds.Tables[0];

                    return UsersSelect;
                }
                
                else { 
                    cmd.CommandText = "select * from user_table where user_id like '%" + user_id + "%'";
                    Console.WriteLine("값있음");
                    SqlDataReader sdr = cmd.ExecuteReader();
                    
                    
                    while (sdr.Read())
                    {
                        User us = new User();
                        us.user_num = int.Parse(sdr["user_num"].ToString());
                        us.user_id = sdr["user_id"].ToString();
                        us.user_passWord = sdr["user_passWord"].ToString();
                        us.user_name = sdr["user_name"].ToString();
                        us.user_phoneNum = sdr["user_phoneNum"].ToString();
                        us.user_email = sdr["user_email"].ToString();
                        us.user_createTime = sdr["user_createTime"].ToString() == "" ?
                    new DateTime() :
                        DateTime.Parse(sdr["user_createTime"].ToString());

                        UsersSelect.Add(us);

                    }
                    return UsersSelect;
                }
               
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message + "select");
                AdminManager.Instance.printLog("select" + e.StackTrace);
                return UsersSelect;
            }
            finally
            {
                conn.Close();
            }
        }

        public override int updateQuery(string user_id, string user_passWord, string user_name, string user_phoneNum, string user_email)
        {
            try
            {
                ConnectDB();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                string sqlcommand = "";
                sqlcommand = "update user_table set user_name=@p3, user_phoneNum=@p4, user_email=@p5, user_createTime=@p6 where user_id=@p1 and user_passWord=@p2";
                cmd.Parameters.AddWithValue("@p1", user_id);
                cmd.Parameters.AddWithValue("@p2", user_passWord);
                cmd.Parameters.AddWithValue("@p3", user_name);
                cmd.Parameters.AddWithValue("@p4", user_phoneNum);
                cmd.Parameters.AddWithValue("@p5", user_email);
                cmd.Parameters.AddWithValue("@p6", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"));
                cmd.CommandText = sqlcommand;
                int result = cmd.ExecuteNonQuery();
                return result;
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show("update" + e.Message);
                AdminManager.Instance.printLog("update" + e.StackTrace);
                return -9;
            }
            finally
            {
                conn.Close();
            }
        }
        public override int deleteQuery(string user_id, string user_passWord)
        {
            try
            {
                ConnectDB();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                string sqlcommand = "";
                sqlcommand = "delete user_table where user_id=@p1 and user_passWord=@p2";
                cmd.Parameters.AddWithValue("@p1", user_id);
                cmd.Parameters.AddWithValue("@p2", user_passWord);
                cmd.CommandText = sqlcommand;
                int result = cmd.ExecuteNonQuery();
                return result;
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show("delete" + e.Message);
                AdminManager.Instance.printLog("delete" + e.StackTrace);
                return -9;
            }
            finally
            {
                conn.Close();
            }
        }

        public override int insertQuery(string user_id, string user_passWord, string user_name, string user_phoneNum, string user_email)
        {
            try
            {
                ConnectDB();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                string sqlcommand = "";
                sqlcommand = "insert into user_table(user_id, user_passWord, user_name, user_phoneNum, user_email) values (@p1, @p2, @p3, @p4, @p5)";
                cmd.Parameters.AddWithValue("@p1", user_id);
                cmd.Parameters.AddWithValue("@p2", user_passWord);
                cmd.Parameters.AddWithValue("@p3", user_name);
                cmd.Parameters.AddWithValue("@p4", user_phoneNum);
                cmd.Parameters.AddWithValue("@p5", user_email);
                cmd.Parameters.AddWithValue("@p6", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"));
                cmd.CommandText = sqlcommand;
                int result = cmd.ExecuteNonQuery();
                return result;
            }
            catch (Exception e)
            {
                
                return -9;
            }
            finally
            {
                conn.Close();
            }
        }
       
        
        public override string loginQuery(string user_id, string user_pw)
        {
            string result = "";
            try
            {
                ConnectDB();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select user_id, user_passWord from user_table where user_id = @p1 and user_passWord = @p2";
                cmd.Parameters.AddWithValue("@p1", user_id);
                cmd.Parameters.AddWithValue("@p2", user_pw);
                SqlDataReader sdr = cmd.ExecuteReader();

                if (sdr.Read())
                {
                    result = sdr["user_id"].ToString();
                }
              
                return result;
            }
            catch (Exception e)
            {

                return "";
            }
            finally
            {
                conn.Close();
            }
        }

        public override User MyPageSelect(string user_id)
        {
            User us = new User();
            try
            {
                ConnectDB(); //db 연결

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn; //어디에 커맨드 보낼지 지정

                cmd.CommandType = CommandType.Text;
                string sqlcommand = "";

                sqlcommand = "select * from user_table where user_id=@p1";
                cmd.Parameters.AddWithValue("@p1", user_id);
                cmd.CommandText = sqlcommand;

                SqlDataReader sdr = cmd.ExecuteReader();



                while (sdr.Read())
                {
                    us.user_name = sdr["user_name"].ToString();
                    us.user_id = sdr["user_id"].ToString();
                    us.user_phoneNum = sdr["user_phoneNum"].ToString();
                    us.user_email = sdr["user_email"].ToString();

                }
                return us;
            }
            catch (Exception e)
            {

                return us;
            }
            finally
            {
                conn.Close();
            }
        }

    }
}
