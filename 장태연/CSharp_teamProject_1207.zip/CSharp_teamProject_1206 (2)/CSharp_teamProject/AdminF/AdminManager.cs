﻿using System;
using System.Data;

namespace CSharp_teamProject
{
    public class AdminManager : DataManager
    {
        private static AdminManager _instance;

        public static AdminManager Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new AdminManager();
                    _instance.Load();
                }
                return _instance;
            }
        }

        private AdminManager()
        {
        }

        public override void Load(string user_id_box = "")
        {
            try
            {
                AdminHelper.Instance.selectQuery(user_id_box);
                Users.Clear();
                foreach (DataRow item in AdminHelper.Instance.dt.Rows)
                {
                    User temp = new User();
                    temp.user_num = int.Parse(item["user_num"].ToString());
                    temp.user_id = item["user_id"].ToString();
                    temp.user_passWord = item["user_passWord"].ToString();
                    temp.user_name = item["user_name"].ToString();
                    temp.user_phoneNum = item["user_phoneNum"].ToString();
                    temp.user_email = item["user_email"].ToString();
                    temp.user_createTime = item["user_createTime"].ToString() == "" ?
                    new DateTime():
                        DateTime.Parse(item["user_createTime"].ToString());
                    
                    Users.Add(temp);
                }
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message + "load");
                printLog(e.StackTrace + "load");
            }
        }

        public override string Load(string id, string pw)
        {
            string result = "";
            try
            {
                if(id == "admin" && pw == "1234")
                {
                    result = "admin";
                    return result;
                }
                else { 
                result = AdminHelper.Instance.loginQuery(id, pw);

                return result;
                }
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message + "load");
                printLog(e.StackTrace + "load");

                return "";
            }
        }
        public override User MypageLoad(string id)
        {

            User MyPageUser = AdminHelper.Instance.MyPageSelect(id);

            return MyPageUser;
        }

        public override void Save()
        {
            throw new System.NotImplementedException();
        }

      
    }
}
