﻿using System.Collections.Generic;
using System.IO;

namespace CSharp_teamProject
{
    public abstract class DataManager
    {
        public List<User> Users = new List<User>();
      
        public List<Hotel> Hotels = new List<Hotel>();

        public abstract void Load(string user_id_box = "");
        public abstract string Load(string id, string pw);
        //id값을 가져올 것
        public abstract User MypageLoad(string id);

        //public abstract void hotelInsert(string id);
        public abstract void Save();

        public void printLog(string contents)
        {
            DirectoryInfo di = new DirectoryInfo("Admin_History");
            if (di.Exists == false)
                di.Create();

            using (StreamWriter w = new StreamWriter("Admin_History\\Admin_History.txt", true))
            {
                w.WriteLine(contents);
            }
        }
    }
}
