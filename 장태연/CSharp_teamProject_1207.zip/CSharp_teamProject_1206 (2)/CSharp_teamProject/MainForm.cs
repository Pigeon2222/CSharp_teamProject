﻿using System;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace CSharp_teamProject
{
    public partial class MainForm : Form
    {
       // Login_up login = new Login_up();

        public MainForm()
        {

            InitializeComponent();


            this.KeyPreview = true;
            chart();
            new Login_up().ShowDialog();
            Console.WriteLine(Login_up.loginstatus);
            if (Login_up.loginstatus != "admin")
            {
                Mainbutton4.Text = "MyPage";
            }
            //textBox1 위에 키보드를 누르고 그 키가 올라올 때
            //이벤트 추가
            //람다 사용함
            //키가 엔터일 때, button1을 눌러준다.
            //사이드 버튼(움직일때마다 따라가는거)
            panel_side.Height = Mainbutton1.Height; //첫번째 버튼의 높이로 바꿈
            panel_side.Top = Mainbutton1.Top; //첫번째 버튼의 y값으로 바꿈.
                                              //FirstControl 로 만든 유저컨트롤을 맨 앞으로 보냄.

            //User user2 = Login_up.users1.Single(x => x.user_id==);
           
          
        }

        private void Mainbutton_x_Click(object sender, EventArgs e)
        {
            Dispose();
        }


        private void Mainbutton1_Click(object sender, EventArgs e)
        {
            panel_side.Height = Mainbutton1.Height; //첫번째 버튼의 높이로 바꿈
            panel_side.Top = Mainbutton1.Top; //첫번째 버튼의 y값으로 바꿈.
                                              //map 로 만든 유저컨트롤을 맨 앞으로 보냄.
                                              //map.BringToFront(); //맨 앞으로 보냄.
                                              // Application.OpenForms["Hotel"].Close();
        }

        private void Mainbutton2_Click(object sender, EventArgs e)
        {
            panel_side.Height = Mainbutton2.Height;
            panel_side.Top = Mainbutton2.Top;
            new Hotel_Form().ShowDialog();
        }

        private void Mainbutton3_Click(object sender, EventArgs e)
        {
            panel_side.Height = Mainbutton3.Height;
            panel_side.Top = Mainbutton3.Top;
            new Weather().ShowDialog();
        }

        private void Mainbutton4_Click(object sender, EventArgs e) //admin
        {
            panel_side.Height = Mainbutton4.Height;
            panel_side.Top = Mainbutton4.Top;
            if(Login_up.loginstatus=="admin")
            new Admin_Form().ShowDialog();
            else
                new MyPage().ShowDialog();
           
        }

        private void chart()
        {
            chart1.Titles.Add("국내 여행객");
            chart1.ChartAreas[0].AxisX.Title = "날짜";
            chart1.ChartAreas[0].AxisY.Title = "여행객 수";
            chart1.ChartAreas[0].AxisX.LabelStyle.Format = "yyyy-MM";
            chart1.ChartAreas[0].AxisX.Interval = 1;
            chart1.ChartAreas[0].AxisX.IntervalType = DateTimeIntervalType.Months;
            chart1.ChartAreas[0].AxisX.IntervalOffset = 1;
            chart1.ChartAreas[0].AxisX.LabelStyle.Angle = -45;

            var d = new DateTime(2021, 11, 1);
            // 여성 인원수
            chart1.Series[0].Points.Clear();
            chart1.Series[0].Points.AddXY(d, 17924);
            chart1.Series[0].Points.AddXY(d.AddMonths(1), 17325);
            chart1.Series[0].Points.AddXY(d.AddMonths(2), 13328);
            chart1.Series[0].Points.AddXY(d.AddMonths(3), 28987);
            chart1.Series[0].Points.AddXY(d.AddMonths(4), 20258);
            chart1.Series[0].Points.AddXY(d.AddMonths(5), 34785);
            chart1.Series[0].Points.AddXY(d.AddMonths(6), 52188);
            chart1.Series[0].Points.AddXY(d.AddMonths(7), 80549);
            chart1.Series[0].Points.AddXY(d.AddMonths(8), 98160);
            chart1.Series[0].Points.AddXY(d.AddMonths(9), 126434);
            chart1.Series[0].Points.AddXY(d.AddMonths(10), 139322);
            chart1.Series[0].Points.AddXY(d.AddMonths(11), 224985);

            chart1.Series[0].XValueType = ChartValueType.DateTime;


            // 남성 인원수
            chart1.Series[1].Points.Clear();
            chart1.Series[1].Points.AddXY(d, 36184);
            chart1.Series[1].Points.AddXY(d.AddMonths(1), 32854);
            chart1.Series[1].Points.AddXY(d.AddMonths(2), 28834);
            chart1.Series[1].Points.AddXY(d.AddMonths(3), 36184);
            chart1.Series[1].Points.AddXY(d.AddMonths(4), 37477);
            chart1.Series[1].Points.AddXY(d.AddMonths(5), 56183);
            chart1.Series[1].Points.AddXY(d.AddMonths(6), 82169);
            chart1.Series[1].Points.AddXY(d.AddMonths(7), 105712);
            chart1.Series[1].Points.AddXY(d.AddMonths(8), 121199);
            chart1.Series[1].Points.AddXY(d.AddMonths(9), 140007);
            chart1.Series[1].Points.AddXY(d.AddMonths(10), 154721);
            chart1.Series[1].Points.AddXY(d.AddMonths(11), 201483);

            chart1.Series[1].XValueType = ChartValueType.DateTime;

            // 남여 인원수 추세선
            chart1.Series[2].Points.Clear();
            chart1.Series[2].Points.AddXY(d, 54108);
            chart1.Series[2].Points.AddXY(d.AddMonths(1), 50179);
            chart1.Series[2].Points.AddXY(d.AddMonths(2), 42162);
            chart1.Series[2].Points.AddXY(d.AddMonths(3), 65171);
            chart1.Series[2].Points.AddXY(d.AddMonths(4), 57735);
            chart1.Series[2].Points.AddXY(d.AddMonths(5), 90968);
            chart1.Series[2].Points.AddXY(d.AddMonths(6), 134357);
            chart1.Series[2].Points.AddXY(d.AddMonths(7), 186261);
            chart1.Series[2].Points.AddXY(d.AddMonths(8), 219359);
            chart1.Series[2].Points.AddXY(d.AddMonths(9), 266441);
            chart1.Series[2].Points.AddXY(d.AddMonths(10), 294043);
            chart1.Series[2].Points.AddXY(d.AddMonths(11), 426468);

            chart1.Series[2].XValueType = ChartValueType.DateTime;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            main_timer.Text = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss");
        }

        private void MainForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
                this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new Login_up().ShowDialog();
        }
    }
}
