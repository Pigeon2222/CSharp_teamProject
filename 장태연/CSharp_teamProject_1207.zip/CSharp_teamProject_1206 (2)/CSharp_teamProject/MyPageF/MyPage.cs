﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharp_teamProject
{
    
    public partial class MyPage : Form
    {
        public static string myName;
     
            AdminManager adminmanager = AdminManager.Instance;
        public MyPage()

        {
            InitializeComponent();

            string myId = Login_up.loginstatus;

            User myUser = adminmanager.MypageLoad(myId);
            myName = myUser.user_name.ToString();



            MyPage_label5_2.Text = myUser.user_name.ToString();
            MyPage_label6_2.Text = myUser.user_id.ToString();
            MyPage_label7_2.Text = myUser.user_phoneNum.ToString();
            MyPage_label8_2.Text = myUser.user_email.ToString();
            
           

        }
    }
}
