﻿namespace CSharp_teamProject
{
    partial class Admin_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.data_box = new System.Windows.Forms.GroupBox();
            this.admin_datagridview = new System.Windows.Forms.DataGridView();
            this.user_phoneNum_label = new System.Windows.Forms.Label();
            this.user_name_label = new System.Windows.Forms.Label();
            this.user_passWord_label = new System.Windows.Forms.Label();
            this.user_id_label = new System.Windows.Forms.Label();
            this.user_name_box = new System.Windows.Forms.TextBox();
            this.user_phoneNum_box = new System.Windows.Forms.TextBox();
            this.user_passWord_box = new System.Windows.Forms.TextBox();
            this.user_create_button = new System.Windows.Forms.Button();
            this.log_box = new System.Windows.Forms.ListBox();
            this.user_id_box = new System.Windows.Forms.TextBox();
            this.user_box = new System.Windows.Forms.GroupBox();
            this.user_update_button = new System.Windows.Forms.Button();
            this.user_delete_button = new System.Windows.Forms.Button();
            this.user_email_label = new System.Windows.Forms.Label();
            this.user_email_box = new System.Windows.Forms.TextBox();
            this.user_search_button = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.hotel_search_button = new System.Windows.Forms.Button();
            this.hotel_name_box = new System.Windows.Forms.TextBox();
            this.hotel_create_button = new System.Windows.Forms.Button();
            this.hotel_phoneNum_box = new System.Windows.Forms.TextBox();
            this.hotel_zipCode_box = new System.Windows.Forms.TextBox();
            this.hotel_address_box = new System.Windows.Forms.TextBox();
            this.hotel_name_label = new System.Windows.Forms.Label();
            this.hotel_phoneNum_label = new System.Windows.Forms.Label();
            this.hotel_address_label = new System.Windows.Forms.Label();
            this.hotel_zipCode_label = new System.Windows.Forms.Label();
            this.hotel_coordinateX_box = new System.Windows.Forms.TextBox();
            this.hotel_coordinateX_label = new System.Windows.Forms.Label();
            this.hotel_delete_button = new System.Windows.Forms.Button();
            this.hotel_coordinateY_box = new System.Windows.Forms.TextBox();
            this.hotel_coordinateY_label = new System.Windows.Forms.Label();
            this.hotel_roomCount_box = new System.Windows.Forms.TextBox();
            this.hotel_roomCount_label = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.hotel_box = new System.Windows.Forms.GroupBox();
            this.data_box.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.admin_datagridview)).BeginInit();
            this.user_box.SuspendLayout();
            this.hotel_box.SuspendLayout();
            this.SuspendLayout();
            // 
            // data_box
            // 
            this.data_box.Controls.Add(this.admin_datagridview);
            this.data_box.Location = new System.Drawing.Point(7, 248);
            this.data_box.Name = "data_box";
            this.data_box.Size = new System.Drawing.Size(986, 273);
            this.data_box.TabIndex = 23;
            this.data_box.TabStop = false;
            this.data_box.Text = "정보";
            // 
            // admin_datagridview
            // 
            this.admin_datagridview.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.admin_datagridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.admin_datagridview.Location = new System.Drawing.Point(7, 28);
            this.admin_datagridview.Name = "admin_datagridview";
            this.admin_datagridview.RowTemplate.Height = 23;
            this.admin_datagridview.Size = new System.Drawing.Size(974, 248);
            this.admin_datagridview.TabIndex = 2;
            this.admin_datagridview.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.admin_datagridview_CellClick);
            // 
            // user_phoneNum_label
            // 
            this.user_phoneNum_label.AutoSize = true;
            this.user_phoneNum_label.Location = new System.Drawing.Point(3, 117);
            this.user_phoneNum_label.Name = "user_phoneNum_label";
            this.user_phoneNum_label.Size = new System.Drawing.Size(53, 12);
            this.user_phoneNum_label.TabIndex = 12;
            this.user_phoneNum_label.Text = "전화번호";
            // 
            // user_name_label
            // 
            this.user_name_label.AutoSize = true;
            this.user_name_label.Location = new System.Drawing.Point(3, 88);
            this.user_name_label.Name = "user_name_label";
            this.user_name_label.Size = new System.Drawing.Size(29, 12);
            this.user_name_label.TabIndex = 11;
            this.user_name_label.Text = "이름";
            // 
            // user_passWord_label
            // 
            this.user_passWord_label.AutoSize = true;
            this.user_passWord_label.Location = new System.Drawing.Point(3, 59);
            this.user_passWord_label.Name = "user_passWord_label";
            this.user_passWord_label.Size = new System.Drawing.Size(53, 12);
            this.user_passWord_label.TabIndex = 10;
            this.user_passWord_label.Text = "비밀번호";
            // 
            // user_id_label
            // 
            this.user_id_label.AutoSize = true;
            this.user_id_label.Location = new System.Drawing.Point(3, 30);
            this.user_id_label.Name = "user_id_label";
            this.user_id_label.Size = new System.Drawing.Size(41, 12);
            this.user_id_label.TabIndex = 9;
            this.user_id_label.Text = "아이디";
            // 
            // user_name_box
            // 
            this.user_name_box.Location = new System.Drawing.Point(66, 84);
            this.user_name_box.Name = "user_name_box";
            this.user_name_box.Size = new System.Drawing.Size(118, 21);
            this.user_name_box.TabIndex = 4;
            // 
            // user_phoneNum_box
            // 
            this.user_phoneNum_box.Location = new System.Drawing.Point(66, 113);
            this.user_phoneNum_box.Name = "user_phoneNum_box";
            this.user_phoneNum_box.Size = new System.Drawing.Size(118, 21);
            this.user_phoneNum_box.TabIndex = 5;
            // 
            // user_passWord_box
            // 
            this.user_passWord_box.Location = new System.Drawing.Point(66, 55);
            this.user_passWord_box.Name = "user_passWord_box";
            this.user_passWord_box.Size = new System.Drawing.Size(118, 21);
            this.user_passWord_box.TabIndex = 3;
            // 
            // user_create_button
            // 
            this.user_create_button.Location = new System.Drawing.Point(188, 54);
            this.user_create_button.Name = "user_create_button";
            this.user_create_button.Size = new System.Drawing.Size(52, 23);
            this.user_create_button.TabIndex = 8;
            this.user_create_button.Text = "추가";
            this.user_create_button.UseVisualStyleBackColor = true;
            this.user_create_button.Click += new System.EventHandler(this.user_create_button_Click);
            // 
            // log_box
            // 
            this.log_box.FormattingEnabled = true;
            this.log_box.ItemHeight = 12;
            this.log_box.Location = new System.Drawing.Point(14, 524);
            this.log_box.Name = "log_box";
            this.log_box.Size = new System.Drawing.Size(974, 148);
            this.log_box.TabIndex = 21;
            // 
            // user_id_box
            // 
            this.user_id_box.Location = new System.Drawing.Point(66, 26);
            this.user_id_box.Name = "user_id_box";
            this.user_id_box.Size = new System.Drawing.Size(118, 21);
            this.user_id_box.TabIndex = 2;
            // 
            // user_box
            // 
            this.user_box.Controls.Add(this.user_update_button);
            this.user_box.Controls.Add(this.user_delete_button);
            this.user_box.Controls.Add(this.user_email_label);
            this.user_box.Controls.Add(this.user_email_box);
            this.user_box.Controls.Add(this.user_phoneNum_label);
            this.user_box.Controls.Add(this.user_name_label);
            this.user_box.Controls.Add(this.user_passWord_label);
            this.user_box.Controls.Add(this.user_id_label);
            this.user_box.Controls.Add(this.user_name_box);
            this.user_box.Controls.Add(this.user_phoneNum_box);
            this.user_box.Controls.Add(this.user_passWord_box);
            this.user_box.Controls.Add(this.user_create_button);
            this.user_box.Controls.Add(this.user_id_box);
            this.user_box.Controls.Add(this.user_search_button);
            this.user_box.Location = new System.Drawing.Point(7, 24);
            this.user_box.Name = "user_box";
            this.user_box.Size = new System.Drawing.Size(482, 218);
            this.user_box.TabIndex = 22;
            this.user_box.TabStop = false;
            this.user_box.Text = "회원";
            // 
            // user_update_button
            // 
            this.user_update_button.Location = new System.Drawing.Point(188, 83);
            this.user_update_button.Name = "user_update_button";
            this.user_update_button.Size = new System.Drawing.Size(52, 23);
            this.user_update_button.TabIndex = 9;
            this.user_update_button.Text = "수정";
            this.user_update_button.UseVisualStyleBackColor = true;
            this.user_update_button.Click += new System.EventHandler(this.user_update_button_Click);
            // 
            // user_delete_button
            // 
            this.user_delete_button.Location = new System.Drawing.Point(188, 112);
            this.user_delete_button.Name = "user_delete_button";
            this.user_delete_button.Size = new System.Drawing.Size(52, 23);
            this.user_delete_button.TabIndex = 10;
            this.user_delete_button.Text = "삭제";
            this.user_delete_button.UseVisualStyleBackColor = true;
            this.user_delete_button.Click += new System.EventHandler(this.user_delete_button_Click);
            // 
            // user_email_label
            // 
            this.user_email_label.AutoSize = true;
            this.user_email_label.Location = new System.Drawing.Point(3, 146);
            this.user_email_label.Name = "user_email_label";
            this.user_email_label.Size = new System.Drawing.Size(41, 12);
            this.user_email_label.TabIndex = 14;
            this.user_email_label.Text = "이메일";
            // 
            // user_email_box
            // 
            this.user_email_box.Location = new System.Drawing.Point(66, 142);
            this.user_email_box.Name = "user_email_box";
            this.user_email_box.Size = new System.Drawing.Size(118, 21);
            this.user_email_box.TabIndex = 6;
            // 
            // user_search_button
            // 
            this.user_search_button.Location = new System.Drawing.Point(188, 25);
            this.user_search_button.Name = "user_search_button";
            this.user_search_button.Size = new System.Drawing.Size(52, 23);
            this.user_search_button.TabIndex = 7;
            this.user_search_button.Text = "조회";
            this.user_search_button.UseVisualStyleBackColor = true;
            this.user_search_button.Click += new System.EventHandler(this.user_search_button_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            // 
            // hotel_search_button
            // 
            this.hotel_search_button.Location = new System.Drawing.Point(188, 25);
            this.hotel_search_button.Name = "hotel_search_button";
            this.hotel_search_button.Size = new System.Drawing.Size(52, 23);
            this.hotel_search_button.TabIndex = 18;
            this.hotel_search_button.Text = "조회";
            this.hotel_search_button.UseVisualStyleBackColor = true;
            // 
            // hotel_name_box
            // 
            this.hotel_name_box.Location = new System.Drawing.Point(66, 25);
            this.hotel_name_box.Name = "hotel_name_box";
            this.hotel_name_box.Size = new System.Drawing.Size(118, 21);
            this.hotel_name_box.TabIndex = 11;
            // 
            // hotel_create_button
            // 
            this.hotel_create_button.Location = new System.Drawing.Point(188, 54);
            this.hotel_create_button.Name = "hotel_create_button";
            this.hotel_create_button.Size = new System.Drawing.Size(52, 23);
            this.hotel_create_button.TabIndex = 19;
            this.hotel_create_button.Text = "추가";
            this.hotel_create_button.UseVisualStyleBackColor = true;
            // 
            // hotel_phoneNum_box
            // 
            this.hotel_phoneNum_box.Location = new System.Drawing.Point(66, 54);
            this.hotel_phoneNum_box.Name = "hotel_phoneNum_box";
            this.hotel_phoneNum_box.Size = new System.Drawing.Size(118, 21);
            this.hotel_phoneNum_box.TabIndex = 12;
            // 
            // hotel_zipCode_box
            // 
            this.hotel_zipCode_box.Location = new System.Drawing.Point(66, 112);
            this.hotel_zipCode_box.Name = "hotel_zipCode_box";
            this.hotel_zipCode_box.Size = new System.Drawing.Size(118, 21);
            this.hotel_zipCode_box.TabIndex = 14;
            // 
            // hotel_address_box
            // 
            this.hotel_address_box.Location = new System.Drawing.Point(66, 83);
            this.hotel_address_box.Name = "hotel_address_box";
            this.hotel_address_box.Size = new System.Drawing.Size(118, 21);
            this.hotel_address_box.TabIndex = 13;
            // 
            // hotel_name_label
            // 
            this.hotel_name_label.AutoSize = true;
            this.hotel_name_label.Location = new System.Drawing.Point(3, 29);
            this.hotel_name_label.Name = "hotel_name_label";
            this.hotel_name_label.Size = new System.Drawing.Size(41, 12);
            this.hotel_name_label.TabIndex = 9;
            this.hotel_name_label.Text = "숙소명";
            // 
            // hotel_phoneNum_label
            // 
            this.hotel_phoneNum_label.AutoSize = true;
            this.hotel_phoneNum_label.Location = new System.Drawing.Point(3, 58);
            this.hotel_phoneNum_label.Name = "hotel_phoneNum_label";
            this.hotel_phoneNum_label.Size = new System.Drawing.Size(53, 12);
            this.hotel_phoneNum_label.TabIndex = 10;
            this.hotel_phoneNum_label.Text = "전화번호";
            // 
            // hotel_address_label
            // 
            this.hotel_address_label.AutoSize = true;
            this.hotel_address_label.Location = new System.Drawing.Point(3, 87);
            this.hotel_address_label.Name = "hotel_address_label";
            this.hotel_address_label.Size = new System.Drawing.Size(29, 12);
            this.hotel_address_label.TabIndex = 11;
            this.hotel_address_label.Text = "주소";
            // 
            // hotel_zipCode_label
            // 
            this.hotel_zipCode_label.AutoSize = true;
            this.hotel_zipCode_label.Location = new System.Drawing.Point(3, 116);
            this.hotel_zipCode_label.Name = "hotel_zipCode_label";
            this.hotel_zipCode_label.Size = new System.Drawing.Size(53, 12);
            this.hotel_zipCode_label.TabIndex = 12;
            this.hotel_zipCode_label.Text = "우편번호";
            // 
            // hotel_coordinateX_box
            // 
            this.hotel_coordinateX_box.Location = new System.Drawing.Point(66, 141);
            this.hotel_coordinateX_box.Name = "hotel_coordinateX_box";
            this.hotel_coordinateX_box.Size = new System.Drawing.Size(118, 21);
            this.hotel_coordinateX_box.TabIndex = 15;
            // 
            // hotel_coordinateX_label
            // 
            this.hotel_coordinateX_label.AutoSize = true;
            this.hotel_coordinateX_label.Location = new System.Drawing.Point(3, 145);
            this.hotel_coordinateX_label.Name = "hotel_coordinateX_label";
            this.hotel_coordinateX_label.Size = new System.Drawing.Size(37, 12);
            this.hotel_coordinateX_label.TabIndex = 14;
            this.hotel_coordinateX_label.Text = "X좌표";
            // 
            // hotel_delete_button
            // 
            this.hotel_delete_button.Location = new System.Drawing.Point(188, 83);
            this.hotel_delete_button.Name = "hotel_delete_button";
            this.hotel_delete_button.Size = new System.Drawing.Size(52, 23);
            this.hotel_delete_button.TabIndex = 20;
            this.hotel_delete_button.Text = "수정";
            this.hotel_delete_button.UseVisualStyleBackColor = true;
            // 
            // hotel_coordinateY_box
            // 
            this.hotel_coordinateY_box.Location = new System.Drawing.Point(66, 170);
            this.hotel_coordinateY_box.Name = "hotel_coordinateY_box";
            this.hotel_coordinateY_box.Size = new System.Drawing.Size(118, 21);
            this.hotel_coordinateY_box.TabIndex = 16;
            // 
            // hotel_coordinateY_label
            // 
            this.hotel_coordinateY_label.AutoSize = true;
            this.hotel_coordinateY_label.Location = new System.Drawing.Point(3, 174);
            this.hotel_coordinateY_label.Name = "hotel_coordinateY_label";
            this.hotel_coordinateY_label.Size = new System.Drawing.Size(37, 12);
            this.hotel_coordinateY_label.TabIndex = 17;
            this.hotel_coordinateY_label.Text = "Y좌표";
            // 
            // hotel_roomCount_box
            // 
            this.hotel_roomCount_box.Location = new System.Drawing.Point(66, 199);
            this.hotel_roomCount_box.Name = "hotel_roomCount_box";
            this.hotel_roomCount_box.Size = new System.Drawing.Size(118, 21);
            this.hotel_roomCount_box.TabIndex = 17;
            // 
            // hotel_roomCount_label
            // 
            this.hotel_roomCount_label.AutoSize = true;
            this.hotel_roomCount_label.Location = new System.Drawing.Point(3, 203);
            this.hotel_roomCount_label.Name = "hotel_roomCount_label";
            this.hotel_roomCount_label.Size = new System.Drawing.Size(41, 12);
            this.hotel_roomCount_label.TabIndex = 19;
            this.hotel_roomCount_label.Text = "객실수";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(188, 111);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(52, 23);
            this.button1.TabIndex = 21;
            this.button1.Text = "삭제";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // hotel_box
            // 
            this.hotel_box.Controls.Add(this.button1);
            this.hotel_box.Controls.Add(this.hotel_roomCount_label);
            this.hotel_box.Controls.Add(this.hotel_roomCount_box);
            this.hotel_box.Controls.Add(this.hotel_coordinateY_label);
            this.hotel_box.Controls.Add(this.hotel_coordinateY_box);
            this.hotel_box.Controls.Add(this.hotel_delete_button);
            this.hotel_box.Controls.Add(this.hotel_coordinateX_label);
            this.hotel_box.Controls.Add(this.hotel_coordinateX_box);
            this.hotel_box.Controls.Add(this.hotel_zipCode_label);
            this.hotel_box.Controls.Add(this.hotel_address_label);
            this.hotel_box.Controls.Add(this.hotel_phoneNum_label);
            this.hotel_box.Controls.Add(this.hotel_name_label);
            this.hotel_box.Controls.Add(this.hotel_address_box);
            this.hotel_box.Controls.Add(this.hotel_zipCode_box);
            this.hotel_box.Controls.Add(this.hotel_phoneNum_box);
            this.hotel_box.Controls.Add(this.hotel_create_button);
            this.hotel_box.Controls.Add(this.hotel_name_box);
            this.hotel_box.Controls.Add(this.hotel_search_button);
            this.hotel_box.Location = new System.Drawing.Point(503, 24);
            this.hotel_box.Name = "hotel_box";
            this.hotel_box.Size = new System.Drawing.Size(482, 218);
            this.hotel_box.TabIndex = 25;
            this.hotel_box.TabStop = false;
            this.hotel_box.Text = "숙소";
            // 
            // Admin_Form
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1000, 700);
            this.Controls.Add(this.hotel_box);
            this.Controls.Add(this.data_box);
            this.Controls.Add(this.log_box);
            this.Controls.Add(this.user_box);
            this.Name = "Admin_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin_Form";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Admin_Form_KeyDown);
            this.data_box.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.admin_datagridview)).EndInit();
            this.user_box.ResumeLayout(false);
            this.user_box.PerformLayout();
            this.hotel_box.ResumeLayout(false);
            this.hotel_box.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox data_box;
        private System.Windows.Forms.DataGridView admin_datagridview;
        private System.Windows.Forms.Label user_phoneNum_label;
        private System.Windows.Forms.Label user_name_label;
        private System.Windows.Forms.Label user_passWord_label;
        private System.Windows.Forms.Label user_id_label;
        private System.Windows.Forms.TextBox user_name_box;
        private System.Windows.Forms.TextBox user_phoneNum_box;
        private System.Windows.Forms.TextBox user_passWord_box;
        private System.Windows.Forms.Button user_create_button;
        private System.Windows.Forms.ListBox log_box;
        private System.Windows.Forms.TextBox user_id_box;
        private System.Windows.Forms.GroupBox user_box;
        private System.Windows.Forms.Button user_delete_button;
        private System.Windows.Forms.Label user_email_label;
        private System.Windows.Forms.TextBox user_email_box;
        private System.Windows.Forms.Button user_search_button;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button user_update_button;
        private System.Windows.Forms.Button hotel_search_button;
        private System.Windows.Forms.TextBox hotel_name_box;
        private System.Windows.Forms.Button hotel_create_button;
        private System.Windows.Forms.TextBox hotel_phoneNum_box;
        private System.Windows.Forms.TextBox hotel_zipCode_box;
        private System.Windows.Forms.TextBox hotel_address_box;
        private System.Windows.Forms.Label hotel_name_label;
        private System.Windows.Forms.Label hotel_phoneNum_label;
        private System.Windows.Forms.Label hotel_address_label;
        private System.Windows.Forms.Label hotel_zipCode_label;
        private System.Windows.Forms.TextBox hotel_coordinateX_box;
        private System.Windows.Forms.Label hotel_coordinateX_label;
        private System.Windows.Forms.Button hotel_delete_button;
        private System.Windows.Forms.TextBox hotel_coordinateY_box;
        private System.Windows.Forms.Label hotel_coordinateY_label;
        private System.Windows.Forms.TextBox hotel_roomCount_box;
        private System.Windows.Forms.Label hotel_roomCount_label;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox hotel_box;
    }
}