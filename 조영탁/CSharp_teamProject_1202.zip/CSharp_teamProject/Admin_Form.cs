﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace CSharp_teamProject
{
    public partial class W : UserControl
    {
        public W()
        {
            InitializeComponent();
            admin_timer.Text = DateTime.Now.ToString($"yyyy년 MM월 dd일 HH시 mm분 ss초");

            try
            {
                user_id_box.Text = Admin_Manager.users[0].user_id;
                user_passWord_box.Text = Admin_Manager.users[0].user_passWord;
                user_name_box.Text = Admin_Manager.users[0].user_name;
                user_phoneNum_box.Text = Admin_Manager.users[0].user_phoneNum;
                user_email_box.Text = Admin_Manager.users[0].user_email;
            }
            catch (Exception)
            {
            }
            if (Admin_Manager.users.Count > 0) // 길이가 0인데 DataSource로 넣으려고 하면 셀 선택시 오류나서 방지
                admin_datagridview.DataSource = Admin_Manager.users;
        }

        private void user_search_button_Click(object sender, EventArgs e)
        {

        }

        private void user_create_button_Click(object sender, EventArgs e)
        {
            if (user_id_box.Text.Trim() == "")
                MessageBox.Show("아이디를 입력해주세요");
            else if (user_passWord_box.Text.Trim() == "")
                MessageBox.Show("비밀번호를 입력해주세요.");
            else
                try
                {
                    user_add_delete(user_id_box.Text, user_passWord_box.Text, "insert");

                    User user = Admin_Manager.users.Single(x => x.user_id == user_id_box.Text);

                    user.user_id = user_id_box.Text;
                    user.user_passWord = user_passWord_box.Text;
                    user.user_name = user_name_box.Text;
                    user.user_phoneNum = user_phoneNum_box.Text;
                    user.user_email = user_email_box.Text;
                    user.user_createTime = DateTime.Now;

                    admin_datagridview.DataSource = null;
                    admin_datagridview.DataSource = Admin_Manager.users;

                    Admin_Manager.Save(user_id_box.Text, user_passWord_box.Text, user_name_box.Text, user_phoneNum_box.Text, user_email_box.Text);
                    string contents = $"회원 {user_id_box.Text} 을/를 등록 하였습니다.";
                    WriteLog(contents);
                    MessageBox.Show(contents);
                }
                catch (Exception)
                {
                    MessageBox.Show($"회원 {user_id_box.Text} 을/를 등록하지 못했습니다.");
                    WriteLog($"회원 {user_id_box.Text} 을/를 등록하지 못했습니다.");
                }
        }

        private void user_delete_button_Click(object sender, EventArgs e)
        {
            if (user_id_box.Text.Trim() == "")
                MessageBox.Show("아이디를 입력해주세요");
            else
                try
                {
                    User user = Admin_Manager.users.Single(x => x.user_id == user_id_box.Text);

                    string old_id = user.user_id;

                    user.user_id = "";
                    user.user_passWord = "";
                    user.user_name = "";
                    user.user_phoneNum = "";
                    user.user_email = "";
                    user.user_createTime = DateTime.Now;

                    admin_datagridview.DataSource = null;
                    admin_datagridview.DataSource = Admin_Manager.users;

                    Admin_Manager.Save(user_id_box.Text, user_passWord_box.Text, user_name_box.Text, user_phoneNum_box.Text, user_email_box.Text, true);
                    string contents = $"회원 {user_id_box.Text} 을/를 삭제 하였습니다.";
                    WriteLog(contents);
                    MessageBox.Show(contents);

                    user_add_delete(user_id_box.Text, user_passWord_box.Text, "delete");
                }
                catch (Exception)
                {
                    MessageBox.Show($"회원 {user_id_box.Text} 을/를 삭제하지 못했습니다.");
                    WriteLog($"회원 {user_id_box.Text} 을/를 삭제하지 못했습니다.");
                }
        }

        private void user_add_delete(string text1, string text2, string v)
        {
            string contents = "";
            bool check = Admin_Manager.Save(v, text1, text2, out contents);
            MessageBox.Show(contents);
            WriteLog(contents);
        }

        private string lookUp_user_id(string user_id)
        {
            string have_user_id = "";
            foreach (var item in Admin_Manager.users)
            {
                if (item.user_id == user_id)
                {
                    have_user_id = item.user_id;
                    break;
                }
            }
            return have_user_id;
        }

        // 전체 갱신
        private void reset()
        {
            Admin_Manager.Load();
            admin_datagridview.DataSource = null;
            if (Admin_Manager.users.Count > 0)
                admin_datagridview.DataSource = Admin_Manager.users;
        }

        private void WriteLog(string contents)
        {
            string log
                = $"[{DateTime.Now.ToString("yyyy/MM/dd hh:mm:ss")}]" + $"{contents}";
            Admin_Manager.printLog(log); // 파일에 적기
            log_box.Items.Insert(0, log); // 화면에 적기
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            admin_timer.Text = DateTime.Now.ToString($"yyyy년 MM월 dd일 HH시 mm분 ss초");
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            User user = admin_datagridview.CurrentRow.DataBoundItem as User;
            user_id_box.Text = user.user_id;
            user_passWord_box.Text = user.user_passWord;
            user_name_box.Text = user.user_name;
            user_phoneNum_box.Text = user.user_phoneNum;
            user_email_box.Text = user.user_email;
        }
    }
}
