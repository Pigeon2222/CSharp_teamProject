﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace CSharp_teamProject
{
    public class Admin_Helper
    {
        private static SqlConnection conn = new SqlConnection(); // db 연결
        public static SqlDataAdapter da; // db에 있는 데이터 가져옴
        public static DataSet ds;
        public static DataTable dt;

        public static void ConnectDB() // db 열어 crud 수행하고 닫음
        {
            string dataSource = "local";
            string db = "HHDB";
            string security = "SSPI";
            conn.ConnectionString = string.Format
                ("Data Source=({0}); initial Catalog={1};" +
                "integrated Security={2};" +
                "Timeout=3", dataSource, db, security); // 윈도우 기본 보안
            conn = new SqlConnection(conn.ConnectionString);
            conn.Open();
        }

        public static void selectQuery(string user_id = "") // 매개변수 없으면 -1
        {
            try
            {
                ConnectDB(); // DB 연결
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn; // 커맨드를 어디에 보낼지 지정
                if (user_id == "") // 전체 조회
                    cmd.CommandText = "select * from user_table";
                else // 특정 번호만 조회
                    cmd.CommandText = "select * from user_table " +
                    "where user_id=" + user_id;
                da = new SqlDataAdapter(cmd);
                ds = new DataSet();
                da.Fill(ds, "Admin_Manager");
                dt = ds.Tables[0]; // 여러 테이블이 선택되도 하나의 테이블만 선택
            }
            catch (Exception e)
            {

                System.Windows.Forms.MessageBox.Show(e.Message + "select");
                Admin_Manager.printLog("select" + e.StackTrace);
                return;
            }
            finally
            {
                conn.Close(); // db 연결 해제
            }
        }

        public static void updateQuery(string user_id, string user_passWord, string user_name, string user_phoneNum, string user_email, bool isRemove)
        {
            try
            {
                ConnectDB();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                string sqlcommand = "";
                if (isRemove)
                {
                    sqlcommand = "delete user_table where user_id=@p1";
                    cmd.Parameters.AddWithValue("@p1", user_id);
                }
                else
                {
                    sqlcommand = "update user_table set user_passWord=@p2, " +
                        "user_name=@p3, user_phoneNum=@p4, user_email=@p5, " +
                        "user_createTime=@6 where user_id=@p1";
                    cmd.Parameters.AddWithValue("@p1", user_id);
                    cmd.Parameters.AddWithValue("@p2", user_passWord);
                    cmd.Parameters.AddWithValue("@p3", user_name);
                    cmd.Parameters.AddWithValue("@p4", user_phoneNum);
                    cmd.Parameters.AddWithValue("@p5", user_email);
                    cmd.Parameters.AddWithValue("@p6", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"));
                }
                cmd.CommandText = sqlcommand;
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show("update" + e.Message);
                Admin_Manager.printLog("update" + e.StackTrace);
            }
            finally
            {
                conn.Close();
            }
        }

        private static void executeQuery(string user_id, string user_password, string command)
        {
            string sqlcommand = "";
            if (command == "insert")
                sqlcommand = "insert into user_table(user_id, user_password) values (@p1, @p2)";
            else
                sqlcommand = "delete from user_table where user_id=@p1";
            try
            {
                ConnectDB();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@p1", user_id);
                cmd.Parameters.AddWithValue("@p2", user_password);
                cmd.CommandText = sqlcommand;
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show("update" + e.Message);
                Admin_Manager.printLog("update" + e.StackTrace);
            }
            finally
            {
                conn.Close();
            }
        }

        public static void deleteQuery(string user_id, string user_password)
        {
            executeQuery(user_id, user_password, "delete");
        }

        public static void insertQuery(string user_id, string user_password)
        {
            executeQuery(user_id, user_password, "insert");
        }
    }
}
