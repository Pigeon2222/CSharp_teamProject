﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;

namespace CSharp_teamProject
{
    public class Admin_Manager
    {
        public static List<User> users = new List<User>();

        static Admin_Manager() // 정적 생성자, 데이터매니저에 접근할 때 딱 한번만 호출됨
        {
            Load();
        }
        public static void Load()
        {
            try
            {
                Admin_Helper.selectQuery();
                users.Clear();
                foreach (DataRow item in Admin_Helper.dt.Rows)
                {
                    User user1 = new User();
                    user1.user_id = item["user_id"].ToString();
                    user1.user_passWord = item["user_passWord"].ToString();
                    user1.user_name = item["user_name"].ToString();
                    user1.user_phoneNum = item["user_phoneNum"].ToString();
                    user1.user_email = item["user_email"].ToString();
                    user1.user_createTime = new DateTime();
                    users.Add(user1);
                }
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message + "load");
                printLog(e.StackTrace + "load");
            }
        }
        public static void printLog(string contents) // 파일에 내용 적음
        {
            DirectoryInfo di = new DirectoryInfo("Admin_History");
            if (di.Exists == false) // 폴더 없으면 폴더 생성
                di.Create();

            using (StreamWriter w = new StreamWriter("Admin_History\\Admin_History.txt", true))
            {
                w.WriteLine(contents); // 폴더에 글을 쓸 것, true는 append를 하여 새로운 내용을 뒤에 추가한다는 뜻
            }
        }

        public static void Save(string user_id, string user_passWord, string user_name, string user_phoneNum, string user_email, bool isRemove = false)
        {
            try
            {
                Admin_Helper.updateQuery(user_id, user_passWord, user_name, user_phoneNum, user_email, isRemove);
            }
            catch (Exception)
            {
                throw;
            }
        }

        // 주차 공간 추가 및 삭제용 save, 오버로딩함
        public static bool Save(string command, string user_id, string user_password, out string contents)
        {
            Admin_Helper.selectQuery(user_id);
            contents = ""; // out은 반드시 값을 대입해줘야함
            if (command == "insert")
                return DBInsert(user_id, user_password, ref contents); // ref는 참조값을 읽음
            else
                return DBDelete(user_id, user_password, ref contents);
        }

        // 공간 추가
        private static bool DBInsert(string user_id, string user_password, ref string contents)
        {
            if (Admin_Helper.dt.Rows.Count == 0)
            {
                Admin_Helper.insertQuery(user_id, user_password);
                contents = $"공간 추가 성공.";
                return true;
            }
            else
            {
                contents = $"공간 추가 실패.";
                return false;
            }
        }

        // 공간 삭제
        private static bool DBDelete(string user_id, string user_password, ref string contents)
        {
            if (Admin_Helper.dt.Rows.Count != 0)
            {
                Admin_Helper.deleteQuery(user_id, user_password);
                contents = $"공간 추가 성공.";
                return true;
            }
            else
            {
                contents = $"공간 추가 실패.";
                return false;
            }
        }
    }
}
