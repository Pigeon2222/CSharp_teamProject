﻿namespace CSharp_teamProject.Admin
{
    partial class Admin_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.hotel_roomCount_label = new System.Windows.Forms.Label();
            this.hotel_coordinateY_label = new System.Windows.Forms.Label();
            this.hotel_coordinateY_box = new System.Windows.Forms.TextBox();
            this.hotel_delete_button = new System.Windows.Forms.Button();
            this.hotel_coordinateX_label = new System.Windows.Forms.Label();
            this.hotel_coordinateX_box = new System.Windows.Forms.TextBox();
            this.hotel_zipCode_label = new System.Windows.Forms.Label();
            this.hotel_address_label = new System.Windows.Forms.Label();
            this.hotel_phoneNum_label = new System.Windows.Forms.Label();
            this.admin_delete_button = new System.Windows.Forms.Button();
            this.admin_email_box = new System.Windows.Forms.TextBox();
            this.admin_phoneNum_label = new System.Windows.Forms.Label();
            this.admin_name_label = new System.Windows.Forms.Label();
            this.admin_passWord_label = new System.Windows.Forms.Label();
            this.admin_id_label = new System.Windows.Forms.Label();
            this.admin_name_box = new System.Windows.Forms.TextBox();
            this.hotel_roomCount_box = new System.Windows.Forms.TextBox();
            this.admin_email_label = new System.Windows.Forms.Label();
            this.hotel_box = new System.Windows.Forms.GroupBox();
            this.hotel_name_label = new System.Windows.Forms.Label();
            this.hotel_address_box = new System.Windows.Forms.TextBox();
            this.hotel_zipCode_box = new System.Windows.Forms.TextBox();
            this.hotel_phoneNum_box = new System.Windows.Forms.TextBox();
            this.hotel_create_button = new System.Windows.Forms.Button();
            this.hotel_name_box = new System.Windows.Forms.TextBox();
            this.hotel_search_button = new System.Windows.Forms.Button();
            this.bus_delete_button = new System.Windows.Forms.Button();
            this.bus_endPoint_label = new System.Windows.Forms.Label();
            this.bus_endTime_box = new System.Windows.Forms.TextBox();
            this.bus_startPoint_label = new System.Windows.Forms.Label();
            this.bus_endTime_label = new System.Windows.Forms.Label();
            this.bus_startTime_label = new System.Windows.Forms.Label();
            this.bus_name_label = new System.Windows.Forms.Label();
            this.bus_endPoint_box = new System.Windows.Forms.TextBox();
            this.bus_startTime_box = new System.Windows.Forms.TextBox();
            this.bus_startPoint_box = new System.Windows.Forms.TextBox();
            this.bus_create_button = new System.Windows.Forms.Button();
            this.bus_search_button = new System.Windows.Forms.Button();
            this.bus_box = new System.Windows.Forms.GroupBox();
            this.bus_name_box = new System.Windows.Forms.TextBox();
            this.admin_phoneNum_box = new System.Windows.Forms.TextBox();
            this.data_box = new System.Windows.Forms.GroupBox();
            this.admin_datagridview = new System.Windows.Forms.DataGridView();
            this.userBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.user_phoneNum_label = new System.Windows.Forms.Label();
            this.user_name_label = new System.Windows.Forms.Label();
            this.user_passWord_label = new System.Windows.Forms.Label();
            this.user_id_label = new System.Windows.Forms.Label();
            this.user_name_box = new System.Windows.Forms.TextBox();
            this.user_phoneNum_box = new System.Windows.Forms.TextBox();
            this.user_passWord_box = new System.Windows.Forms.TextBox();
            this.user_create_button = new System.Windows.Forms.Button();
            this.log_box = new System.Windows.Forms.ListBox();
            this.admin_id_box = new System.Windows.Forms.TextBox();
            this.user_id_box = new System.Windows.Forms.TextBox();
            this.user_box = new System.Windows.Forms.GroupBox();
            this.user_delete_button = new System.Windows.Forms.Button();
            this.user_email_label = new System.Windows.Forms.Label();
            this.user_email_box = new System.Windows.Forms.TextBox();
            this.user_search_button = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.admin_box = new System.Windows.Forms.GroupBox();
            this.admin_passWord_box = new System.Windows.Forms.TextBox();
            this.admin_create_button = new System.Windows.Forms.Button();
            this.admin_search_button = new System.Windows.Forms.Button();
            this.admin_timer = new System.Windows.Forms.Label();
            this.hotel_box.SuspendLayout();
            this.bus_box.SuspendLayout();
            this.data_box.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.admin_datagridview)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userBindingSource)).BeginInit();
            this.user_box.SuspendLayout();
            this.admin_box.SuspendLayout();
            this.SuspendLayout();
            // 
            // hotel_roomCount_label
            // 
            this.hotel_roomCount_label.AutoSize = true;
            this.hotel_roomCount_label.Location = new System.Drawing.Point(4, 224);
            this.hotel_roomCount_label.Name = "hotel_roomCount_label";
            this.hotel_roomCount_label.Size = new System.Drawing.Size(41, 12);
            this.hotel_roomCount_label.TabIndex = 19;
            this.hotel_roomCount_label.Text = "객실수";
            // 
            // hotel_coordinateY_label
            // 
            this.hotel_coordinateY_label.AutoSize = true;
            this.hotel_coordinateY_label.Location = new System.Drawing.Point(4, 195);
            this.hotel_coordinateY_label.Name = "hotel_coordinateY_label";
            this.hotel_coordinateY_label.Size = new System.Drawing.Size(37, 12);
            this.hotel_coordinateY_label.TabIndex = 17;
            this.hotel_coordinateY_label.Text = "Y좌표";
            // 
            // hotel_coordinateY_box
            // 
            this.hotel_coordinateY_box.Location = new System.Drawing.Point(67, 191);
            this.hotel_coordinateY_box.Name = "hotel_coordinateY_box";
            this.hotel_coordinateY_box.Size = new System.Drawing.Size(118, 21);
            this.hotel_coordinateY_box.TabIndex = 16;
            // 
            // hotel_delete_button
            // 
            this.hotel_delete_button.Location = new System.Drawing.Point(189, 104);
            this.hotel_delete_button.Name = "hotel_delete_button";
            this.hotel_delete_button.Size = new System.Drawing.Size(52, 23);
            this.hotel_delete_button.TabIndex = 15;
            this.hotel_delete_button.Text = "삭제";
            this.hotel_delete_button.UseVisualStyleBackColor = true;
            // 
            // hotel_coordinateX_label
            // 
            this.hotel_coordinateX_label.AutoSize = true;
            this.hotel_coordinateX_label.Location = new System.Drawing.Point(4, 166);
            this.hotel_coordinateX_label.Name = "hotel_coordinateX_label";
            this.hotel_coordinateX_label.Size = new System.Drawing.Size(37, 12);
            this.hotel_coordinateX_label.TabIndex = 14;
            this.hotel_coordinateX_label.Text = "X좌표";
            // 
            // hotel_coordinateX_box
            // 
            this.hotel_coordinateX_box.Location = new System.Drawing.Point(67, 162);
            this.hotel_coordinateX_box.Name = "hotel_coordinateX_box";
            this.hotel_coordinateX_box.Size = new System.Drawing.Size(118, 21);
            this.hotel_coordinateX_box.TabIndex = 13;
            // 
            // hotel_zipCode_label
            // 
            this.hotel_zipCode_label.AutoSize = true;
            this.hotel_zipCode_label.Location = new System.Drawing.Point(4, 137);
            this.hotel_zipCode_label.Name = "hotel_zipCode_label";
            this.hotel_zipCode_label.Size = new System.Drawing.Size(53, 12);
            this.hotel_zipCode_label.TabIndex = 12;
            this.hotel_zipCode_label.Text = "우편번호";
            // 
            // hotel_address_label
            // 
            this.hotel_address_label.AutoSize = true;
            this.hotel_address_label.Location = new System.Drawing.Point(4, 108);
            this.hotel_address_label.Name = "hotel_address_label";
            this.hotel_address_label.Size = new System.Drawing.Size(29, 12);
            this.hotel_address_label.TabIndex = 11;
            this.hotel_address_label.Text = "주소";
            // 
            // hotel_phoneNum_label
            // 
            this.hotel_phoneNum_label.AutoSize = true;
            this.hotel_phoneNum_label.Location = new System.Drawing.Point(4, 79);
            this.hotel_phoneNum_label.Name = "hotel_phoneNum_label";
            this.hotel_phoneNum_label.Size = new System.Drawing.Size(53, 12);
            this.hotel_phoneNum_label.TabIndex = 10;
            this.hotel_phoneNum_label.Text = "전화번호";
            // 
            // admin_delete_button
            // 
            this.admin_delete_button.Location = new System.Drawing.Point(188, 104);
            this.admin_delete_button.Name = "admin_delete_button";
            this.admin_delete_button.Size = new System.Drawing.Size(52, 23);
            this.admin_delete_button.TabIndex = 15;
            this.admin_delete_button.Text = "삭제";
            this.admin_delete_button.UseVisualStyleBackColor = true;
            // 
            // admin_email_box
            // 
            this.admin_email_box.Location = new System.Drawing.Point(66, 163);
            this.admin_email_box.Name = "admin_email_box";
            this.admin_email_box.Size = new System.Drawing.Size(118, 21);
            this.admin_email_box.TabIndex = 13;
            // 
            // admin_phoneNum_label
            // 
            this.admin_phoneNum_label.AutoSize = true;
            this.admin_phoneNum_label.Location = new System.Drawing.Point(3, 138);
            this.admin_phoneNum_label.Name = "admin_phoneNum_label";
            this.admin_phoneNum_label.Size = new System.Drawing.Size(53, 12);
            this.admin_phoneNum_label.TabIndex = 12;
            this.admin_phoneNum_label.Text = "전화번호";
            // 
            // admin_name_label
            // 
            this.admin_name_label.AutoSize = true;
            this.admin_name_label.Location = new System.Drawing.Point(3, 109);
            this.admin_name_label.Name = "admin_name_label";
            this.admin_name_label.Size = new System.Drawing.Size(29, 12);
            this.admin_name_label.TabIndex = 11;
            this.admin_name_label.Text = "이름";
            // 
            // admin_passWord_label
            // 
            this.admin_passWord_label.AutoSize = true;
            this.admin_passWord_label.Location = new System.Drawing.Point(3, 80);
            this.admin_passWord_label.Name = "admin_passWord_label";
            this.admin_passWord_label.Size = new System.Drawing.Size(53, 12);
            this.admin_passWord_label.TabIndex = 10;
            this.admin_passWord_label.Text = "비밀번호";
            // 
            // admin_id_label
            // 
            this.admin_id_label.AutoSize = true;
            this.admin_id_label.Location = new System.Drawing.Point(3, 51);
            this.admin_id_label.Name = "admin_id_label";
            this.admin_id_label.Size = new System.Drawing.Size(41, 12);
            this.admin_id_label.TabIndex = 9;
            this.admin_id_label.Text = "아이디";
            // 
            // admin_name_box
            // 
            this.admin_name_box.Location = new System.Drawing.Point(66, 105);
            this.admin_name_box.Name = "admin_name_box";
            this.admin_name_box.Size = new System.Drawing.Size(118, 21);
            this.admin_name_box.TabIndex = 6;
            // 
            // hotel_roomCount_box
            // 
            this.hotel_roomCount_box.Location = new System.Drawing.Point(67, 220);
            this.hotel_roomCount_box.Name = "hotel_roomCount_box";
            this.hotel_roomCount_box.Size = new System.Drawing.Size(118, 21);
            this.hotel_roomCount_box.TabIndex = 18;
            // 
            // admin_email_label
            // 
            this.admin_email_label.AutoSize = true;
            this.admin_email_label.Location = new System.Drawing.Point(3, 167);
            this.admin_email_label.Name = "admin_email_label";
            this.admin_email_label.Size = new System.Drawing.Size(41, 12);
            this.admin_email_label.TabIndex = 14;
            this.admin_email_label.Text = "이메일";
            // 
            // hotel_box
            // 
            this.hotel_box.Controls.Add(this.hotel_roomCount_label);
            this.hotel_box.Controls.Add(this.hotel_roomCount_box);
            this.hotel_box.Controls.Add(this.hotel_coordinateY_label);
            this.hotel_box.Controls.Add(this.hotel_coordinateY_box);
            this.hotel_box.Controls.Add(this.hotel_delete_button);
            this.hotel_box.Controls.Add(this.hotel_coordinateX_label);
            this.hotel_box.Controls.Add(this.hotel_coordinateX_box);
            this.hotel_box.Controls.Add(this.hotel_zipCode_label);
            this.hotel_box.Controls.Add(this.hotel_address_label);
            this.hotel_box.Controls.Add(this.hotel_phoneNum_label);
            this.hotel_box.Controls.Add(this.hotel_name_label);
            this.hotel_box.Controls.Add(this.hotel_address_box);
            this.hotel_box.Controls.Add(this.hotel_zipCode_box);
            this.hotel_box.Controls.Add(this.hotel_phoneNum_box);
            this.hotel_box.Controls.Add(this.hotel_create_button);
            this.hotel_box.Controls.Add(this.hotel_name_box);
            this.hotel_box.Controls.Add(this.hotel_search_button);
            this.hotel_box.Location = new System.Drawing.Point(503, 33);
            this.hotel_box.Name = "hotel_box";
            this.hotel_box.Size = new System.Drawing.Size(242, 221);
            this.hotel_box.TabIndex = 25;
            this.hotel_box.TabStop = false;
            this.hotel_box.Text = "숙소";
            // 
            // hotel_name_label
            // 
            this.hotel_name_label.AutoSize = true;
            this.hotel_name_label.Location = new System.Drawing.Point(4, 50);
            this.hotel_name_label.Name = "hotel_name_label";
            this.hotel_name_label.Size = new System.Drawing.Size(41, 12);
            this.hotel_name_label.TabIndex = 9;
            this.hotel_name_label.Text = "숙소명";
            // 
            // hotel_address_box
            // 
            this.hotel_address_box.Location = new System.Drawing.Point(67, 104);
            this.hotel_address_box.Name = "hotel_address_box";
            this.hotel_address_box.Size = new System.Drawing.Size(118, 21);
            this.hotel_address_box.TabIndex = 6;
            // 
            // hotel_zipCode_box
            // 
            this.hotel_zipCode_box.Location = new System.Drawing.Point(67, 133);
            this.hotel_zipCode_box.Name = "hotel_zipCode_box";
            this.hotel_zipCode_box.Size = new System.Drawing.Size(118, 21);
            this.hotel_zipCode_box.TabIndex = 8;
            // 
            // hotel_phoneNum_box
            // 
            this.hotel_phoneNum_box.Location = new System.Drawing.Point(67, 75);
            this.hotel_phoneNum_box.Name = "hotel_phoneNum_box";
            this.hotel_phoneNum_box.Size = new System.Drawing.Size(118, 21);
            this.hotel_phoneNum_box.TabIndex = 4;
            // 
            // hotel_create_button
            // 
            this.hotel_create_button.Location = new System.Drawing.Point(189, 75);
            this.hotel_create_button.Name = "hotel_create_button";
            this.hotel_create_button.Size = new System.Drawing.Size(52, 23);
            this.hotel_create_button.TabIndex = 5;
            this.hotel_create_button.Text = "추가";
            this.hotel_create_button.UseVisualStyleBackColor = true;
            // 
            // hotel_name_box
            // 
            this.hotel_name_box.Location = new System.Drawing.Point(67, 46);
            this.hotel_name_box.Name = "hotel_name_box";
            this.hotel_name_box.Size = new System.Drawing.Size(118, 21);
            this.hotel_name_box.TabIndex = 2;
            // 
            // hotel_search_button
            // 
            this.hotel_search_button.Location = new System.Drawing.Point(189, 46);
            this.hotel_search_button.Name = "hotel_search_button";
            this.hotel_search_button.Size = new System.Drawing.Size(52, 23);
            this.hotel_search_button.TabIndex = 3;
            this.hotel_search_button.Text = "조회";
            this.hotel_search_button.UseVisualStyleBackColor = true;
            // 
            // bus_delete_button
            // 
            this.bus_delete_button.Location = new System.Drawing.Point(189, 104);
            this.bus_delete_button.Name = "bus_delete_button";
            this.bus_delete_button.Size = new System.Drawing.Size(52, 23);
            this.bus_delete_button.TabIndex = 15;
            this.bus_delete_button.Text = "삭제";
            this.bus_delete_button.UseVisualStyleBackColor = true;
            // 
            // bus_endPoint_label
            // 
            this.bus_endPoint_label.AutoSize = true;
            this.bus_endPoint_label.Location = new System.Drawing.Point(4, 166);
            this.bus_endPoint_label.Name = "bus_endPoint_label";
            this.bus_endPoint_label.Size = new System.Drawing.Size(53, 12);
            this.bus_endPoint_label.TabIndex = 14;
            this.bus_endPoint_label.Text = "도착시간";
            // 
            // bus_endTime_box
            // 
            this.bus_endTime_box.Location = new System.Drawing.Point(67, 162);
            this.bus_endTime_box.Name = "bus_endTime_box";
            this.bus_endTime_box.Size = new System.Drawing.Size(118, 21);
            this.bus_endTime_box.TabIndex = 13;
            // 
            // bus_startPoint_label
            // 
            this.bus_startPoint_label.AutoSize = true;
            this.bus_startPoint_label.Location = new System.Drawing.Point(4, 137);
            this.bus_startPoint_label.Name = "bus_startPoint_label";
            this.bus_startPoint_label.Size = new System.Drawing.Size(53, 12);
            this.bus_startPoint_label.TabIndex = 12;
            this.bus_startPoint_label.Text = "출발시간";
            // 
            // bus_endTime_label
            // 
            this.bus_endTime_label.AutoSize = true;
            this.bus_endTime_label.Location = new System.Drawing.Point(4, 108);
            this.bus_endTime_label.Name = "bus_endTime_label";
            this.bus_endTime_label.Size = new System.Drawing.Size(41, 12);
            this.bus_endTime_label.TabIndex = 11;
            this.bus_endTime_label.Text = "도착지";
            // 
            // bus_startTime_label
            // 
            this.bus_startTime_label.AutoSize = true;
            this.bus_startTime_label.Location = new System.Drawing.Point(4, 79);
            this.bus_startTime_label.Name = "bus_startTime_label";
            this.bus_startTime_label.Size = new System.Drawing.Size(41, 12);
            this.bus_startTime_label.TabIndex = 10;
            this.bus_startTime_label.Text = "출발지";
            // 
            // bus_name_label
            // 
            this.bus_name_label.AutoSize = true;
            this.bus_name_label.Location = new System.Drawing.Point(4, 50);
            this.bus_name_label.Name = "bus_name_label";
            this.bus_name_label.Size = new System.Drawing.Size(41, 12);
            this.bus_name_label.TabIndex = 9;
            this.bus_name_label.Text = "버스명";
            // 
            // bus_endPoint_box
            // 
            this.bus_endPoint_box.Location = new System.Drawing.Point(67, 104);
            this.bus_endPoint_box.Name = "bus_endPoint_box";
            this.bus_endPoint_box.Size = new System.Drawing.Size(118, 21);
            this.bus_endPoint_box.TabIndex = 6;
            // 
            // bus_startTime_box
            // 
            this.bus_startTime_box.Location = new System.Drawing.Point(67, 133);
            this.bus_startTime_box.Name = "bus_startTime_box";
            this.bus_startTime_box.Size = new System.Drawing.Size(118, 21);
            this.bus_startTime_box.TabIndex = 8;
            // 
            // bus_startPoint_box
            // 
            this.bus_startPoint_box.Location = new System.Drawing.Point(67, 75);
            this.bus_startPoint_box.Name = "bus_startPoint_box";
            this.bus_startPoint_box.Size = new System.Drawing.Size(118, 21);
            this.bus_startPoint_box.TabIndex = 4;
            // 
            // bus_create_button
            // 
            this.bus_create_button.Location = new System.Drawing.Point(189, 75);
            this.bus_create_button.Name = "bus_create_button";
            this.bus_create_button.Size = new System.Drawing.Size(52, 23);
            this.bus_create_button.TabIndex = 5;
            this.bus_create_button.Text = "추가";
            this.bus_create_button.UseVisualStyleBackColor = true;
            // 
            // bus_search_button
            // 
            this.bus_search_button.Location = new System.Drawing.Point(189, 46);
            this.bus_search_button.Name = "bus_search_button";
            this.bus_search_button.Size = new System.Drawing.Size(52, 23);
            this.bus_search_button.TabIndex = 3;
            this.bus_search_button.Text = "조회";
            this.bus_search_button.UseVisualStyleBackColor = true;
            // 
            // bus_box
            // 
            this.bus_box.Controls.Add(this.bus_delete_button);
            this.bus_box.Controls.Add(this.bus_endPoint_label);
            this.bus_box.Controls.Add(this.bus_endTime_box);
            this.bus_box.Controls.Add(this.bus_startPoint_label);
            this.bus_box.Controls.Add(this.bus_endTime_label);
            this.bus_box.Controls.Add(this.bus_startTime_label);
            this.bus_box.Controls.Add(this.bus_name_label);
            this.bus_box.Controls.Add(this.bus_endPoint_box);
            this.bus_box.Controls.Add(this.bus_startTime_box);
            this.bus_box.Controls.Add(this.bus_startPoint_box);
            this.bus_box.Controls.Add(this.bus_create_button);
            this.bus_box.Controls.Add(this.bus_name_box);
            this.bus_box.Controls.Add(this.bus_search_button);
            this.bus_box.Location = new System.Drawing.Point(751, 33);
            this.bus_box.Name = "bus_box";
            this.bus_box.Size = new System.Drawing.Size(242, 221);
            this.bus_box.TabIndex = 26;
            this.bus_box.TabStop = false;
            this.bus_box.Text = "버스";
            // 
            // bus_name_box
            // 
            this.bus_name_box.Location = new System.Drawing.Point(67, 46);
            this.bus_name_box.Name = "bus_name_box";
            this.bus_name_box.Size = new System.Drawing.Size(118, 21);
            this.bus_name_box.TabIndex = 2;
            // 
            // admin_phoneNum_box
            // 
            this.admin_phoneNum_box.Location = new System.Drawing.Point(66, 134);
            this.admin_phoneNum_box.Name = "admin_phoneNum_box";
            this.admin_phoneNum_box.Size = new System.Drawing.Size(118, 21);
            this.admin_phoneNum_box.TabIndex = 8;
            // 
            // data_box
            // 
            this.data_box.Controls.Add(this.admin_datagridview);
            this.data_box.Location = new System.Drawing.Point(7, 260);
            this.data_box.Name = "data_box";
            this.data_box.Size = new System.Drawing.Size(986, 270);
            this.data_box.TabIndex = 23;
            this.data_box.TabStop = false;
            this.data_box.Text = "정보";
            // 
            // admin_datagridview
            // 
            this.admin_datagridview.AutoGenerateColumns = false;
            this.admin_datagridview.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.admin_datagridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.admin_datagridview.DataSource = this.userBindingSource;
            this.admin_datagridview.Location = new System.Drawing.Point(12, 64);
            this.admin_datagridview.Name = "admin_datagridview";
            this.admin_datagridview.RowTemplate.Height = 23;
            this.admin_datagridview.Size = new System.Drawing.Size(974, 248);
            this.admin_datagridview.TabIndex = 2;
            // 
            // user_phoneNum_label
            // 
            this.user_phoneNum_label.AutoSize = true;
            this.user_phoneNum_label.Location = new System.Drawing.Point(3, 139);
            this.user_phoneNum_label.Name = "user_phoneNum_label";
            this.user_phoneNum_label.Size = new System.Drawing.Size(53, 12);
            this.user_phoneNum_label.TabIndex = 12;
            this.user_phoneNum_label.Text = "전화번호";
            // 
            // user_name_label
            // 
            this.user_name_label.AutoSize = true;
            this.user_name_label.Location = new System.Drawing.Point(3, 110);
            this.user_name_label.Name = "user_name_label";
            this.user_name_label.Size = new System.Drawing.Size(29, 12);
            this.user_name_label.TabIndex = 11;
            this.user_name_label.Text = "이름";
            // 
            // user_passWord_label
            // 
            this.user_passWord_label.AutoSize = true;
            this.user_passWord_label.Location = new System.Drawing.Point(3, 81);
            this.user_passWord_label.Name = "user_passWord_label";
            this.user_passWord_label.Size = new System.Drawing.Size(53, 12);
            this.user_passWord_label.TabIndex = 10;
            this.user_passWord_label.Text = "비밀번호";
            // 
            // user_id_label
            // 
            this.user_id_label.AutoSize = true;
            this.user_id_label.Location = new System.Drawing.Point(3, 52);
            this.user_id_label.Name = "user_id_label";
            this.user_id_label.Size = new System.Drawing.Size(41, 12);
            this.user_id_label.TabIndex = 9;
            this.user_id_label.Text = "아이디";
            // 
            // user_name_box
            // 
            this.user_name_box.Location = new System.Drawing.Point(66, 106);
            this.user_name_box.Name = "user_name_box";
            this.user_name_box.Size = new System.Drawing.Size(118, 21);
            this.user_name_box.TabIndex = 6;
            // 
            // user_phoneNum_box
            // 
            this.user_phoneNum_box.Location = new System.Drawing.Point(66, 135);
            this.user_phoneNum_box.Name = "user_phoneNum_box";
            this.user_phoneNum_box.Size = new System.Drawing.Size(118, 21);
            this.user_phoneNum_box.TabIndex = 8;
            // 
            // user_passWord_box
            // 
            this.user_passWord_box.Location = new System.Drawing.Point(66, 77);
            this.user_passWord_box.Name = "user_passWord_box";
            this.user_passWord_box.Size = new System.Drawing.Size(118, 21);
            this.user_passWord_box.TabIndex = 4;
            // 
            // user_create_button
            // 
            this.user_create_button.Location = new System.Drawing.Point(188, 76);
            this.user_create_button.Name = "user_create_button";
            this.user_create_button.Size = new System.Drawing.Size(52, 23);
            this.user_create_button.TabIndex = 5;
            this.user_create_button.Text = "추가";
            this.user_create_button.UseVisualStyleBackColor = true;
            // 
            // log_box
            // 
            this.log_box.FormattingEnabled = true;
            this.log_box.ItemHeight = 12;
            this.log_box.Location = new System.Drawing.Point(7, 536);
            this.log_box.Name = "log_box";
            this.log_box.Size = new System.Drawing.Size(986, 112);
            this.log_box.TabIndex = 21;
            // 
            // admin_id_box
            // 
            this.admin_id_box.Location = new System.Drawing.Point(66, 47);
            this.admin_id_box.Name = "admin_id_box";
            this.admin_id_box.Size = new System.Drawing.Size(118, 21);
            this.admin_id_box.TabIndex = 2;
            // 
            // user_id_box
            // 
            this.user_id_box.Location = new System.Drawing.Point(66, 48);
            this.user_id_box.Name = "user_id_box";
            this.user_id_box.Size = new System.Drawing.Size(118, 21);
            this.user_id_box.TabIndex = 2;
            // 
            // user_box
            // 
            this.user_box.Controls.Add(this.user_delete_button);
            this.user_box.Controls.Add(this.user_email_label);
            this.user_box.Controls.Add(this.user_email_box);
            this.user_box.Controls.Add(this.user_phoneNum_label);
            this.user_box.Controls.Add(this.user_name_label);
            this.user_box.Controls.Add(this.user_passWord_label);
            this.user_box.Controls.Add(this.user_id_label);
            this.user_box.Controls.Add(this.user_name_box);
            this.user_box.Controls.Add(this.user_phoneNum_box);
            this.user_box.Controls.Add(this.user_passWord_box);
            this.user_box.Controls.Add(this.user_create_button);
            this.user_box.Controls.Add(this.user_id_box);
            this.user_box.Controls.Add(this.user_search_button);
            this.user_box.Location = new System.Drawing.Point(7, 33);
            this.user_box.Name = "user_box";
            this.user_box.Size = new System.Drawing.Size(242, 221);
            this.user_box.TabIndex = 22;
            this.user_box.TabStop = false;
            this.user_box.Text = "회원";
            // 
            // user_delete_button
            // 
            this.user_delete_button.Location = new System.Drawing.Point(188, 105);
            this.user_delete_button.Name = "user_delete_button";
            this.user_delete_button.Size = new System.Drawing.Size(52, 23);
            this.user_delete_button.TabIndex = 15;
            this.user_delete_button.Text = "삭제";
            this.user_delete_button.UseVisualStyleBackColor = true;
            // 
            // user_email_label
            // 
            this.user_email_label.AutoSize = true;
            this.user_email_label.Location = new System.Drawing.Point(3, 168);
            this.user_email_label.Name = "user_email_label";
            this.user_email_label.Size = new System.Drawing.Size(41, 12);
            this.user_email_label.TabIndex = 14;
            this.user_email_label.Text = "이메일";
            // 
            // user_email_box
            // 
            this.user_email_box.Location = new System.Drawing.Point(66, 164);
            this.user_email_box.Name = "user_email_box";
            this.user_email_box.Size = new System.Drawing.Size(118, 21);
            this.user_email_box.TabIndex = 13;
            // 
            // user_search_button
            // 
            this.user_search_button.Location = new System.Drawing.Point(188, 47);
            this.user_search_button.Name = "user_search_button";
            this.user_search_button.Size = new System.Drawing.Size(52, 23);
            this.user_search_button.TabIndex = 3;
            this.user_search_button.Text = "조회";
            this.user_search_button.UseVisualStyleBackColor = true;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            // 
            // admin_box
            // 
            this.admin_box.Controls.Add(this.admin_delete_button);
            this.admin_box.Controls.Add(this.admin_email_label);
            this.admin_box.Controls.Add(this.admin_email_box);
            this.admin_box.Controls.Add(this.admin_phoneNum_label);
            this.admin_box.Controls.Add(this.admin_name_label);
            this.admin_box.Controls.Add(this.admin_passWord_label);
            this.admin_box.Controls.Add(this.admin_id_label);
            this.admin_box.Controls.Add(this.admin_name_box);
            this.admin_box.Controls.Add(this.admin_phoneNum_box);
            this.admin_box.Controls.Add(this.admin_passWord_box);
            this.admin_box.Controls.Add(this.admin_create_button);
            this.admin_box.Controls.Add(this.admin_id_box);
            this.admin_box.Controls.Add(this.admin_search_button);
            this.admin_box.Location = new System.Drawing.Point(255, 33);
            this.admin_box.Name = "admin_box";
            this.admin_box.Size = new System.Drawing.Size(242, 221);
            this.admin_box.TabIndex = 27;
            this.admin_box.TabStop = false;
            this.admin_box.Text = "관리자";
            // 
            // admin_passWord_box
            // 
            this.admin_passWord_box.Location = new System.Drawing.Point(66, 76);
            this.admin_passWord_box.Name = "admin_passWord_box";
            this.admin_passWord_box.Size = new System.Drawing.Size(118, 21);
            this.admin_passWord_box.TabIndex = 4;
            // 
            // admin_create_button
            // 
            this.admin_create_button.Location = new System.Drawing.Point(188, 75);
            this.admin_create_button.Name = "admin_create_button";
            this.admin_create_button.Size = new System.Drawing.Size(52, 23);
            this.admin_create_button.TabIndex = 5;
            this.admin_create_button.Text = "추가";
            this.admin_create_button.UseVisualStyleBackColor = true;
            // 
            // admin_search_button
            // 
            this.admin_search_button.Location = new System.Drawing.Point(188, 46);
            this.admin_search_button.Name = "admin_search_button";
            this.admin_search_button.Size = new System.Drawing.Size(52, 23);
            this.admin_search_button.TabIndex = 3;
            this.admin_search_button.Text = "조회";
            this.admin_search_button.UseVisualStyleBackColor = true;
            // 
            // admin_timer
            // 
            this.admin_timer.AutoSize = true;
            this.admin_timer.Location = new System.Drawing.Point(10, 655);
            this.admin_timer.Name = "admin_timer";
            this.admin_timer.Size = new System.Drawing.Size(74, 12);
            this.admin_timer.TabIndex = 24;
            this.admin_timer.Text = "admin_timer";
            // 
            // Admin_Form
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1000, 700);
            this.Controls.Add(this.hotel_box);
            this.Controls.Add(this.bus_box);
            this.Controls.Add(this.data_box);
            this.Controls.Add(this.log_box);
            this.Controls.Add(this.user_box);
            this.Controls.Add(this.admin_box);
            this.Controls.Add(this.admin_timer);
            this.Name = "Admin_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin_Form";
            this.hotel_box.ResumeLayout(false);
            this.hotel_box.PerformLayout();
            this.bus_box.ResumeLayout(false);
            this.bus_box.PerformLayout();
            this.data_box.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.admin_datagridview)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userBindingSource)).EndInit();
            this.user_box.ResumeLayout(false);
            this.user_box.PerformLayout();
            this.admin_box.ResumeLayout(false);
            this.admin_box.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label hotel_roomCount_label;
        private System.Windows.Forms.Label hotel_coordinateY_label;
        private System.Windows.Forms.TextBox hotel_coordinateY_box;
        private System.Windows.Forms.Button hotel_delete_button;
        private System.Windows.Forms.Label hotel_coordinateX_label;
        private System.Windows.Forms.TextBox hotel_coordinateX_box;
        private System.Windows.Forms.Label hotel_zipCode_label;
        private System.Windows.Forms.Label hotel_address_label;
        private System.Windows.Forms.Label hotel_phoneNum_label;
        private System.Windows.Forms.Button admin_delete_button;
        private System.Windows.Forms.TextBox admin_email_box;
        private System.Windows.Forms.Label admin_phoneNum_label;
        private System.Windows.Forms.Label admin_name_label;
        private System.Windows.Forms.Label admin_passWord_label;
        private System.Windows.Forms.Label admin_id_label;
        private System.Windows.Forms.TextBox admin_name_box;
        private System.Windows.Forms.TextBox hotel_roomCount_box;
        private System.Windows.Forms.Label admin_email_label;
        private System.Windows.Forms.GroupBox hotel_box;
        private System.Windows.Forms.Label hotel_name_label;
        private System.Windows.Forms.TextBox hotel_address_box;
        private System.Windows.Forms.TextBox hotel_zipCode_box;
        private System.Windows.Forms.TextBox hotel_phoneNum_box;
        private System.Windows.Forms.Button hotel_create_button;
        private System.Windows.Forms.TextBox hotel_name_box;
        private System.Windows.Forms.Button hotel_search_button;
        private System.Windows.Forms.Button bus_delete_button;
        private System.Windows.Forms.Label bus_endPoint_label;
        private System.Windows.Forms.TextBox bus_endTime_box;
        private System.Windows.Forms.Label bus_startPoint_label;
        private System.Windows.Forms.Label bus_endTime_label;
        private System.Windows.Forms.Label bus_startTime_label;
        private System.Windows.Forms.Label bus_name_label;
        private System.Windows.Forms.TextBox bus_endPoint_box;
        private System.Windows.Forms.TextBox bus_startTime_box;
        private System.Windows.Forms.TextBox bus_startPoint_box;
        private System.Windows.Forms.Button bus_create_button;
        private System.Windows.Forms.Button bus_search_button;
        private System.Windows.Forms.GroupBox bus_box;
        private System.Windows.Forms.TextBox bus_name_box;
        private System.Windows.Forms.TextBox admin_phoneNum_box;
        private System.Windows.Forms.GroupBox data_box;
        private System.Windows.Forms.DataGridView admin_datagridview;
        private System.Windows.Forms.BindingSource userBindingSource;
        private System.Windows.Forms.Label user_phoneNum_label;
        private System.Windows.Forms.Label user_name_label;
        private System.Windows.Forms.Label user_passWord_label;
        private System.Windows.Forms.Label user_id_label;
        private System.Windows.Forms.TextBox user_name_box;
        private System.Windows.Forms.TextBox user_phoneNum_box;
        private System.Windows.Forms.TextBox user_passWord_box;
        private System.Windows.Forms.Button user_create_button;
        private System.Windows.Forms.ListBox log_box;
        private System.Windows.Forms.TextBox admin_id_box;
        private System.Windows.Forms.TextBox user_id_box;
        private System.Windows.Forms.GroupBox user_box;
        private System.Windows.Forms.Button user_delete_button;
        private System.Windows.Forms.Label user_email_label;
        private System.Windows.Forms.TextBox user_email_box;
        private System.Windows.Forms.Button user_search_button;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox admin_box;
        private System.Windows.Forms.TextBox admin_passWord_box;
        private System.Windows.Forms.Button admin_create_button;
        private System.Windows.Forms.Button admin_search_button;
        private System.Windows.Forms.Label admin_timer;
    }
}