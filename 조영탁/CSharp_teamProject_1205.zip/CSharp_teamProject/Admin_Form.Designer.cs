﻿namespace CSharp_teamProject
{
    partial class W
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.user_phoneNum_label = new System.Windows.Forms.Label();
            this.user_name_label = new System.Windows.Forms.Label();
            this.user_passWord_label = new System.Windows.Forms.Label();
            this.user_id_label = new System.Windows.Forms.Label();
            this.user_name_box = new System.Windows.Forms.TextBox();
            this.user_phoneNum_box = new System.Windows.Forms.TextBox();
            this.user_passWord_box = new System.Windows.Forms.TextBox();
            this.user_create_button = new System.Windows.Forms.Button();
            this.log_box = new System.Windows.Forms.ListBox();
            this.admin_datagridview = new System.Windows.Forms.DataGridView();
            this.data_box = new System.Windows.Forms.GroupBox();
            this.user_id_box = new System.Windows.Forms.TextBox();
            this.user_box = new System.Windows.Forms.GroupBox();
            this.user_delete_button = new System.Windows.Forms.Button();
            this.user_email_label = new System.Windows.Forms.Label();
            this.user_email_box = new System.Windows.Forms.TextBox();
            this.user_search_button = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.admin_timer = new System.Windows.Forms.Label();
            this.admin_box = new System.Windows.Forms.GroupBox();
            this.admin_delete_button = new System.Windows.Forms.Button();
            this.admin_email_label = new System.Windows.Forms.Label();
            this.admin_email_box = new System.Windows.Forms.TextBox();
            this.admin_phoneNum_label = new System.Windows.Forms.Label();
            this.admin_name_label = new System.Windows.Forms.Label();
            this.admin_passWord_label = new System.Windows.Forms.Label();
            this.admin_id_label = new System.Windows.Forms.Label();
            this.admin_name_box = new System.Windows.Forms.TextBox();
            this.admin_phoneNum_box = new System.Windows.Forms.TextBox();
            this.admin_passWord_box = new System.Windows.Forms.TextBox();
            this.admin_create_button = new System.Windows.Forms.Button();
            this.admin_id_box = new System.Windows.Forms.TextBox();
            this.admin_search_button = new System.Windows.Forms.Button();
            this.hotel_box = new System.Windows.Forms.GroupBox();
            this.hotel_roomCount_label = new System.Windows.Forms.Label();
            this.hotel_roomCount_box = new System.Windows.Forms.TextBox();
            this.hotel_coordinateY_label = new System.Windows.Forms.Label();
            this.hotel_coordinateY_box = new System.Windows.Forms.TextBox();
            this.hotel_delete_button = new System.Windows.Forms.Button();
            this.hotel_coordinateX_label = new System.Windows.Forms.Label();
            this.hotel_coordinateX_box = new System.Windows.Forms.TextBox();
            this.hotel_zipCode_label = new System.Windows.Forms.Label();
            this.hotel_address_label = new System.Windows.Forms.Label();
            this.hotel_phoneNum_label = new System.Windows.Forms.Label();
            this.hotel_name_label = new System.Windows.Forms.Label();
            this.hotel_address_box = new System.Windows.Forms.TextBox();
            this.hotel_zipCode_box = new System.Windows.Forms.TextBox();
            this.hotel_phoneNum_box = new System.Windows.Forms.TextBox();
            this.hotel_create_button = new System.Windows.Forms.Button();
            this.hotel_name_box = new System.Windows.Forms.TextBox();
            this.hotel_search_button = new System.Windows.Forms.Button();
            this.bus_box = new System.Windows.Forms.GroupBox();
            this.bus_delete_button = new System.Windows.Forms.Button();
            this.bus_endPoint_label = new System.Windows.Forms.Label();
            this.bus_endTime_box = new System.Windows.Forms.TextBox();
            this.bus_startPoint_label = new System.Windows.Forms.Label();
            this.bus_endTime_label = new System.Windows.Forms.Label();
            this.bus_startTime_label = new System.Windows.Forms.Label();
            this.bus_name_label = new System.Windows.Forms.Label();
            this.bus_endPoint_box = new System.Windows.Forms.TextBox();
            this.bus_startTime_box = new System.Windows.Forms.TextBox();
            this.bus_startPoint_box = new System.Windows.Forms.TextBox();
            this.bus_create_button = new System.Windows.Forms.Button();
            this.bus_name_box = new System.Windows.Forms.TextBox();
            this.bus_search_button = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.admin_datagridview)).BeginInit();
            this.data_box.SuspendLayout();
            this.user_box.SuspendLayout();
            this.admin_box.SuspendLayout();
            this.hotel_box.SuspendLayout();
            this.bus_box.SuspendLayout();
            this.SuspendLayout();
            // 
            // user_phoneNum_label
            // 
            this.user_phoneNum_label.AutoSize = true;
            this.user_phoneNum_label.Location = new System.Drawing.Point(1, 107);
            this.user_phoneNum_label.Name = "user_phoneNum_label";
            this.user_phoneNum_label.Size = new System.Drawing.Size(63, 15);
            this.user_phoneNum_label.TabIndex = 12;
            this.user_phoneNum_label.Text = "전화번호";
            // 
            // user_name_label
            // 
            this.user_name_label.AutoSize = true;
            this.user_name_label.Location = new System.Drawing.Point(1, 78);
            this.user_name_label.Name = "user_name_label";
            this.user_name_label.Size = new System.Drawing.Size(35, 15);
            this.user_name_label.TabIndex = 11;
            this.user_name_label.Text = "이름";
            // 
            // user_passWord_label
            // 
            this.user_passWord_label.AutoSize = true;
            this.user_passWord_label.Location = new System.Drawing.Point(1, 49);
            this.user_passWord_label.Name = "user_passWord_label";
            this.user_passWord_label.Size = new System.Drawing.Size(63, 15);
            this.user_passWord_label.TabIndex = 10;
            this.user_passWord_label.Text = "비밀번호";
            // 
            // user_id_label
            // 
            this.user_id_label.AutoSize = true;
            this.user_id_label.Location = new System.Drawing.Point(1, 20);
            this.user_id_label.Name = "user_id_label";
            this.user_id_label.Size = new System.Drawing.Size(49, 15);
            this.user_id_label.TabIndex = 9;
            this.user_id_label.Text = "아이디";
            // 
            // user_name_box
            // 
            this.user_name_box.Location = new System.Drawing.Point(64, 74);
            this.user_name_box.Name = "user_name_box";
            this.user_name_box.Size = new System.Drawing.Size(118, 23);
            this.user_name_box.TabIndex = 6;
            // 
            // user_phoneNum_box
            // 
            this.user_phoneNum_box.Location = new System.Drawing.Point(64, 103);
            this.user_phoneNum_box.Name = "user_phoneNum_box";
            this.user_phoneNum_box.Size = new System.Drawing.Size(118, 23);
            this.user_phoneNum_box.TabIndex = 8;
            // 
            // user_passWord_box
            // 
            this.user_passWord_box.Location = new System.Drawing.Point(64, 45);
            this.user_passWord_box.Name = "user_passWord_box";
            this.user_passWord_box.Size = new System.Drawing.Size(118, 23);
            this.user_passWord_box.TabIndex = 4;
            // 
            // user_create_button
            // 
            this.user_create_button.Location = new System.Drawing.Point(186, 44);
            this.user_create_button.Name = "user_create_button";
            this.user_create_button.Size = new System.Drawing.Size(52, 23);
            this.user_create_button.TabIndex = 5;
            this.user_create_button.Text = "추가";
            this.user_create_button.UseVisualStyleBackColor = true;
            this.user_create_button.Click += new System.EventHandler(this.user_create_button_Click);
            // 
            // log_box
            // 
            this.log_box.FormattingEnabled = true;
            this.log_box.ItemHeight = 15;
            this.log_box.Location = new System.Drawing.Point(6, 506);
            this.log_box.Name = "log_box";
            this.log_box.Size = new System.Drawing.Size(986, 169);
            this.log_box.TabIndex = 2;
            // 
            // admin_datagridview
            // 
            this.admin_datagridview.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.admin_datagridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.admin_datagridview.Location = new System.Drawing.Point(6, 16);
            this.admin_datagridview.Name = "admin_datagridview";
            this.admin_datagridview.RowTemplate.Height = 23;
            this.admin_datagridview.Size = new System.Drawing.Size(974, 248);
            this.admin_datagridview.TabIndex = 2;
            // 
            // data_box
            // 
            this.data_box.Controls.Add(this.admin_datagridview);
            this.data_box.Location = new System.Drawing.Point(6, 230);
            this.data_box.Name = "data_box";
            this.data_box.Size = new System.Drawing.Size(986, 270);
            this.data_box.TabIndex = 5;
            this.data_box.TabStop = false;
            this.data_box.Text = "정보";
            // 
            // user_id_box
            // 
            this.user_id_box.Location = new System.Drawing.Point(64, 16);
            this.user_id_box.Name = "user_id_box";
            this.user_id_box.Size = new System.Drawing.Size(118, 23);
            this.user_id_box.TabIndex = 2;
            // 
            // user_box
            // 
            this.user_box.Controls.Add(this.user_delete_button);
            this.user_box.Controls.Add(this.user_email_label);
            this.user_box.Controls.Add(this.user_email_box);
            this.user_box.Controls.Add(this.user_phoneNum_label);
            this.user_box.Controls.Add(this.user_name_label);
            this.user_box.Controls.Add(this.user_passWord_label);
            this.user_box.Controls.Add(this.user_id_label);
            this.user_box.Controls.Add(this.user_name_box);
            this.user_box.Controls.Add(this.user_phoneNum_box);
            this.user_box.Controls.Add(this.user_passWord_box);
            this.user_box.Controls.Add(this.user_create_button);
            this.user_box.Controls.Add(this.user_id_box);
            this.user_box.Controls.Add(this.user_search_button);
            this.user_box.Location = new System.Drawing.Point(6, 3);
            this.user_box.Name = "user_box";
            this.user_box.Size = new System.Drawing.Size(242, 221);
            this.user_box.TabIndex = 3;
            this.user_box.TabStop = false;
            this.user_box.Text = "회원";
            // 
            // user_delete_button
            // 
            this.user_delete_button.Location = new System.Drawing.Point(186, 73);
            this.user_delete_button.Name = "user_delete_button";
            this.user_delete_button.Size = new System.Drawing.Size(52, 23);
            this.user_delete_button.TabIndex = 15;
            this.user_delete_button.Text = "삭제";
            this.user_delete_button.UseVisualStyleBackColor = true;
            this.user_delete_button.Click += new System.EventHandler(this.user_delete_button_Click);
            // 
            // user_email_label
            // 
            this.user_email_label.AutoSize = true;
            this.user_email_label.Location = new System.Drawing.Point(1, 136);
            this.user_email_label.Name = "user_email_label";
            this.user_email_label.Size = new System.Drawing.Size(49, 15);
            this.user_email_label.TabIndex = 14;
            this.user_email_label.Text = "이메일";
            // 
            // user_email_box
            // 
            this.user_email_box.Location = new System.Drawing.Point(64, 132);
            this.user_email_box.Name = "user_email_box";
            this.user_email_box.Size = new System.Drawing.Size(118, 23);
            this.user_email_box.TabIndex = 13;
            // 
            // user_search_button
            // 
            this.user_search_button.Location = new System.Drawing.Point(186, 15);
            this.user_search_button.Name = "user_search_button";
            this.user_search_button.Size = new System.Drawing.Size(52, 23);
            this.user_search_button.TabIndex = 3;
            this.user_search_button.Text = "조회";
            this.user_search_button.UseVisualStyleBackColor = true;
            this.user_search_button.Click += new System.EventHandler(this.user_search_button_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            // 
            // admin_timer
            // 
            this.admin_timer.AutoSize = true;
            this.admin_timer.Location = new System.Drawing.Point(3, 681);
            this.admin_timer.Name = "admin_timer";
            this.admin_timer.Size = new System.Drawing.Size(84, 15);
            this.admin_timer.TabIndex = 6;
            this.admin_timer.Text = "admin_timer";
            // 
            // admin_box
            // 
            this.admin_box.Controls.Add(this.admin_delete_button);
            this.admin_box.Controls.Add(this.admin_email_label);
            this.admin_box.Controls.Add(this.admin_email_box);
            this.admin_box.Controls.Add(this.admin_phoneNum_label);
            this.admin_box.Controls.Add(this.admin_name_label);
            this.admin_box.Controls.Add(this.admin_passWord_label);
            this.admin_box.Controls.Add(this.admin_id_label);
            this.admin_box.Controls.Add(this.admin_name_box);
            this.admin_box.Controls.Add(this.admin_phoneNum_box);
            this.admin_box.Controls.Add(this.admin_passWord_box);
            this.admin_box.Controls.Add(this.admin_create_button);
            this.admin_box.Controls.Add(this.admin_id_box);
            this.admin_box.Controls.Add(this.admin_search_button);
            this.admin_box.Location = new System.Drawing.Point(254, 3);
            this.admin_box.Name = "admin_box";
            this.admin_box.Size = new System.Drawing.Size(242, 221);
            this.admin_box.TabIndex = 20;
            this.admin_box.TabStop = false;
            this.admin_box.Text = "관리자";
            // 
            // admin_delete_button
            // 
            this.admin_delete_button.Location = new System.Drawing.Point(186, 73);
            this.admin_delete_button.Name = "admin_delete_button";
            this.admin_delete_button.Size = new System.Drawing.Size(52, 23);
            this.admin_delete_button.TabIndex = 15;
            this.admin_delete_button.Text = "삭제";
            this.admin_delete_button.UseVisualStyleBackColor = true;
            // 
            // admin_email_label
            // 
            this.admin_email_label.AutoSize = true;
            this.admin_email_label.Location = new System.Drawing.Point(1, 136);
            this.admin_email_label.Name = "admin_email_label";
            this.admin_email_label.Size = new System.Drawing.Size(49, 15);
            this.admin_email_label.TabIndex = 14;
            this.admin_email_label.Text = "이메일";
            // 
            // admin_email_box
            // 
            this.admin_email_box.Location = new System.Drawing.Point(64, 132);
            this.admin_email_box.Name = "admin_email_box";
            this.admin_email_box.Size = new System.Drawing.Size(118, 23);
            this.admin_email_box.TabIndex = 13;
            // 
            // admin_phoneNum_label
            // 
            this.admin_phoneNum_label.AutoSize = true;
            this.admin_phoneNum_label.Location = new System.Drawing.Point(1, 107);
            this.admin_phoneNum_label.Name = "admin_phoneNum_label";
            this.admin_phoneNum_label.Size = new System.Drawing.Size(63, 15);
            this.admin_phoneNum_label.TabIndex = 12;
            this.admin_phoneNum_label.Text = "전화번호";
            // 
            // admin_name_label
            // 
            this.admin_name_label.AutoSize = true;
            this.admin_name_label.Location = new System.Drawing.Point(1, 78);
            this.admin_name_label.Name = "admin_name_label";
            this.admin_name_label.Size = new System.Drawing.Size(35, 15);
            this.admin_name_label.TabIndex = 11;
            this.admin_name_label.Text = "이름";
            // 
            // admin_passWord_label
            // 
            this.admin_passWord_label.AutoSize = true;
            this.admin_passWord_label.Location = new System.Drawing.Point(1, 49);
            this.admin_passWord_label.Name = "admin_passWord_label";
            this.admin_passWord_label.Size = new System.Drawing.Size(63, 15);
            this.admin_passWord_label.TabIndex = 10;
            this.admin_passWord_label.Text = "비밀번호";
            // 
            // admin_id_label
            // 
            this.admin_id_label.AutoSize = true;
            this.admin_id_label.Location = new System.Drawing.Point(1, 20);
            this.admin_id_label.Name = "admin_id_label";
            this.admin_id_label.Size = new System.Drawing.Size(49, 15);
            this.admin_id_label.TabIndex = 9;
            this.admin_id_label.Text = "아이디";
            // 
            // admin_name_box
            // 
            this.admin_name_box.Location = new System.Drawing.Point(64, 74);
            this.admin_name_box.Name = "admin_name_box";
            this.admin_name_box.Size = new System.Drawing.Size(118, 23);
            this.admin_name_box.TabIndex = 6;
            // 
            // admin_phoneNum_box
            // 
            this.admin_phoneNum_box.Location = new System.Drawing.Point(64, 103);
            this.admin_phoneNum_box.Name = "admin_phoneNum_box";
            this.admin_phoneNum_box.Size = new System.Drawing.Size(118, 23);
            this.admin_phoneNum_box.TabIndex = 8;
            // 
            // admin_passWord_box
            // 
            this.admin_passWord_box.Location = new System.Drawing.Point(64, 45);
            this.admin_passWord_box.Name = "admin_passWord_box";
            this.admin_passWord_box.Size = new System.Drawing.Size(118, 23);
            this.admin_passWord_box.TabIndex = 4;
            // 
            // admin_create_button
            // 
            this.admin_create_button.Location = new System.Drawing.Point(186, 44);
            this.admin_create_button.Name = "admin_create_button";
            this.admin_create_button.Size = new System.Drawing.Size(52, 23);
            this.admin_create_button.TabIndex = 5;
            this.admin_create_button.Text = "추가";
            this.admin_create_button.UseVisualStyleBackColor = true;
            // 
            // admin_id_box
            // 
            this.admin_id_box.Location = new System.Drawing.Point(64, 16);
            this.admin_id_box.Name = "admin_id_box";
            this.admin_id_box.Size = new System.Drawing.Size(118, 23);
            this.admin_id_box.TabIndex = 2;
            // 
            // admin_search_button
            // 
            this.admin_search_button.Location = new System.Drawing.Point(186, 15);
            this.admin_search_button.Name = "admin_search_button";
            this.admin_search_button.Size = new System.Drawing.Size(52, 23);
            this.admin_search_button.TabIndex = 3;
            this.admin_search_button.Text = "조회";
            this.admin_search_button.UseVisualStyleBackColor = true;
            // 
            // hotel_box
            // 
            this.hotel_box.Controls.Add(this.hotel_roomCount_label);
            this.hotel_box.Controls.Add(this.hotel_roomCount_box);
            this.hotel_box.Controls.Add(this.hotel_coordinateY_label);
            this.hotel_box.Controls.Add(this.hotel_coordinateY_box);
            this.hotel_box.Controls.Add(this.hotel_delete_button);
            this.hotel_box.Controls.Add(this.hotel_coordinateX_label);
            this.hotel_box.Controls.Add(this.hotel_coordinateX_box);
            this.hotel_box.Controls.Add(this.hotel_zipCode_label);
            this.hotel_box.Controls.Add(this.hotel_address_label);
            this.hotel_box.Controls.Add(this.hotel_phoneNum_label);
            this.hotel_box.Controls.Add(this.hotel_name_label);
            this.hotel_box.Controls.Add(this.hotel_address_box);
            this.hotel_box.Controls.Add(this.hotel_zipCode_box);
            this.hotel_box.Controls.Add(this.hotel_phoneNum_box);
            this.hotel_box.Controls.Add(this.hotel_create_button);
            this.hotel_box.Controls.Add(this.hotel_name_box);
            this.hotel_box.Controls.Add(this.hotel_search_button);
            this.hotel_box.Location = new System.Drawing.Point(502, 3);
            this.hotel_box.Name = "hotel_box";
            this.hotel_box.Size = new System.Drawing.Size(242, 221);
            this.hotel_box.TabIndex = 20;
            this.hotel_box.TabStop = false;
            this.hotel_box.Text = "숙소";
            // 
            // hotel_roomCount_label
            // 
            this.hotel_roomCount_label.AutoSize = true;
            this.hotel_roomCount_label.Location = new System.Drawing.Point(1, 193);
            this.hotel_roomCount_label.Name = "hotel_roomCount_label";
            this.hotel_roomCount_label.Size = new System.Drawing.Size(49, 15);
            this.hotel_roomCount_label.TabIndex = 19;
            this.hotel_roomCount_label.Text = "객실수";
            // 
            // hotel_roomCount_box
            // 
            this.hotel_roomCount_box.Location = new System.Drawing.Point(64, 189);
            this.hotel_roomCount_box.Name = "hotel_roomCount_box";
            this.hotel_roomCount_box.Size = new System.Drawing.Size(118, 23);
            this.hotel_roomCount_box.TabIndex = 18;
            // 
            // hotel_coordinateY_label
            // 
            this.hotel_coordinateY_label.AutoSize = true;
            this.hotel_coordinateY_label.Location = new System.Drawing.Point(1, 164);
            this.hotel_coordinateY_label.Name = "hotel_coordinateY_label";
            this.hotel_coordinateY_label.Size = new System.Drawing.Size(42, 15);
            this.hotel_coordinateY_label.TabIndex = 17;
            this.hotel_coordinateY_label.Text = "Y좌표";
            // 
            // hotel_coordinateY_box
            // 
            this.hotel_coordinateY_box.Location = new System.Drawing.Point(64, 160);
            this.hotel_coordinateY_box.Name = "hotel_coordinateY_box";
            this.hotel_coordinateY_box.Size = new System.Drawing.Size(118, 23);
            this.hotel_coordinateY_box.TabIndex = 16;
            // 
            // hotel_delete_button
            // 
            this.hotel_delete_button.Location = new System.Drawing.Point(186, 73);
            this.hotel_delete_button.Name = "hotel_delete_button";
            this.hotel_delete_button.Size = new System.Drawing.Size(52, 23);
            this.hotel_delete_button.TabIndex = 15;
            this.hotel_delete_button.Text = "삭제";
            this.hotel_delete_button.UseVisualStyleBackColor = true;
            // 
            // hotel_coordinateX_label
            // 
            this.hotel_coordinateX_label.AutoSize = true;
            this.hotel_coordinateX_label.Location = new System.Drawing.Point(1, 135);
            this.hotel_coordinateX_label.Name = "hotel_coordinateX_label";
            this.hotel_coordinateX_label.Size = new System.Drawing.Size(42, 15);
            this.hotel_coordinateX_label.TabIndex = 14;
            this.hotel_coordinateX_label.Text = "X좌표";
            // 
            // hotel_coordinateX_box
            // 
            this.hotel_coordinateX_box.Location = new System.Drawing.Point(64, 131);
            this.hotel_coordinateX_box.Name = "hotel_coordinateX_box";
            this.hotel_coordinateX_box.Size = new System.Drawing.Size(118, 23);
            this.hotel_coordinateX_box.TabIndex = 13;
            // 
            // hotel_zipCode_label
            // 
            this.hotel_zipCode_label.AutoSize = true;
            this.hotel_zipCode_label.Location = new System.Drawing.Point(1, 106);
            this.hotel_zipCode_label.Name = "hotel_zipCode_label";
            this.hotel_zipCode_label.Size = new System.Drawing.Size(63, 15);
            this.hotel_zipCode_label.TabIndex = 12;
            this.hotel_zipCode_label.Text = "우편번호";
            // 
            // hotel_address_label
            // 
            this.hotel_address_label.AutoSize = true;
            this.hotel_address_label.Location = new System.Drawing.Point(1, 77);
            this.hotel_address_label.Name = "hotel_address_label";
            this.hotel_address_label.Size = new System.Drawing.Size(35, 15);
            this.hotel_address_label.TabIndex = 11;
            this.hotel_address_label.Text = "주소";
            // 
            // hotel_phoneNum_label
            // 
            this.hotel_phoneNum_label.AutoSize = true;
            this.hotel_phoneNum_label.Location = new System.Drawing.Point(1, 48);
            this.hotel_phoneNum_label.Name = "hotel_phoneNum_label";
            this.hotel_phoneNum_label.Size = new System.Drawing.Size(63, 15);
            this.hotel_phoneNum_label.TabIndex = 10;
            this.hotel_phoneNum_label.Text = "전화번호";
            // 
            // hotel_name_label
            // 
            this.hotel_name_label.AutoSize = true;
            this.hotel_name_label.Location = new System.Drawing.Point(1, 19);
            this.hotel_name_label.Name = "hotel_name_label";
            this.hotel_name_label.Size = new System.Drawing.Size(49, 15);
            this.hotel_name_label.TabIndex = 9;
            this.hotel_name_label.Text = "숙소명";
            // 
            // hotel_address_box
            // 
            this.hotel_address_box.Location = new System.Drawing.Point(64, 73);
            this.hotel_address_box.Name = "hotel_address_box";
            this.hotel_address_box.Size = new System.Drawing.Size(118, 23);
            this.hotel_address_box.TabIndex = 6;
            // 
            // hotel_zipCode_box
            // 
            this.hotel_zipCode_box.Location = new System.Drawing.Point(64, 102);
            this.hotel_zipCode_box.Name = "hotel_zipCode_box";
            this.hotel_zipCode_box.Size = new System.Drawing.Size(118, 23);
            this.hotel_zipCode_box.TabIndex = 8;
            // 
            // hotel_phoneNum_box
            // 
            this.hotel_phoneNum_box.Location = new System.Drawing.Point(64, 44);
            this.hotel_phoneNum_box.Name = "hotel_phoneNum_box";
            this.hotel_phoneNum_box.Size = new System.Drawing.Size(118, 23);
            this.hotel_phoneNum_box.TabIndex = 4;
            // 
            // hotel_create_button
            // 
            this.hotel_create_button.Location = new System.Drawing.Point(186, 44);
            this.hotel_create_button.Name = "hotel_create_button";
            this.hotel_create_button.Size = new System.Drawing.Size(52, 23);
            this.hotel_create_button.TabIndex = 5;
            this.hotel_create_button.Text = "추가";
            this.hotel_create_button.UseVisualStyleBackColor = true;
            // 
            // hotel_name_box
            // 
            this.hotel_name_box.Location = new System.Drawing.Point(64, 15);
            this.hotel_name_box.Name = "hotel_name_box";
            this.hotel_name_box.Size = new System.Drawing.Size(118, 23);
            this.hotel_name_box.TabIndex = 2;
            // 
            // hotel_search_button
            // 
            this.hotel_search_button.Location = new System.Drawing.Point(186, 15);
            this.hotel_search_button.Name = "hotel_search_button";
            this.hotel_search_button.Size = new System.Drawing.Size(52, 23);
            this.hotel_search_button.TabIndex = 3;
            this.hotel_search_button.Text = "조회";
            this.hotel_search_button.UseVisualStyleBackColor = true;
            // 
            // bus_box
            // 
            this.bus_box.Controls.Add(this.bus_delete_button);
            this.bus_box.Controls.Add(this.bus_endPoint_label);
            this.bus_box.Controls.Add(this.bus_endTime_box);
            this.bus_box.Controls.Add(this.bus_startPoint_label);
            this.bus_box.Controls.Add(this.bus_endTime_label);
            this.bus_box.Controls.Add(this.bus_startTime_label);
            this.bus_box.Controls.Add(this.bus_name_label);
            this.bus_box.Controls.Add(this.bus_endPoint_box);
            this.bus_box.Controls.Add(this.bus_startTime_box);
            this.bus_box.Controls.Add(this.bus_startPoint_box);
            this.bus_box.Controls.Add(this.bus_create_button);
            this.bus_box.Controls.Add(this.bus_name_box);
            this.bus_box.Controls.Add(this.bus_search_button);
            this.bus_box.Location = new System.Drawing.Point(750, 3);
            this.bus_box.Name = "bus_box";
            this.bus_box.Size = new System.Drawing.Size(242, 221);
            this.bus_box.TabIndex = 20;
            this.bus_box.TabStop = false;
            this.bus_box.Text = "버스";
            // 
            // bus_delete_button
            // 
            this.bus_delete_button.Location = new System.Drawing.Point(186, 73);
            this.bus_delete_button.Name = "bus_delete_button";
            this.bus_delete_button.Size = new System.Drawing.Size(52, 23);
            this.bus_delete_button.TabIndex = 15;
            this.bus_delete_button.Text = "삭제";
            this.bus_delete_button.UseVisualStyleBackColor = true;
            // 
            // bus_endPoint_label
            // 
            this.bus_endPoint_label.AutoSize = true;
            this.bus_endPoint_label.Location = new System.Drawing.Point(1, 135);
            this.bus_endPoint_label.Name = "bus_endPoint_label";
            this.bus_endPoint_label.Size = new System.Drawing.Size(63, 15);
            this.bus_endPoint_label.TabIndex = 14;
            this.bus_endPoint_label.Text = "도착시간";
            // 
            // bus_endTime_box
            // 
            this.bus_endTime_box.Location = new System.Drawing.Point(64, 131);
            this.bus_endTime_box.Name = "bus_endTime_box";
            this.bus_endTime_box.Size = new System.Drawing.Size(118, 23);
            this.bus_endTime_box.TabIndex = 13;
            // 
            // bus_startPoint_label
            // 
            this.bus_startPoint_label.AutoSize = true;
            this.bus_startPoint_label.Location = new System.Drawing.Point(1, 106);
            this.bus_startPoint_label.Name = "bus_startPoint_label";
            this.bus_startPoint_label.Size = new System.Drawing.Size(63, 15);
            this.bus_startPoint_label.TabIndex = 12;
            this.bus_startPoint_label.Text = "출발시간";
            // 
            // bus_endTime_label
            // 
            this.bus_endTime_label.AutoSize = true;
            this.bus_endTime_label.Location = new System.Drawing.Point(1, 77);
            this.bus_endTime_label.Name = "bus_endTime_label";
            this.bus_endTime_label.Size = new System.Drawing.Size(49, 15);
            this.bus_endTime_label.TabIndex = 11;
            this.bus_endTime_label.Text = "도착지";
            // 
            // bus_startTime_label
            // 
            this.bus_startTime_label.AutoSize = true;
            this.bus_startTime_label.Location = new System.Drawing.Point(1, 48);
            this.bus_startTime_label.Name = "bus_startTime_label";
            this.bus_startTime_label.Size = new System.Drawing.Size(49, 15);
            this.bus_startTime_label.TabIndex = 10;
            this.bus_startTime_label.Text = "출발지";
            // 
            // bus_name_label
            // 
            this.bus_name_label.AutoSize = true;
            this.bus_name_label.Location = new System.Drawing.Point(1, 19);
            this.bus_name_label.Name = "bus_name_label";
            this.bus_name_label.Size = new System.Drawing.Size(49, 15);
            this.bus_name_label.TabIndex = 9;
            this.bus_name_label.Text = "버스명";
            // 
            // bus_endPoint_box
            // 
            this.bus_endPoint_box.Location = new System.Drawing.Point(64, 73);
            this.bus_endPoint_box.Name = "bus_endPoint_box";
            this.bus_endPoint_box.Size = new System.Drawing.Size(118, 23);
            this.bus_endPoint_box.TabIndex = 6;
            // 
            // bus_startTime_box
            // 
            this.bus_startTime_box.Location = new System.Drawing.Point(64, 102);
            this.bus_startTime_box.Name = "bus_startTime_box";
            this.bus_startTime_box.Size = new System.Drawing.Size(118, 23);
            this.bus_startTime_box.TabIndex = 8;
            // 
            // bus_startPoint_box
            // 
            this.bus_startPoint_box.Location = new System.Drawing.Point(64, 44);
            this.bus_startPoint_box.Name = "bus_startPoint_box";
            this.bus_startPoint_box.Size = new System.Drawing.Size(118, 23);
            this.bus_startPoint_box.TabIndex = 4;
            // 
            // bus_create_button
            // 
            this.bus_create_button.Location = new System.Drawing.Point(186, 44);
            this.bus_create_button.Name = "bus_create_button";
            this.bus_create_button.Size = new System.Drawing.Size(52, 23);
            this.bus_create_button.TabIndex = 5;
            this.bus_create_button.Text = "추가";
            this.bus_create_button.UseVisualStyleBackColor = true;
            // 
            // bus_name_box
            // 
            this.bus_name_box.Location = new System.Drawing.Point(64, 15);
            this.bus_name_box.Name = "bus_name_box";
            this.bus_name_box.Size = new System.Drawing.Size(118, 23);
            this.bus_name_box.TabIndex = 2;
            // 
            // bus_search_button
            // 
            this.bus_search_button.Location = new System.Drawing.Point(186, 15);
            this.bus_search_button.Name = "bus_search_button";
            this.bus_search_button.Size = new System.Drawing.Size(52, 23);
            this.bus_search_button.TabIndex = 3;
            this.bus_search_button.Text = "조회";
            this.bus_search_button.UseVisualStyleBackColor = true;
            // 
            // W
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.bus_box);
            this.Controls.Add(this.hotel_box);
            this.Controls.Add(this.admin_box);
            this.Controls.Add(this.log_box);
            this.Controls.Add(this.data_box);
            this.Controls.Add(this.user_box);
            this.Controls.Add(this.admin_timer);
            this.Font = new System.Drawing.Font("D2Coding", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "W";
            this.Size = new System.Drawing.Size(1000, 700);
            ((System.ComponentModel.ISupportInitialize)(this.admin_datagridview)).EndInit();
            this.data_box.ResumeLayout(false);
            this.user_box.ResumeLayout(false);
            this.user_box.PerformLayout();
            this.admin_box.ResumeLayout(false);
            this.admin_box.PerformLayout();
            this.hotel_box.ResumeLayout(false);
            this.hotel_box.PerformLayout();
            this.bus_box.ResumeLayout(false);
            this.bus_box.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label user_phoneNum_label;
        private System.Windows.Forms.Label user_name_label;
        private System.Windows.Forms.Label user_passWord_label;
        private System.Windows.Forms.Label user_id_label;
        private System.Windows.Forms.TextBox user_name_box;
        private System.Windows.Forms.TextBox user_phoneNum_box;
        private System.Windows.Forms.TextBox user_passWord_box;
        private System.Windows.Forms.Button user_create_button;
        private System.Windows.Forms.ListBox log_box;
        private System.Windows.Forms.DataGridView admin_datagridview;
        private System.Windows.Forms.GroupBox data_box;
        private System.Windows.Forms.TextBox user_id_box;
        private System.Windows.Forms.GroupBox user_box;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label admin_timer;
        private System.Windows.Forms.Label user_email_label;
        private System.Windows.Forms.TextBox user_email_box;
        private System.Windows.Forms.Button user_delete_button;
        private System.Windows.Forms.GroupBox admin_box;
        private System.Windows.Forms.Button admin_delete_button;
        private System.Windows.Forms.Label admin_email_label;
        private System.Windows.Forms.TextBox admin_email_box;
        private System.Windows.Forms.Label admin_phoneNum_label;
        private System.Windows.Forms.Label admin_name_label;
        private System.Windows.Forms.Label admin_passWord_label;
        private System.Windows.Forms.Label admin_id_label;
        private System.Windows.Forms.TextBox admin_name_box;
        private System.Windows.Forms.TextBox admin_phoneNum_box;
        private System.Windows.Forms.TextBox admin_passWord_box;
        private System.Windows.Forms.Button admin_create_button;
        private System.Windows.Forms.TextBox admin_id_box;
        private System.Windows.Forms.GroupBox hotel_box;
        private System.Windows.Forms.Label hotel_roomCount_label;
        private System.Windows.Forms.TextBox hotel_roomCount_box;
        private System.Windows.Forms.Label hotel_coordinateY_label;
        private System.Windows.Forms.TextBox hotel_coordinateY_box;
        private System.Windows.Forms.Button hotel_delete_button;
        private System.Windows.Forms.Label hotel_coordinateX_label;
        private System.Windows.Forms.TextBox hotel_coordinateX_box;
        private System.Windows.Forms.Label hotel_zipCode_label;
        private System.Windows.Forms.Label hotel_address_label;
        private System.Windows.Forms.Label hotel_phoneNum_label;
        private System.Windows.Forms.Label hotel_name_label;
        private System.Windows.Forms.TextBox hotel_address_box;
        private System.Windows.Forms.TextBox hotel_zipCode_box;
        private System.Windows.Forms.TextBox hotel_phoneNum_box;
        private System.Windows.Forms.Button hotel_create_button;
        private System.Windows.Forms.TextBox hotel_name_box;
        private System.Windows.Forms.GroupBox bus_box;
        private System.Windows.Forms.Button bus_delete_button;
        private System.Windows.Forms.Label bus_endPoint_label;
        private System.Windows.Forms.TextBox bus_endTime_box;
        private System.Windows.Forms.Label bus_startPoint_label;
        private System.Windows.Forms.Label bus_endTime_label;
        private System.Windows.Forms.Label bus_startTime_label;
        private System.Windows.Forms.Label bus_name_label;
        private System.Windows.Forms.TextBox bus_endPoint_box;
        private System.Windows.Forms.TextBox bus_startTime_box;
        private System.Windows.Forms.TextBox bus_startPoint_box;
        private System.Windows.Forms.Button bus_create_button;
        private System.Windows.Forms.TextBox bus_name_box;
        private System.Windows.Forms.Button user_search_button;
        private System.Windows.Forms.Button admin_search_button;
        private System.Windows.Forms.Button hotel_search_button;
        private System.Windows.Forms.Button bus_search_button;
    }
}
