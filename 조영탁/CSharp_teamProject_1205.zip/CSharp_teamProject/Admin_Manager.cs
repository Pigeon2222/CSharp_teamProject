﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;

namespace CSharp_teamProject
{
    public class Admin_Manager
    {
        public static List<User> users = new List<User>();

        static Admin_Manager()
        {
            Load();
        }
        public static void Load(string user_id_box = "")
        {
            try
            {
                Admin_Helper.selectQuery(user_id_box);
                users.Clear();
                foreach (DataRow item in Admin_Helper.dt.Rows)
                {
                    User user1 = new User();
                    user1.user_id = item["user_id"].ToString();
                    user1.user_passWord = item["user_passWord"].ToString();
                    user1.user_name = item["user_name"].ToString();
                    user1.user_phoneNum = item["user_phoneNum"].ToString();
                    user1.user_email = item["user_email"].ToString();
                    user1.user_createTime = new DateTime();
                    users.Add(user1);
                }
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message + "load");
                printLog(e.StackTrace + "load");
            }
        }
        public static void printLog(string contents)
        {
            DirectoryInfo di = new DirectoryInfo("Admin_History");
            if (di.Exists == false)
                di.Create();

            using (StreamWriter w = new StreamWriter("Admin_History\\Admin_History.txt", true))
            {
                w.WriteLine(contents);
            }
        }
    }
}
