﻿using System;

namespace CSharp_teamProject
{
    public class Bus
    {
        public int bus_num { get; set; }
        public string bus_name { get; set; }
        public string bus_startPoint { get; set; }
        public string bus_endPoint { get; set; }
        public string bus_startTime { get; set; }
        public string bus_endTime { get; set; }
        public DateTime bus_createTime { get; set; }
    }
}
