﻿using CSharp_teamProject.Login;
using System;
using System.Windows.Forms;

namespace CSharp_teamProject
{
    public partial class Login_up : Form
    {
        public Login_up()
        {
            InitializeComponent();
            maskedTextBox2.KeyUp += (sender, e) =>
            {
                if (e.KeyCode == Keys.Enter)
                {
                    Login_button_Login.PerformClick();
                    maskedTextBox2.Text = "";
                }
            };
        }

        private void Login_button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Login_button_Login_Click(object sender, EventArgs e)
        {
            string id = maskedTextBox1.Text;
            string pw = maskedTextBox2.Text;
            if (maskedTextBox2.Text != "")
            {
                if (id.Equals("admin") && pw.Equals("1234"))
                {
                    MessageBox.Show("로그인에 성공했습니다.", "LOGIN");
                    Dispose();
                }
                else
                    MessageBox.Show("로그인 실패.", "LOGIN");
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {
            new sign_up().ShowDialog();
        }
    }
}
