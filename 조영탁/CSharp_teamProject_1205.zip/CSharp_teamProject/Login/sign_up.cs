﻿using System.Windows.Forms;

namespace CSharp_teamProject.Login
{
    public partial class sign_up : Form
    {
        public sign_up()
        {
            InitializeComponent();
        }

        private void btn_Register_Click(object sender, System.EventArgs e)
        {
            MessageBox.Show("가입 기능 미구현");
        }
    }
}
