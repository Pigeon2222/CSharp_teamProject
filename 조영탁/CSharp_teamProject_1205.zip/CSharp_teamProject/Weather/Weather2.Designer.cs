﻿namespace CSharp_teamProject.Weather
{
    partial class Weather2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.weather_button4 = new System.Windows.Forms.Button();
            this.weather_button1 = new System.Windows.Forms.Button();
            this.weather_label2 = new System.Windows.Forms.Label();
            this.weather_textBox2 = new System.Windows.Forms.TextBox();
            this.weather_button3 = new System.Windows.Forms.Button();
            this.weather_button2 = new System.Windows.Forms.Button();
            this.weather_label1 = new System.Windows.Forms.Label();
            this.weather_richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.weather_textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // weather_button4
            // 
            this.weather_button4.Location = new System.Drawing.Point(300, 36);
            this.weather_button4.Name = "weather_button4";
            this.weather_button4.Size = new System.Drawing.Size(72, 58);
            this.weather_button4.TabIndex = 20;
            this.weather_button4.Text = "대구";
            this.weather_button4.UseVisualStyleBackColor = true;
            this.weather_button4.Click += new System.EventHandler(this.weather_button4_Click);
            // 
            // weather_button1
            // 
            this.weather_button1.Location = new System.Drawing.Point(190, 36);
            this.weather_button1.Name = "weather_button1";
            this.weather_button1.Size = new System.Drawing.Size(72, 58);
            this.weather_button1.TabIndex = 19;
            this.weather_button1.Text = "포항";
            this.weather_button1.UseVisualStyleBackColor = true;
            this.weather_button1.Click += new System.EventHandler(this.weather_button1_Click);
            // 
            // weather_label2
            // 
            this.weather_label2.AutoSize = true;
            this.weather_label2.Location = new System.Drawing.Point(542, 116);
            this.weather_label2.Name = "weather_label2";
            this.weather_label2.Size = new System.Drawing.Size(22, 12);
            this.weather_label2.TabIndex = 18;
            this.weather_label2.Text = "lon";
            // 
            // weather_textBox2
            // 
            this.weather_textBox2.Location = new System.Drawing.Point(588, 113);
            this.weather_textBox2.Name = "weather_textBox2";
            this.weather_textBox2.Size = new System.Drawing.Size(100, 21);
            this.weather_textBox2.TabIndex = 17;
            // 
            // weather_button3
            // 
            this.weather_button3.Location = new System.Drawing.Point(780, 303);
            this.weather_button3.Name = "weather_button3";
            this.weather_button3.Size = new System.Drawing.Size(75, 23);
            this.weather_button3.TabIndex = 16;
            this.weather_button3.Text = "주간날씨";
            this.weather_button3.UseVisualStyleBackColor = true;
            this.weather_button3.Click += new System.EventHandler(this.weather_button3_Click);
            // 
            // weather_button2
            // 
            this.weather_button2.Location = new System.Drawing.Point(780, 254);
            this.weather_button2.Name = "weather_button2";
            this.weather_button2.Size = new System.Drawing.Size(75, 23);
            this.weather_button2.TabIndex = 15;
            this.weather_button2.Text = "현재날씨";
            this.weather_button2.UseVisualStyleBackColor = true;
            this.weather_button2.Click += new System.EventHandler(this.weather_button2_Click);
            // 
            // weather_label1
            // 
            this.weather_label1.AutoSize = true;
            this.weather_label1.Location = new System.Drawing.Point(542, 76);
            this.weather_label1.Name = "weather_label1";
            this.weather_label1.Size = new System.Drawing.Size(18, 12);
            this.weather_label1.TabIndex = 14;
            this.weather_label1.Text = "lat";
            // 
            // weather_richTextBox1
            // 
            this.weather_richTextBox1.Location = new System.Drawing.Point(168, 165);
            this.weather_richTextBox1.Name = "weather_richTextBox1";
            this.weather_richTextBox1.Size = new System.Drawing.Size(584, 374);
            this.weather_richTextBox1.TabIndex = 13;
            this.weather_richTextBox1.Text = "";
            // 
            // weather_textBox1
            // 
            this.weather_textBox1.Location = new System.Drawing.Point(588, 73);
            this.weather_textBox1.Name = "weather_textBox1";
            this.weather_textBox1.Size = new System.Drawing.Size(100, 21);
            this.weather_textBox1.TabIndex = 12;
            // 
            // Weather2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 661);
            this.Controls.Add(this.weather_button4);
            this.Controls.Add(this.weather_button1);
            this.Controls.Add(this.weather_label2);
            this.Controls.Add(this.weather_textBox2);
            this.Controls.Add(this.weather_button3);
            this.Controls.Add(this.weather_button2);
            this.Controls.Add(this.weather_label1);
            this.Controls.Add(this.weather_richTextBox1);
            this.Controls.Add(this.weather_textBox1);
            this.Name = "Weather2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Weather";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Button weather_button4;
        private System.Windows.Forms.Button weather_button1;
        private System.Windows.Forms.Label weather_label2;
        private System.Windows.Forms.TextBox weather_textBox2;
        private System.Windows.Forms.Button weather_button3;
        private System.Windows.Forms.Button weather_button2;
        private System.Windows.Forms.Label weather_label1;
        private System.Windows.Forms.RichTextBox weather_richTextBox1;
        private System.Windows.Forms.TextBox weather_textBox1;
    }
}