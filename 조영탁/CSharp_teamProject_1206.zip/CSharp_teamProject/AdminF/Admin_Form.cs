﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace CSharp_teamProject
{
    public partial class Admin_Form : Form
    {
        DataManager datamanager = AdminManager.Instance;
        DBHelper dbhelper = AdminHelper.Instance;
        public Admin_Form()
        {
            InitializeComponent();
            this.KeyPreview = true;

            try
            {
            }
            catch (Exception)
            {
            }
            if (datamanager.Users.Count > 0)
            {
                admin_datagridview.DataSource = null;
                admin_datagridview.DataSource = datamanager.Users;
            }
        }

        private void WriteLog(string contents)
        {
            string log = $"[{DateTime.Now.ToString("yyyy/MM/dd hh:mm:ss")}]" + $"{contents}";
            datamanager.printLog(log);
            log_box.Items.Insert(0, log);
        }

        private void user_search_button_Click(object sender, EventArgs e)
        {
            try
            {
                User user = datamanager.Users.Single(x => x.user_id == user_id_box.Text);

                user.user_id = user_id_box.Text;
                user.user_passWord = user_passWord_box.Text;
                user.user_name = user_name_box.Text;
                user.user_phoneNum = user_phoneNum_box.Text;
                user.user_email = user_email_box.Text;
                user.user_createTime = DateTime.Now;

                admin_datagridview.DataSource = null;
                admin_datagridview.DataSource = datamanager.Users;

                dbhelper.selectQuery(user_id_box.Text);
                string contents = $"회원 {user_id_box.Text} 을/를 조회 하였습니다.";
                WriteLog(contents);
                MessageBox.Show(contents);
                datamanager.Load(user_id_box.Text);
            }
            catch (Exception)
            {
                MessageBox.Show($"회원 {user_id_box.Text} 을/를 조회하지 못했습니다.");
                WriteLog($"회원 {user_id_box.Text} 을/를 조회하지 못했습니다.");
            }
        }

        private void user_create_button_Click(object sender, EventArgs e)
        {
            if (user_id_box.Text.Trim() == "")
                MessageBox.Show("아이디를 입력해주세요");
            else if (user_passWord_box.Text.Trim() == "")
                MessageBox.Show("비밀번호를 입력해주세요.");
            else
                try
                {
                    int result = dbhelper.insertQuery(user_id_box.Text, user_passWord_box.Text, user_name_box.Text, user_phoneNum_box.Text, user_email_box.Text);
                    if (result != 0)
                    {
                        string contents = $"회원 {user_id_box.Text} 을/를 등록 하였습니다.";
                        WriteLog(contents);
                        MessageBox.Show(contents);
                        datamanager.Load();
                        admin_datagridview.DataSource = null;
                        admin_datagridview.DataSource = datamanager.Users;
                    }
                    else if (result == -9)
                    {
                        MessageBox.Show($"DB 연결에 문제가 있습니다.");
                        WriteLog($"DB 연결에 문제가 있습니다.");
                    }
                    else
                    {
                        MessageBox.Show($"회원 {user_id_box.Text} 을/를 등록하지 못했습니다.");
                        WriteLog($"회원 {user_id_box.Text} 을/를 등록하지 못했습니다.");
                    }
                }
                catch (Exception)
                {
                }
        }

        private void user_update_button_Click(object sender, EventArgs e)
        {
            if (user_id_box.Text.Trim() == "")
                MessageBox.Show("아이디를 입력해주세요");
            else if (user_passWord_box.Text.Trim() == "")
                MessageBox.Show("비밀번호를 입력해주세요.");
            else
                try
                {
                    int result = dbhelper.updateQuery(user_id_box.Text, user_passWord_box.Text, user_name_box.Text, user_phoneNum_box.Text, user_email_box.Text);
                    if (result != 0)
                    {
                        string contents = $"회원 {user_id_box.Text} 을/를 수정 하였습니다.";
                        WriteLog(contents);
                        MessageBox.Show(contents);
                        datamanager.Load();
                        admin_datagridview.DataSource = null;
                        admin_datagridview.DataSource = datamanager.Users;
                    }
                    else if (result == -9)
                    {
                        MessageBox.Show($"DB 연결에 문제가 있습니다.");
                        WriteLog($"DB 연결에 문제가 있습니다.");
                    }
                    else
                    {
                        MessageBox.Show($"회원 {user_id_box.Text} 을/를 수정하지 못했습니다.");
                        WriteLog($"회원 {user_id_box.Text} 을/를 수정하지 못했습니다.");
                    }
                }
                catch (Exception)
                {
                }
        }

        private void user_delete_button_Click(object sender, EventArgs e)
        {
            if (user_id_box.Text.Trim() == "")
                MessageBox.Show("아이디를 입력해주세요");
            else if (user_passWord_box.Text.Trim() == "")
                MessageBox.Show("비밀번호를 입력해주세요.");
            else
                try
                {
                    int result = dbhelper.deleteQuery(user_id_box.Text, user_passWord_box.Text);
                    if (result != 0)
                    {
                        string contents = $"회원 {user_id_box.Text} 을/를 삭제 하였습니다.";
                        WriteLog(contents);
                        MessageBox.Show(contents);
                        datamanager.Load();
                        admin_datagridview.DataSource = null;
                        if (datamanager.Users.Count > 0)
                            admin_datagridview.DataSource = datamanager.Users;
                    }
                    else if (result == -9)
                    {
                        MessageBox.Show($"DB 연결에 문제가 있습니다.");
                        WriteLog($"DB 연결에 문제가 있습니다.");
                    }
                    else
                    {
                        MessageBox.Show($"회원 {user_id_box.Text} 을/를 삭제하지 못했습니다.");
                        WriteLog($"회원 {user_id_box.Text} 을/를 삭제하지 못했습니다.");
                    }
                }
                catch (Exception)
                {
                }
        }

        private void admin_datagridview_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            User user = admin_datagridview.CurrentRow.DataBoundItem as User;
            user_id_box.Text = user.user_id;
            user_passWord_box.Text = user.user_passWord;
            user_name_box.Text = user.user_name;
            user_phoneNum_box.Text = user.user_phoneNum;
            user_email_box.Text = user.user_email;
        }

        private void Admin_Form_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
                this.Close();
        }
    }
}
