﻿using System;
using System.Windows.Forms;

namespace CSharp_teamProject
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            this.KeyPreview = true;
            chart();
            new Login_up().ShowDialog();
            //textBox1 위에 키보드를 누르고 그 키가 올라올 때
            //이벤트 추가
            //람다 사용함
            //키가 엔터일 때, button1을 눌러준다.
            //사이드 버튼(움직일때마다 따라가는거)
            panel_side.Height = Mainbutton1.Height; //첫번째 버튼의 높이로 바꿈
            panel_side.Top = Mainbutton1.Top; //첫번째 버튼의 y값으로 바꿈.
                                              //FirstControl 로 만든 유저컨트롤을 맨 앞으로 보냄.
        }

        private void Mainbutton_x_Click(object sender, EventArgs e)
        {
            Dispose();
        }


        private void Mainbutton1_Click(object sender, EventArgs e)
        {
            panel_side.Height = Mainbutton1.Height; //첫번째 버튼의 높이로 바꿈
            panel_side.Top = Mainbutton1.Top; //첫번째 버튼의 y값으로 바꿈.
                                              //map 로 만든 유저컨트롤을 맨 앞으로 보냄.
                                              //map.BringToFront(); //맨 앞으로 보냄.
                                              // Application.OpenForms["Hotel"].Close();
        }

        private void Mainbutton2_Click(object sender, EventArgs e)
        {
            panel_side.Height = Mainbutton2.Height;
            panel_side.Top = Mainbutton2.Top;
            new Hotel_Form().ShowDialog();
        }

        private void Mainbutton3_Click(object sender, EventArgs e)
        {
            panel_side.Height = Mainbutton3.Height;
            panel_side.Top = Mainbutton3.Top;
            new Weather().ShowDialog();
        }

        private void Mainbutton4_Click(object sender, EventArgs e)
        {
            panel_side.Height = Mainbutton4.Height;
            panel_side.Top = Mainbutton4.Top;
            new Admin_Form().ShowDialog();
        }

        private void chart()
        {
            // 여성 인원수
            chart1.Series[0].Points.Clear();
            chart1.Series[0].Points.AddXY(1, 17924);
            chart1.Series[0].Points.AddXY(2, 17325);
            chart1.Series[0].Points.AddXY(3, 13328);
            chart1.Series[0].Points.AddXY(4, 28987);
            chart1.Series[0].Points.AddXY(5, 20258);
            chart1.Series[0].Points.AddXY(6, 34785);
            chart1.Series[0].Points.AddXY(7, 52188);
            chart1.Series[0].Points.AddXY(8, 80549);
            chart1.Series[0].Points.AddXY(9, 98160);
            chart1.Series[0].Points.AddXY(10, 126434);
            chart1.Series[0].Points.AddXY(11, 139322);
            chart1.Series[0].Points.AddXY(12, 224985);

            // 남성 인원수
            chart1.Series[1].Points.Clear();
            chart1.Series[1].Points.AddXY(1, 36184);
            chart1.Series[1].Points.AddXY(2, 32854);
            chart1.Series[1].Points.AddXY(3, 28834);
            chart1.Series[1].Points.AddXY(4, 36184);
            chart1.Series[1].Points.AddXY(5, 37477);
            chart1.Series[1].Points.AddXY(6, 56183);
            chart1.Series[1].Points.AddXY(7, 82169);
            chart1.Series[1].Points.AddXY(8, 105712);
            chart1.Series[1].Points.AddXY(9, 121199);
            chart1.Series[1].Points.AddXY(10, 140007);
            chart1.Series[1].Points.AddXY(11, 154721);
            chart1.Series[1].Points.AddXY(12, 201483);

            // 남여 인원수 추세선
            chart1.Series[2].Points.Clear();
            chart1.Series[2].Points.AddXY(1, 54108);
            chart1.Series[2].Points.AddXY(2, 50179);
            chart1.Series[2].Points.AddXY(3, 42162);
            chart1.Series[2].Points.AddXY(4, 65171);
            chart1.Series[2].Points.AddXY(5, 57735);
            chart1.Series[2].Points.AddXY(6, 90968);
            chart1.Series[2].Points.AddXY(7, 134357);
            chart1.Series[2].Points.AddXY(8, 186261);
            chart1.Series[2].Points.AddXY(9, 219359);
            chart1.Series[2].Points.AddXY(10, 266441);
            chart1.Series[2].Points.AddXY(11, 294043);
            chart1.Series[2].Points.AddXY(12, 426468);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            main_timer.Text = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss");
        }

        private void MainForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
                this.Close();
        }
    }
}
