﻿namespace CSharp_teamProject
{
    partial class Weather
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.weather_button13 = new System.Windows.Forms.Button();
            this.weather_button14 = new System.Windows.Forms.Button();
            this.weather_button15 = new System.Windows.Forms.Button();
            this.weather_button16 = new System.Windows.Forms.Button();
            this.weather_button12 = new System.Windows.Forms.Button();
            this.weather_button7 = new System.Windows.Forms.Button();
            this.weather_button11 = new System.Windows.Forms.Button();
            this.weather_button10 = new System.Windows.Forms.Button();
            this.weather_button9 = new System.Windows.Forms.Button();
            this.weather_button8 = new System.Windows.Forms.Button();
            this.weather_button6 = new System.Windows.Forms.Button();
            this.weather_button5 = new System.Windows.Forms.Button();
            this.weather_button4 = new System.Windows.Forms.Button();
            this.weather_button3 = new System.Windows.Forms.Button();
            this.weather_label2 = new System.Windows.Forms.Label();
            this.weather_textBox2 = new System.Windows.Forms.TextBox();
            this.weather_button2 = new System.Windows.Forms.Button();
            this.weather_button1 = new System.Windows.Forms.Button();
            this.weather_label1 = new System.Windows.Forms.Label();
            this.weather_richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.weather_textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // weather_button13
            // 
            this.weather_button13.Location = new System.Drawing.Point(371, 149);
            this.weather_button13.Name = "weather_button13";
            this.weather_button13.Size = new System.Drawing.Size(72, 58);
            this.weather_button13.TabIndex = 46;
            this.weather_button13.Text = "울산";
            this.weather_button13.UseVisualStyleBackColor = true;
            this.weather_button13.Click += new System.EventHandler(this.weather_button13_Click);
            // 
            // weather_button14
            // 
            this.weather_button14.Location = new System.Drawing.Point(463, 149);
            this.weather_button14.Name = "weather_button14";
            this.weather_button14.Size = new System.Drawing.Size(72, 58);
            this.weather_button14.TabIndex = 45;
            this.weather_button14.Text = "광주";
            this.weather_button14.UseVisualStyleBackColor = true;
            this.weather_button14.Click += new System.EventHandler(this.weather_button14_Click);
            // 
            // weather_button15
            // 
            this.weather_button15.Location = new System.Drawing.Point(555, 149);
            this.weather_button15.Name = "weather_button15";
            this.weather_button15.Size = new System.Drawing.Size(72, 58);
            this.weather_button15.TabIndex = 44;
            this.weather_button15.Text = "부산";
            this.weather_button15.UseVisualStyleBackColor = true;
            this.weather_button15.Click += new System.EventHandler(this.weather_button15_Click);
            // 
            // weather_button16
            // 
            this.weather_button16.Location = new System.Drawing.Point(645, 149);
            this.weather_button16.Name = "weather_button16";
            this.weather_button16.Size = new System.Drawing.Size(72, 58);
            this.weather_button16.TabIndex = 43;
            this.weather_button16.Text = "제주";
            this.weather_button16.UseVisualStyleBackColor = true;
            this.weather_button16.Click += new System.EventHandler(this.weather_button16_Click);
            // 
            // weather_button12
            // 
            this.weather_button12.Location = new System.Drawing.Point(276, 149);
            this.weather_button12.Name = "weather_button12";
            this.weather_button12.Size = new System.Drawing.Size(72, 58);
            this.weather_button12.TabIndex = 42;
            this.weather_button12.Text = "창원";
            this.weather_button12.UseVisualStyleBackColor = true;
            this.weather_button12.Click += new System.EventHandler(this.weather_button12_Click);
            // 
            // weather_button7
            // 
            this.weather_button7.Location = new System.Drawing.Point(463, 69);
            this.weather_button7.Name = "weather_button7";
            this.weather_button7.Size = new System.Drawing.Size(72, 58);
            this.weather_button7.TabIndex = 41;
            this.weather_button7.Text = "울릉도";
            this.weather_button7.UseVisualStyleBackColor = true;
            this.weather_button7.Click += new System.EventHandler(this.weather_button7_Click);
            // 
            // weather_button11
            // 
            this.weather_button11.Location = new System.Drawing.Point(177, 149);
            this.weather_button11.Name = "weather_button11";
            this.weather_button11.Size = new System.Drawing.Size(72, 58);
            this.weather_button11.TabIndex = 40;
            this.weather_button11.Text = "전주";
            this.weather_button11.UseVisualStyleBackColor = true;
            this.weather_button11.Click += new System.EventHandler(this.weather_button11_Click);
            // 
            // weather_button10
            // 
            this.weather_button10.Location = new System.Drawing.Point(85, 149);
            this.weather_button10.Name = "weather_button10";
            this.weather_button10.Size = new System.Drawing.Size(72, 58);
            this.weather_button10.TabIndex = 39;
            this.weather_button10.Text = "대구";
            this.weather_button10.UseVisualStyleBackColor = true;
            this.weather_button10.Click += new System.EventHandler(this.weather_button10_Click);
            // 
            // weather_button9
            // 
            this.weather_button9.Location = new System.Drawing.Point(645, 69);
            this.weather_button9.Name = "weather_button9";
            this.weather_button9.Size = new System.Drawing.Size(72, 58);
            this.weather_button9.TabIndex = 38;
            this.weather_button9.Text = "청주";
            this.weather_button9.UseVisualStyleBackColor = true;
            this.weather_button9.Click += new System.EventHandler(this.weather_button9_Click);
            // 
            // weather_button8
            // 
            this.weather_button8.Location = new System.Drawing.Point(555, 69);
            this.weather_button8.Name = "weather_button8";
            this.weather_button8.Size = new System.Drawing.Size(72, 58);
            this.weather_button8.TabIndex = 37;
            this.weather_button8.Text = "대전";
            this.weather_button8.UseVisualStyleBackColor = true;
            this.weather_button8.Click += new System.EventHandler(this.weather_button8_Click);
            // 
            // weather_button6
            // 
            this.weather_button6.Location = new System.Drawing.Point(371, 69);
            this.weather_button6.Name = "weather_button6";
            this.weather_button6.Size = new System.Drawing.Size(72, 58);
            this.weather_button6.TabIndex = 36;
            this.weather_button6.Text = "강릉";
            this.weather_button6.UseVisualStyleBackColor = true;
            this.weather_button6.Click += new System.EventHandler(this.weather_button6_Click);
            // 
            // weather_button5
            // 
            this.weather_button5.Location = new System.Drawing.Point(276, 69);
            this.weather_button5.Name = "weather_button5";
            this.weather_button5.Size = new System.Drawing.Size(72, 58);
            this.weather_button5.TabIndex = 35;
            this.weather_button5.Text = "춘천";
            this.weather_button5.UseVisualStyleBackColor = true;
            this.weather_button5.Click += new System.EventHandler(this.weather_button5_Click);
            // 
            // weather_button4
            // 
            this.weather_button4.Location = new System.Drawing.Point(176, 69);
            this.weather_button4.Name = "weather_button4";
            this.weather_button4.Size = new System.Drawing.Size(72, 58);
            this.weather_button4.TabIndex = 34;
            this.weather_button4.Text = "인천";
            this.weather_button4.UseVisualStyleBackColor = true;
            this.weather_button4.Click += new System.EventHandler(this.weather_button4_Click_1);
            // 
            // weather_button3
            // 
            this.weather_button3.Location = new System.Drawing.Point(85, 69);
            this.weather_button3.Name = "weather_button3";
            this.weather_button3.Size = new System.Drawing.Size(72, 58);
            this.weather_button3.TabIndex = 33;
            this.weather_button3.Text = "서울";
            this.weather_button3.UseVisualStyleBackColor = true;
            this.weather_button3.Click += new System.EventHandler(this.weather_button3_Click);
            // 
            // weather_label2
            // 
            this.weather_label2.AutoSize = true;
            this.weather_label2.Location = new System.Drawing.Point(754, 172);
            this.weather_label2.Name = "weather_label2";
            this.weather_label2.Size = new System.Drawing.Size(22, 12);
            this.weather_label2.TabIndex = 32;
            this.weather_label2.Text = "lon";
            // 
            // weather_textBox2
            // 
            this.weather_textBox2.Location = new System.Drawing.Point(800, 169);
            this.weather_textBox2.Name = "weather_textBox2";
            this.weather_textBox2.Size = new System.Drawing.Size(100, 21);
            this.weather_textBox2.TabIndex = 31;
            // 
            // weather_button2
            // 
            this.weather_button2.Location = new System.Drawing.Point(800, 356);
            this.weather_button2.Name = "weather_button2";
            this.weather_button2.Size = new System.Drawing.Size(75, 23);
            this.weather_button2.TabIndex = 30;
            this.weather_button2.Text = "주간날씨";
            this.weather_button2.UseVisualStyleBackColor = true;
            this.weather_button2.Click += new System.EventHandler(this.weather_button2_Click);
            // 
            // weather_button1
            // 
            this.weather_button1.Location = new System.Drawing.Point(800, 307);
            this.weather_button1.Name = "weather_button1";
            this.weather_button1.Size = new System.Drawing.Size(75, 23);
            this.weather_button1.TabIndex = 29;
            this.weather_button1.Text = "현재날씨";
            this.weather_button1.UseVisualStyleBackColor = true;
            this.weather_button1.Click += new System.EventHandler(this.weather_button1_Click);
            // 
            // weather_label1
            // 
            this.weather_label1.AutoSize = true;
            this.weather_label1.Location = new System.Drawing.Point(754, 132);
            this.weather_label1.Name = "weather_label1";
            this.weather_label1.Size = new System.Drawing.Size(18, 12);
            this.weather_label1.TabIndex = 28;
            this.weather_label1.Text = "lat";
            // 
            // weather_richTextBox1
            // 
            this.weather_richTextBox1.Location = new System.Drawing.Point(188, 218);
            this.weather_richTextBox1.Name = "weather_richTextBox1";
            this.weather_richTextBox1.Size = new System.Drawing.Size(584, 374);
            this.weather_richTextBox1.TabIndex = 27;
            this.weather_richTextBox1.Text = "";
            // 
            // weather_textBox1
            // 
            this.weather_textBox1.Location = new System.Drawing.Point(800, 129);
            this.weather_textBox1.Name = "weather_textBox1";
            this.weather_textBox1.Size = new System.Drawing.Size(100, 21);
            this.weather_textBox1.TabIndex = 26;
            // 
            // Weather2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 661);
            this.Controls.Add(this.weather_button13);
            this.Controls.Add(this.weather_button14);
            this.Controls.Add(this.weather_button15);
            this.Controls.Add(this.weather_button16);
            this.Controls.Add(this.weather_button12);
            this.Controls.Add(this.weather_button7);
            this.Controls.Add(this.weather_button11);
            this.Controls.Add(this.weather_button10);
            this.Controls.Add(this.weather_button9);
            this.Controls.Add(this.weather_button8);
            this.Controls.Add(this.weather_button6);
            this.Controls.Add(this.weather_button5);
            this.Controls.Add(this.weather_button4);
            this.Controls.Add(this.weather_button3);
            this.Controls.Add(this.weather_label2);
            this.Controls.Add(this.weather_textBox2);
            this.Controls.Add(this.weather_button2);
            this.Controls.Add(this.weather_button1);
            this.Controls.Add(this.weather_label1);
            this.Controls.Add(this.weather_richTextBox1);
            this.Controls.Add(this.weather_textBox1);
            this.Name = "Weather2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Weather";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button weather_button13;
        private System.Windows.Forms.Button weather_button14;
        private System.Windows.Forms.Button weather_button15;
        private System.Windows.Forms.Button weather_button16;
        private System.Windows.Forms.Button weather_button12;
        private System.Windows.Forms.Button weather_button7;
        private System.Windows.Forms.Button weather_button11;
        private System.Windows.Forms.Button weather_button10;
        private System.Windows.Forms.Button weather_button9;
        private System.Windows.Forms.Button weather_button8;
        private System.Windows.Forms.Button weather_button6;
        private System.Windows.Forms.Button weather_button5;
        private System.Windows.Forms.Button weather_button4;
        private System.Windows.Forms.Button weather_button3;
        private System.Windows.Forms.Label weather_label2;
        private System.Windows.Forms.TextBox weather_textBox2;
        private System.Windows.Forms.Button weather_button2;
        private System.Windows.Forms.Button weather_button1;
        private System.Windows.Forms.Label weather_label1;
        private System.Windows.Forms.RichTextBox weather_richTextBox1;
        private System.Windows.Forms.TextBox weather_textBox1;
    }
}