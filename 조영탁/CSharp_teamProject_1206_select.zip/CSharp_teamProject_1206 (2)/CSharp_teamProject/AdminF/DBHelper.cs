﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace CSharp_teamProject
{
    public abstract class DBHelper
    {
        protected SqlConnection conn = new SqlConnection();
        protected SqlDataAdapter da;
        protected DataSet ds;
        public DataTable dt;
        public List<User> UsersSelect = new List<User>();


        protected void ConnectDB()
        {
            string dataSource = "local";
            string db = "HHDB";
            string security = "SSPI";
            conn.ConnectionString = string.Format
                ("Data Source=({0}); initial Catalog={1};" +
                "integrated Security={2};" +
                "Timeout=3", dataSource, db, security);
            conn = new SqlConnection(conn.ConnectionString);
            conn.Open();
        }

        public abstract List<User> selectQuery(string user_id = "");
        public abstract int updateQuery(string user_id, string user_passWord, string user_name, string user_phoneNum, string user_email);
        public abstract int deleteQuery(string user_id, string user_passWord);
        public abstract int insertQuery(string user_id, string user_passWord, string user_name, string user_phoneNum, string user_email);
    }
}
