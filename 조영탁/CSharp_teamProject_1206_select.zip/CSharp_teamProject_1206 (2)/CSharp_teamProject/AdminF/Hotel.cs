﻿using System;

namespace CSharp_teamProject
{
    public class Hotel
    {
        public int hotel_num { get; set; }
        public string hotel_name { get; set; }
        public string hotel_phoneNum { get; set; }
        public string hotel_address { get; set; }
        public string hotel_zipCode { get; set; }
        public string hotel_coordinateX { get; set; }
        public string hotel_coordinateY { get; set; }
        public string hotel_roomCount { get; set; }
        public DateTime hotel_createTime { get; set; }
    }
}