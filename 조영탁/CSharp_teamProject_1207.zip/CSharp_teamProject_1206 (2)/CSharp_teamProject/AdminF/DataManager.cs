﻿using System.Collections.Generic;
using System.IO;

namespace CSharp_teamProject
{
    public abstract class DataManager
    {
        public List<User> Users = new List<User>();
      
        public List<Hotel> Hotels = new List<Hotel>();

        public abstract void Load(string user_id_box = "");
        public abstract void Save();

        public void printLog(string contents)
        {
            DirectoryInfo di = new DirectoryInfo("Admin_History");
            if (di.Exists == false)
                di.Create();

            using (StreamWriter w = new StreamWriter("Admin_History\\Admin_History.txt", true))
            {
                w.WriteLine(contents);
            }
        }
    }
}
