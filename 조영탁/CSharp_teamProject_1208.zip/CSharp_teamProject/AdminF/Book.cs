﻿using System;

namespace CSharp_teamProject.HotelF
{
    public class Book
    {
        public int book_num { get; set; }
        public string book_id { get; set; }
        public string book_name { get; set; }
        public string book_hotelName { get; set; }
        public string book_hotelRoomNumber { get; set; }
        public DateTime book_createTime { get; set; }
    }
}
