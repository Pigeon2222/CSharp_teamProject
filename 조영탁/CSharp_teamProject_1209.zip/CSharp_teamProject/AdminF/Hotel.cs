﻿namespace CSharp_teamProject
{
    public class Hotel
    {
        public int hotel_num { get; set; }
        public string hotel_name { get; set; }
        public string hotel_tell { get; set; }
        public string hotel_post { get; set; }
        public string hotel_addr { get; set; }
        public int hotel_roomNumber { get; set; }
        public double hotel_lat { get; set; }
        public double hotel_lng { get; set; }
    }
}