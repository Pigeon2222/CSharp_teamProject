﻿namespace CSharp_teamProject
{
    partial class Login_up
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login_up));
            this.Login_button3 = new System.Windows.Forms.Button();
            this.Login_button2 = new System.Windows.Forms.Button();
            this.Login_button1 = new System.Windows.Forms.Button();
            this.Login_button5 = new System.Windows.Forms.Button();
            this.Login_pictureBox = new System.Windows.Forms.PictureBox();
            this.Login_button_Login = new System.Windows.Forms.Button();
            this.Login_label5 = new System.Windows.Forms.Label();
            this.Login_label4 = new System.Windows.Forms.Label();
            this.Login_label3 = new System.Windows.Forms.Label();
            this.Login_TextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.Login_label2 = new System.Windows.Forms.Label();
            this.Login_label1 = new System.Windows.Forms.Label();
            this.Login_panel = new System.Windows.Forms.Panel();
            this.Login_TextBox2 = new System.Windows.Forms.MaskedTextBox();
            this.Login_button6 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Login_pictureBox)).BeginInit();
            this.Login_panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // Login_button3
            // 
            this.Login_button3.BackColor = System.Drawing.Color.White;
            this.Login_button3.FlatAppearance.BorderSize = 0;
            this.Login_button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Login_button3.Image = ((System.Drawing.Image)(resources.GetObject("Login_button3.Image")));
            this.Login_button3.Location = new System.Drawing.Point(268, 11);
            this.Login_button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Login_button3.Name = "Login_button3";
            this.Login_button3.Size = new System.Drawing.Size(31, 38);
            this.Login_button3.TabIndex = 7;
            this.Login_button3.UseVisualStyleBackColor = false;
            this.Login_button3.Click += new System.EventHandler(this.Login_button3_Click);
            // 
            // Login_button2
            // 
            this.Login_button2.BackColor = System.Drawing.Color.White;
            this.Login_button2.FlatAppearance.BorderSize = 0;
            this.Login_button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Login_button2.Image = ((System.Drawing.Image)(resources.GetObject("Login_button2.Image")));
            this.Login_button2.Location = new System.Drawing.Point(219, 11);
            this.Login_button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Login_button2.Name = "Login_button2";
            this.Login_button2.Size = new System.Drawing.Size(31, 38);
            this.Login_button2.TabIndex = 8;
            this.Login_button2.UseVisualStyleBackColor = false;
            this.Login_button2.Click += new System.EventHandler(this.Login_button2_Click);
            // 
            // Login_button1
            // 
            this.Login_button1.BackColor = System.Drawing.Color.White;
            this.Login_button1.FlatAppearance.BorderSize = 0;
            this.Login_button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Login_button1.Image = ((System.Drawing.Image)(resources.GetObject("Login_button1.Image")));
            this.Login_button1.Location = new System.Drawing.Point(10, 9);
            this.Login_button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Login_button1.Name = "Login_button1";
            this.Login_button1.Size = new System.Drawing.Size(31, 38);
            this.Login_button1.TabIndex = 9;
            this.Login_button1.UseVisualStyleBackColor = false;
            this.Login_button1.Click += new System.EventHandler(this.Login_button1_Click);
            // 
            // Login_button5
            // 
            this.Login_button5.BackColor = System.Drawing.Color.White;
            this.Login_button5.FlatAppearance.BorderSize = 0;
            this.Login_button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Login_button5.Image = ((System.Drawing.Image)(resources.GetObject("Login_button5.Image")));
            this.Login_button5.Location = new System.Drawing.Point(314, 10);
            this.Login_button5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Login_button5.Name = "Login_button5";
            this.Login_button5.Size = new System.Drawing.Size(31, 38);
            this.Login_button5.TabIndex = 10;
            this.Login_button5.UseVisualStyleBackColor = false;
            this.Login_button5.Click += new System.EventHandler(this.Login_button5_Click);
            // 
            // Login_pictureBox
            // 
            this.Login_pictureBox.Dock = System.Windows.Forms.DockStyle.Right;
            this.Login_pictureBox.Image = ((System.Drawing.Image)(resources.GetObject("Login_pictureBox.Image")));
            this.Login_pictureBox.Location = new System.Drawing.Point(398, 0);
            this.Login_pictureBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Login_pictureBox.Name = "Login_pictureBox";
            this.Login_pictureBox.Size = new System.Drawing.Size(402, 450);
            this.Login_pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Login_pictureBox.TabIndex = 5;
            this.Login_pictureBox.TabStop = false;
            // 
            // Login_button_Login
            // 
            this.Login_button_Login.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Login_button_Login.FlatAppearance.BorderSize = 0;
            this.Login_button_Login.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Login_button_Login.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Login_button_Login.Location = new System.Drawing.Point(218, 303);
            this.Login_button_Login.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Login_button_Login.Name = "Login_button_Login";
            this.Login_button_Login.Size = new System.Drawing.Size(134, 59);
            this.Login_button_Login.TabIndex = 19;
            this.Login_button_Login.Text = "Login";
            this.Login_button_Login.UseVisualStyleBackColor = false;
            this.Login_button_Login.Click += new System.EventHandler(this.Login_button_Login_Click);
            // 
            // Login_label5
            // 
            this.Login_label5.AutoSize = true;
            this.Login_label5.BackColor = System.Drawing.Color.White;
            this.Login_label5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Login_label5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Login_label5.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.Login_label5.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Login_label5.Location = new System.Drawing.Point(267, 408);
            this.Login_label5.Name = "Login_label5";
            this.Login_label5.Size = new System.Drawing.Size(81, 23);
            this.Login_label5.TabIndex = 11;
            this.Login_label5.Text = "Sign up";
            this.Login_label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // Login_label4
            // 
            this.Login_label4.AutoSize = true;
            this.Login_label4.BackColor = System.Drawing.Color.White;
            this.Login_label4.Font = new System.Drawing.Font("Fira Mono", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Login_label4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Login_label4.Location = new System.Drawing.Point(11, 411);
            this.Login_label4.Name = "Login_label4";
            this.Login_label4.Size = new System.Drawing.Size(230, 21);
            this.Login_label4.TabIndex = 12;
            this.Login_label4.Text = "Don\'t Have an Account?";
            // 
            // Login_label3
            // 
            this.Login_label3.AutoSize = true;
            this.Login_label3.BackColor = System.Drawing.Color.White;
            this.Login_label3.Font = new System.Drawing.Font("Fira Mono", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Login_label3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Login_label3.Location = new System.Drawing.Point(34, 229);
            this.Login_label3.Name = "Login_label3";
            this.Login_label3.Size = new System.Drawing.Size(90, 21);
            this.Login_label3.TabIndex = 13;
            this.Login_label3.Text = "Password";
            // 
            // Login_TextBox1
            // 
            this.Login_TextBox1.Location = new System.Drawing.Point(152, 192);
            this.Login_TextBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Login_TextBox1.Name = "Login_TextBox1";
            this.Login_TextBox1.Size = new System.Drawing.Size(200, 25);
            this.Login_TextBox1.TabIndex = 17;
            // 
            // Login_label2
            // 
            this.Login_label2.AutoSize = true;
            this.Login_label2.BackColor = System.Drawing.Color.White;
            this.Login_label2.Font = new System.Drawing.Font("Fira Mono", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Login_label2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Login_label2.Location = new System.Drawing.Point(36, 196);
            this.Login_label2.Name = "Login_label2";
            this.Login_label2.Size = new System.Drawing.Size(40, 21);
            this.Login_label2.TabIndex = 14;
            this.Login_label2.Text = "ID ";
            // 
            // Login_label1
            // 
            this.Login_label1.AutoSize = true;
            this.Login_label1.BackColor = System.Drawing.Color.White;
            this.Login_label1.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Login_label1.Location = new System.Drawing.Point(30, 112);
            this.Login_label1.Name = "Login_label1";
            this.Login_label1.Size = new System.Drawing.Size(114, 44);
            this.Login_label1.TabIndex = 15;
            this.Login_label1.Text = "Login";
            // 
            // Login_panel
            // 
            this.Login_panel.BackColor = System.Drawing.Color.White;
            this.Login_panel.Controls.Add(this.Login_button6);
            this.Login_panel.Controls.Add(this.Login_button1);
            this.Login_panel.Controls.Add(this.Login_TextBox2);
            this.Login_panel.Controls.Add(this.Login_label4);
            this.Login_panel.Controls.Add(this.Login_button_Login);
            this.Login_panel.Controls.Add(this.Login_label5);
            this.Login_panel.Controls.Add(this.Login_label3);
            this.Login_panel.Controls.Add(this.Login_button2);
            this.Login_panel.Controls.Add(this.Login_TextBox1);
            this.Login_panel.Controls.Add(this.Login_button5);
            this.Login_panel.Controls.Add(this.Login_label2);
            this.Login_panel.Controls.Add(this.Login_button3);
            this.Login_panel.Controls.Add(this.Login_label1);
            this.Login_panel.Location = new System.Drawing.Point(0, 0);
            this.Login_panel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Login_panel.Name = "Login_panel";
            this.Login_panel.Size = new System.Drawing.Size(489, 450);
            this.Login_panel.TabIndex = 19;
            // 
            // Login_TextBox2
            // 
            this.Login_TextBox2.Location = new System.Drawing.Point(152, 226);
            this.Login_TextBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Login_TextBox2.Name = "Login_TextBox2";
            this.Login_TextBox2.PasswordChar = '*';
            this.Login_TextBox2.Size = new System.Drawing.Size(200, 25);
            this.Login_TextBox2.TabIndex = 18;
            // 
            // Login_button6
            // 
            this.Login_button6.BackColor = System.Drawing.Color.White;
            this.Login_button6.FlatAppearance.BorderSize = 0;
            this.Login_button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Login_button6.Image = ((System.Drawing.Image)(resources.GetObject("Login_button6.Image")));
            this.Login_button6.Location = new System.Drawing.Point(359, 10);
            this.Login_button6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Login_button6.Name = "Login_button6";
            this.Login_button6.Size = new System.Drawing.Size(31, 38);
            this.Login_button6.TabIndex = 20;
            this.Login_button6.UseVisualStyleBackColor = false;
            this.Login_button6.Click += new System.EventHandler(this.Login_button6_Click);
            // 
            // Login_up
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Login_pictureBox);
            this.Controls.Add(this.Login_panel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Login_up";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Form1";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Login_up_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.Login_pictureBox)).EndInit();
            this.Login_panel.ResumeLayout(false);
            this.Login_panel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button Login_button3;
        private System.Windows.Forms.Button Login_button2;
        private System.Windows.Forms.Button Login_button1;
        private System.Windows.Forms.Button Login_button5;
        private System.Windows.Forms.PictureBox Login_pictureBox;
        private System.Windows.Forms.Button Login_button_Login;
        private System.Windows.Forms.Label Login_label5;
        private System.Windows.Forms.Label Login_label4;
        private System.Windows.Forms.Label Login_label3;
        private System.Windows.Forms.MaskedTextBox Login_TextBox1;
        private System.Windows.Forms.Label Login_label2;
        private System.Windows.Forms.Label Login_label1;
        private System.Windows.Forms.Panel Login_panel;
        private System.Windows.Forms.MaskedTextBox Login_TextBox2;
        private System.Windows.Forms.Button Login_button6;
    }
}