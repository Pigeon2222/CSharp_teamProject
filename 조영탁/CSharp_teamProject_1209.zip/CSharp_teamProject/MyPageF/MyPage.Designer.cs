﻿namespace CSharp_teamProject
{
    partial class MyPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MyPage));
            this.MyPage_label8_2 = new System.Windows.Forms.Label();
            this.MyPage_label7_2 = new System.Windows.Forms.Label();
            this.MyPage_label6_2 = new System.Windows.Forms.Label();
            this.MyPage_label5_2 = new System.Windows.Forms.Label();
            this.MyPage_label4_2 = new System.Windows.Forms.Label();
            this.MyPage_label3_2 = new System.Windows.Forms.Label();
            this.MyPage_label1_2 = new System.Windows.Forms.Label();
            this.MyPage_label2_2 = new System.Windows.Forms.Label();
            this.MyPage_button1 = new System.Windows.Forms.Button();
            this.MyPage_listBox1 = new System.Windows.Forms.ListBox();
            this.MyPage_label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // MyPage_label8_2
            // 
            this.MyPage_label8_2.AutoSize = true;
            this.MyPage_label8_2.BackColor = System.Drawing.Color.Transparent;
            this.MyPage_label8_2.Font = new System.Drawing.Font("Georgia", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MyPage_label8_2.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.MyPage_label8_2.Location = new System.Drawing.Point(125, 375);
            this.MyPage_label8_2.Name = "MyPage_label8_2";
            this.MyPage_label8_2.Size = new System.Drawing.Size(0, 31);
            this.MyPage_label8_2.TabIndex = 15;
            // 
            // MyPage_label7_2
            // 
            this.MyPage_label7_2.AutoSize = true;
            this.MyPage_label7_2.BackColor = System.Drawing.Color.Transparent;
            this.MyPage_label7_2.Font = new System.Drawing.Font("Georgia", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MyPage_label7_2.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.MyPage_label7_2.Location = new System.Drawing.Point(124, 297);
            this.MyPage_label7_2.Name = "MyPage_label7_2";
            this.MyPage_label7_2.Size = new System.Drawing.Size(0, 31);
            this.MyPage_label7_2.TabIndex = 14;
            // 
            // MyPage_label6_2
            // 
            this.MyPage_label6_2.AutoSize = true;
            this.MyPage_label6_2.BackColor = System.Drawing.Color.Transparent;
            this.MyPage_label6_2.Font = new System.Drawing.Font("Georgia", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MyPage_label6_2.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.MyPage_label6_2.Location = new System.Drawing.Point(124, 137);
            this.MyPage_label6_2.Name = "MyPage_label6_2";
            this.MyPage_label6_2.Size = new System.Drawing.Size(0, 31);
            this.MyPage_label6_2.TabIndex = 13;
            // 
            // MyPage_label5_2
            // 
            this.MyPage_label5_2.AutoSize = true;
            this.MyPage_label5_2.BackColor = System.Drawing.Color.Transparent;
            this.MyPage_label5_2.Font = new System.Drawing.Font("Georgia", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MyPage_label5_2.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.MyPage_label5_2.Location = new System.Drawing.Point(124, 215);
            this.MyPage_label5_2.Name = "MyPage_label5_2";
            this.MyPage_label5_2.Size = new System.Drawing.Size(0, 31);
            this.MyPage_label5_2.TabIndex = 12;
            // 
            // MyPage_label4_2
            // 
            this.MyPage_label4_2.AutoSize = true;
            this.MyPage_label4_2.BackColor = System.Drawing.Color.Transparent;
            this.MyPage_label4_2.Font = new System.Drawing.Font("Georgia", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MyPage_label4_2.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.MyPage_label4_2.Location = new System.Drawing.Point(25, 378);
            this.MyPage_label4_2.Name = "MyPage_label4_2";
            this.MyPage_label4_2.Size = new System.Drawing.Size(79, 27);
            this.MyPage_label4_2.TabIndex = 11;
            this.MyPage_label4_2.Text = "Email";
            // 
            // MyPage_label3_2
            // 
            this.MyPage_label3_2.AutoSize = true;
            this.MyPage_label3_2.BackColor = System.Drawing.Color.Transparent;
            this.MyPage_label3_2.Font = new System.Drawing.Font("Georgia", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MyPage_label3_2.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.MyPage_label3_2.Location = new System.Drawing.Point(25, 298);
            this.MyPage_label3_2.Name = "MyPage_label3_2";
            this.MyPage_label3_2.Size = new System.Drawing.Size(84, 27);
            this.MyPage_label3_2.TabIndex = 10;
            this.MyPage_label3_2.Text = "Phone";
            // 
            // MyPage_label1_2
            // 
            this.MyPage_label1_2.AutoSize = true;
            this.MyPage_label1_2.BackColor = System.Drawing.Color.Transparent;
            this.MyPage_label1_2.Font = new System.Drawing.Font("Georgia", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MyPage_label1_2.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.MyPage_label1_2.Location = new System.Drawing.Point(25, 218);
            this.MyPage_label1_2.Name = "MyPage_label1_2";
            this.MyPage_label1_2.Size = new System.Drawing.Size(78, 27);
            this.MyPage_label1_2.TabIndex = 9;
            this.MyPage_label1_2.Text = "Name";
            // 
            // MyPage_label2_2
            // 
            this.MyPage_label2_2.AutoSize = true;
            this.MyPage_label2_2.BackColor = System.Drawing.Color.Transparent;
            this.MyPage_label2_2.Font = new System.Drawing.Font("Georgia", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MyPage_label2_2.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.MyPage_label2_2.Location = new System.Drawing.Point(46, 142);
            this.MyPage_label2_2.Name = "MyPage_label2_2";
            this.MyPage_label2_2.Size = new System.Drawing.Size(40, 27);
            this.MyPage_label2_2.TabIndex = 8;
            this.MyPage_label2_2.Text = "ID";
            // 
            // MyPage_button1
            // 
            this.MyPage_button1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.MyPage_button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("MyPage_button1.BackgroundImage")));
            this.MyPage_button1.FlatAppearance.BorderSize = 0;
            this.MyPage_button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MyPage_button1.Font = new System.Drawing.Font("Georgia", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MyPage_button1.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.MyPage_button1.Location = new System.Drawing.Point(458, 48);
            this.MyPage_button1.Name = "MyPage_button1";
            this.MyPage_button1.Size = new System.Drawing.Size(442, 59);
            this.MyPage_button1.TabIndex = 18;
            this.MyPage_button1.Text = "Check your Reservation";
            this.MyPage_button1.UseVisualStyleBackColor = false;
            this.MyPage_button1.Click += new System.EventHandler(this.MyPage_button1_Click);
            // 
            // MyPage_listBox1
            // 
            this.MyPage_listBox1.FormattingEnabled = true;
            this.MyPage_listBox1.ItemHeight = 12;
            this.MyPage_listBox1.Location = new System.Drawing.Point(458, 121);
            this.MyPage_listBox1.Name = "MyPage_listBox1";
            this.MyPage_listBox1.Size = new System.Drawing.Size(442, 316);
            this.MyPage_listBox1.TabIndex = 19;
            // 
            // MyPage_label1
            // 
            this.MyPage_label1.AutoSize = true;
            this.MyPage_label1.BackColor = System.Drawing.Color.Transparent;
            this.MyPage_label1.Font = new System.Drawing.Font("Georgia", 28.2F);
            this.MyPage_label1.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.MyPage_label1.Location = new System.Drawing.Point(130, 52);
            this.MyPage_label1.Name = "MyPage_label1";
            this.MyPage_label1.Size = new System.Drawing.Size(161, 43);
            this.MyPage_label1.TabIndex = 20;
            this.MyPage_label1.Text = "My Page";
            // 
            // MyPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(936, 480);
            this.Controls.Add(this.MyPage_label1);
            this.Controls.Add(this.MyPage_listBox1);
            this.Controls.Add(this.MyPage_button1);
            this.Controls.Add(this.MyPage_label8_2);
            this.Controls.Add(this.MyPage_label7_2);
            this.Controls.Add(this.MyPage_label6_2);
            this.Controls.Add(this.MyPage_label5_2);
            this.Controls.Add(this.MyPage_label4_2);
            this.Controls.Add(this.MyPage_label3_2);
            this.Controls.Add(this.MyPage_label1_2);
            this.Controls.Add(this.MyPage_label2_2);
            this.Name = "MyPage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MyPage";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MyPage_KeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label MyPage_label8_2;
        private System.Windows.Forms.Label MyPage_label7_2;
        private System.Windows.Forms.Label MyPage_label6_2;
        private System.Windows.Forms.Label MyPage_label5_2;
        private System.Windows.Forms.Label MyPage_label4_2;
        private System.Windows.Forms.Label MyPage_label3_2;
        private System.Windows.Forms.Label MyPage_label1_2;
        private System.Windows.Forms.Label MyPage_label2_2;
        private System.Windows.Forms.Button MyPage_button1;
        private System.Windows.Forms.ListBox MyPage_listBox1;
        private System.Windows.Forms.Label MyPage_label1;
    }
}